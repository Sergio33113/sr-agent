"""Entrypoint: the kit wrapper runs the stdin/stdout loop, mech.brain.Brain makes the decisions.
mf.run() is called at module level, like the kit's example bot, so harnesses that load this file
in-process (with mechfight.run stubbed) find the bot too."""
import mechfight as mf
from mech.brain import Brain

mf.run(Brain)
