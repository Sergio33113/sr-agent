"""Tunable behaviour parameters (not game rules: those come from hello.config).

Defaults are the shipped values. For local tuning only, MECH_PARAMS may point at a JSON file
whose keys override these (the simulator uses this; the match image never sets it).
"""
from __future__ import annotations

import json
import os

DEFAULTS = {
    # --- weapons and loadout
    "weapon_value": {"laser": 10.0, "lightning": 8.0, "mortar": 2.0, "gun": 5.0},
    "late_lightning_bonus": 4.0,     # lightning value bonus once the zone radius is small
    "late_radius": 140.0,            # "late game" when next_radius <= this
    "swap_margin": 2.5,              # value gain needed to swap a weapon
    "loot_detour_m": 90.0,           # max extra walk for loot when safe
    "cube_detour_m": 70.0,
    "crate_shoot_range": 150.0,
    "npc_hunt": True,
    "npc_hunt_range": 140.0,
    "npc_min_hp_frac": 0.8,          # only hunt drones when our hp fraction is above this
    "fight_cube_m": 0.0,             # while fighting, walk to a known cube this close (0 = off)
    "fight_cube_hp": 0.5,            # ... only above this hp fraction
    "farm_regen_hp": 0.85,           # below this hp fraction (and hit in the last 20 s) don't farm: let regen work
    "reload_below_frac": 0.6,        # with no enemy in view, reload when the magazine is below this fraction
    # --- practice squad economy (econ1s): the leading practice bots take cubes mid-fight and farm readily.
    # Real board, same 48 seeds: econ1 (all modes) 5.42 vs 4.96; mechsim league (free-for-all) -1.44 +-0.69,
    # so these apply only while the house squad is detected (Brain.sq).
    "squad_npc_min_hp_frac": 0.5,
    "squad_npc_hunt_range": 170.0,
    "squad_fight_cube_m": 60.0,
    "squad_farm_regen_hp": 0.5,
    "squad_reload_below_frac": 0.999,
    # --- combat
    "aggression": 1.0,               # >1 fights more, <1 avoids more
    "engage_ratio": 1.15,            # fight if our kill time * ratio < theirs
    "retreat_hp_frac": 0.35,         # break off below this hp fraction when losing
    "kite_range_laser": 120.0,       # preferred distance with laser/gun and no lightning
    "close_range_lightning": 28.0,   # preferred distance when we hold lightning and they don't
    "lightning_energy_reserve": 12.0,
    "strafe_min_s": 0.35,
    "strafe_max_s": 1.1,
    "gun_aim_tol": 0.9,              # fire gun when aim error < tol * target angular radius
    "laser_aim_tol": 0.6,
    "laser_min_range": 0.0,
    "mortar_min_range": 25.0,
    "mortar_max_target_speed": 4.0,  # only lob at slow targets (or crates/NPCs)
    # --- zone and position
    "zone_margin": 18.0,             # stay this far inside the next circle
    "zone_hold_frac": 0.55,          # hold at this fraction of next radius from its centre
    "zone_lead_s": 8.0,              # leave this many seconds of slack when rotating
    "edge_cover_bonus": 1.0,
    # --- drops
    "drop_go": True,
    "drop_max_dist": 160.0,
    "drop_hp_frac": 0.0,             # go for drops only above this hp fraction (0 = always)
    # --- upgrades: base value per pick (diminishing with stacks)
    "upgrade_value": {
        "plating": 10.0, "nanites": 8.5, "armor": 8.0,
        "laser_damage": 8.5, "laser_charge": 6.0, "laser_pierce": 1.0,
        "gun_mag": 7.0, "gun_damage": 7.0, "gun_rate": 6.5, "gun_velocity": 4.5,
        "lightning_efficiency": 6.5, "lightning_range": 6.0, "lightning_chain": 3.5,
        "mortar_reload": 4.0, "mortar_velocity": 3.0, "mortar_splash": 3.0,
        "sensors": 5.0, "servos": 5.0, "gyros": 4.0, "reactor": 4.0, "capacitor": 3.5, "jets": 3.5,
    },
    # --- loadout rule of both practice-board leaders (B11): keep the gun beside a laser, lightning below the gun.
    # mechsim, 96 paired seeds each: practice +1.07 +-0.36 and +0.46 +-0.41 (calibrated squad), +0.07 +-0.25 and
    # +0.39 +-0.25 (full squad); league free-for-all +0.42 +-0.45.
    "gun_laser_always": True,
    "gun_laser_unless_ffa": False,   # the same rule only until there is free-for-all evidence
    "squad_lightning_value": 4.0,    # lightning's value under that rule (gun 5, laser 10)
    # --- practice house squad (mech/brain.py `self.squad`): 15 house bots that share vision, never fight
    # each other and hunt us, one more per kill. Experiments, all off: in mechsim they lost or tied (B11,
    # ../_keep/practice-score.md). squad_hyper is AT's real-board recipe, kept for a real-board test.
    "squad_mode": True,
    "squad_after_s": 0.0,       # econ (sq() params) from the first second unless free-for-all evidence (S11: first death we did not cause at a median 11.9 s in the final-like league)
    "squad_no_retreat": False,       # never break off while a hunter can shoot us; heal once none can
    "squad_heal_below": 0.8,         # out of contact below this hp fraction: hide and hold fire to regen
    "squad_fight_back": False,       # when hit, shoot back instead of evading
    "squad_dmg_upgrades": True,      # damage upgrades first in practice only (kills are the practice score; AT's D1)
    "squad_upgrade_value": {
        "laser_damage": 12.0, "gun_damage": 11.0, "gun_rate": 10.5, "lightning_efficiency": 10.0,
        "laser_charge": 9.5, "lightning_chain": 8.0, "lightning_range": 7.5,
    },
    "squad_gun_laser": False,        # the loadout rule only in squad mode
    "squad_hyper": False,            # attack every mech we see, chase it, no hiding to heal while one is near
    "squad_smith_target": False,     # 2+ shooters: kill first the max (their dps / our time to kill) (Smith's rule)
    "squad_retreat_hp_frac": 0.25,   # practice only, after 30 s (Brain.sqk): break off later (B: 0.35)
    # --- work caps per tick (deterministic: counted, not timed; F6). Sized from the time budgets they
    # replace on the M2 under CPython 3.9: a line-of-sight ray costs ~0.032 ms, a 250-node A* chunk ~0.9 ms.
    "cover_ray_budget": 150,         # rays per cover search (was 5 ms)
    "astar_chunks_path": 5,          # A* chunks per tick while a path exists (was 4 ms)
    "astar_chunks_nopath": 7,        # ... and while we have none (was 6 ms)
    "astar_free_rays": 160,          # rays this tick before A* gives up chunks (was: 5 ms spent)
    "cover_guard_s": 0.015,          # wall-clock safety nets: never bind on a normal CPU
    "tick_guard_s": 0.020,
    # --- progress watchdog (B12, mech/brain.py `watchdog`): a goal we stop getting closer to is skipped (loot,
    # cube, explore, drop) or escaped from (zone, hold, retreat, heal). Unreachable goals (items on roofs,
    # partial A* paths, pockets on roofs) held the bot still for up to 150 s in 52 of 577 traced matches.
    "wd_on": True,
    "wd_stall_s": 4.0,               # no 1.5 m of progress for this long = stalled
    "wd_ban_s": 60.0,                # a stalled loot/explore/drop goal is skipped this long
    "wd_escape_s": 1.5,              # straight at a stalled zone/hold goal with jump and jets this long
    # --- misc
    "scan_period_s": 3.2,
    "debug_draw": True,
}


class Params(dict):
    def __getattr__(self, k):
        try:
            return self[k]
        except KeyError as e:
            raise AttributeError(k) from e


def load() -> Params:
    p = Params(json.loads(json.dumps(DEFAULTS)))
    path = os.environ.get("MECH_PARAMS")
    if path and os.path.exists(path):
        try:
            with open(path) as f:
                over = json.load(f)
            for k, v in over.items():
                if isinstance(v, dict) and isinstance(p.get(k), dict):
                    p[k].update(v)
                else:
                    p[k] = v
        except Exception:
            pass
    return p
