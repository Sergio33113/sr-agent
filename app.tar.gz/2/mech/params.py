"""Tunable behaviour parameters (not game rules: those come from hello.config).

Defaults are the shipped values. For local tuning only, MECH_PARAMS may point at a JSON file
whose keys override these (the simulator uses this; the match image never sets it).
"""
from __future__ import annotations

import json
import os

DEFAULTS = {
    # --- weapons and loadout
    "weapon_value": {"laser": 10.0, "lightning": 8.0, "mortar": 2.0, "gun": 5.0},
    "late_lightning_bonus": 4.0,     # lightning value bonus once the zone radius is small
    "late_radius": 140.0,            # "late game" when next_radius <= this
    "swap_margin": 2.5,              # value gain needed to swap a weapon
    "loot_detour_m": 90.0,           # max extra walk for loot when safe
    "cube_detour_m": 70.0,
    "crate_shoot_range": 150.0,
    "npc_hunt": True,
    "npc_hunt_range": 140.0,
    "npc_min_hp_frac": 0.8,          # only hunt drones when our hp fraction is above this
    # --- combat
    "aggression": 1.0,               # >1 fights more, <1 avoids more
    "engage_ratio": 1.15,            # fight if our kill time * ratio < theirs
    "retreat_hp_frac": 0.35,         # break off below this hp fraction when losing
    "kite_range_laser": 120.0,       # preferred distance with laser/gun and no lightning
    "close_range_lightning": 28.0,   # preferred distance when we hold lightning and they don't
    "lightning_energy_reserve": 12.0,
    "strafe_min_s": 0.35,
    "strafe_max_s": 1.1,
    "gun_aim_tol": 0.9,              # fire gun when aim error < tol * target angular radius
    "laser_aim_tol": 0.6,
    "laser_min_range": 0.0,
    "mortar_min_range": 25.0,
    "mortar_max_target_speed": 4.0,  # only lob at slow targets (or crates/NPCs)
    # --- zone and position
    "zone_margin": 18.0,             # stay this far inside the next circle
    "zone_hold_frac": 0.55,          # hold at this fraction of next radius from its centre
    "zone_lead_s": 8.0,              # leave this many seconds of slack when rotating
    "edge_cover_bonus": 1.0,
    # --- drops
    "drop_go": True,
    "drop_max_dist": 160.0,
    "drop_hp_frac": 0.0,             # go for drops only above this hp fraction (0 = always)
    # --- upgrades: base value per pick (diminishing with stacks)
    "upgrade_value": {
        "plating": 10.0, "nanites": 8.5, "armor": 8.0,
        "laser_damage": 8.5, "laser_charge": 6.0, "laser_pierce": 1.0,
        "gun_mag": 7.0, "gun_damage": 7.0, "gun_rate": 6.5, "gun_velocity": 4.5,
        "lightning_efficiency": 6.5, "lightning_range": 6.0, "lightning_chain": 3.5,
        "mortar_reload": 4.0, "mortar_velocity": 3.0, "mortar_splash": 3.0,
        "sensors": 5.0, "servos": 5.0, "gyros": 4.0, "reactor": 4.0, "capacitor": 3.5, "jets": 3.5,
    },
    # --- misc
    "scan_period_s": 3.2,
    "debug_draw": True,
}


class Params(dict):
    def __getattr__(self, k):
        try:
            return self[k]
        except KeyError as e:
            raise AttributeError(k) from e


def load() -> Params:
    p = Params(json.loads(json.dumps(DEFAULTS)))
    path = os.environ.get("MECH_PARAMS")
    if path and os.path.exists(path):
        try:
            with open(path) as f:
                over = json.load(f)
            for k, v in over.items():
                if isinstance(v, dict) and isinstance(p.get(k), dict):
                    p[k].update(v)
                else:
                    p[k] = v
        except Exception:
            pass
    return p
