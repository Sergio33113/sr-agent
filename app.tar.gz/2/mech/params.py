from __future__ import annotations
import json
import os
DEFAULTS = {'rng_salt': 4, 'weapon_value': {'laser': 10.0, 'lightning': 8.0, 'mortar': 2.0, 'gun': 5.0}, 'late_lightning_bonus': 4.0, 'late_radius': 140.0, 'swap_margin': 2.5, 'loot_detour_m': 90.0, 'cube_detour_m': 70.0, 'crate_shoot_range': 150.0, 'npc_hunt': True, 'npc_hunt_range': 140.0, 'npc_min_hp_frac': 0.8, 'fight_cube_m': 0.0, 'fight_cube_hp': 0.5, 'farm_regen_hp': 0.85, 'reload_below_frac': 0.6, 'squad_npc_min_hp_frac': 0.5, 'squad_npc_hunt_range': 170.0, 'squad_fight_cube_m': 60.0, 'squad_farm_regen_hp': 0.5, 'squad_reload_below_frac': 0.999, 'aggression': 1.0, 'engage_ratio': 1.15, 'retreat_hp_frac': 0.35, 'kite_range_laser': 120.0, 'close_range_lightning': 28.0, 'lightning_energy_reserve': 12.0, 'strafe_min_s': 0.35, 'strafe_max_s': 1.1, 'gun_aim_tol': 0.9, 'laser_aim_tol': 0.6, 'laser_min_range': 0.0, 'mortar_min_range': 25.0, 'mortar_max_target_speed': 4.0, 'zone_margin': 18.0, 'zone_hold_frac': 0.55, 'zone_lead_s': 8.0, 'edge_cover_bonus': 1.0, 'drop_go': True, 'drop_max_dist': 160.0, 'drop_hp_frac': 0.0, 'upgrade_value': {'plating': 10.0, 'nanites': 8.5, 'armor': 8.0, 'laser_damage': 8.5, 'laser_charge': 6.0, 'laser_pierce': 1.0, 'gun_mag': 7.0, 'gun_damage': 7.0, 'gun_rate': 6.5, 'gun_velocity': 4.5, 'lightning_efficiency': 6.5, 'lightning_range': 6.0, 'lightning_chain': 3.5, 'mortar_reload': 4.0, 'mortar_velocity': 3.0, 'mortar_splash': 3.0, 'sensors': 5.0, 'servos': 5.0, 'gyros': 4.0, 'reactor': 4.0, 'capacitor': 3.5, 'jets': 3.5}, 'gun_laser_always': True, 'gun_laser_unless_ffa': False, 'squad_lightning_value': 4.0, 'squad_mode': True, 'squad_after_s': 0.0, 'squad_no_retreat': False, 'squad_heal_below': 0.8, 'squad_fight_back': False, 'squad_dmg_upgrades': True, 'dodge_pred': True, 'squad_dodge_pred': True, 'dodge_all': True, 'squad_dodge_all': True, 'squad_upgrade_value': {'laser_damage': 12.0, 'gun_damage': 11.0, 'gun_rate': 10.5, 'lightning_efficiency': 10.0, 'laser_charge': 9.5, 'lightning_chain': 8.0, 'lightning_range': 7.5}, 'squad_gun_laser': False, 'squad_hyper': False, 'squad_smith_target': False, 'cover_ray_budget': 150, 'astar_chunks_path': 5, 'astar_chunks_nopath': 7, 'astar_free_rays': 160, 'cover_guard_s': 0.015, 'tick_guard_s': 0.02, 'wd_on': True, 'wd_stall_s': 4.0, 'wd_ban_s': 60.0, 'wd_escape_s': 1.5, 'scan_period_s': 3.2, 'debug_draw': True}

class Params(dict):

    def __getattr__(self, k):
        try:
            return self[k]
        except KeyError as a:
            raise AttributeError(k) from a

def load() -> Params:
    d = Params(json.loads(json.dumps(DEFAULTS)))
    g = os.environ.get('MECH_PARAMS')
    if g and os.path.exists(g):
        try:
            with open(g) as a:
                c = json.load(a)
            for (b, h) in c.items():
                if isinstance(h, dict) and isinstance(d.get(b), dict):
                    d[b].update(h)
                else:
                    d[b] = h
        except Exception:
            pass
    return d
