"""Aiming solutions. Pure functions, no state.

Conventions: yaw from +x counter-clockwise, pitch up-positive, positions are feet (x, y, z).
A shot leaves `radius + 0.5` m out along the aim from the muzzle, so a bullet travels on the
line through the muzzle point with a head start of that many metres.
"""
from __future__ import annotations

import math

G_DEFAULT = 22.0


def body_scale(cubes: float, size_per_cube: float = 0.05) -> float:
    return 1.0 + size_per_cube * (cubes or 0)


def predict(pos, vel, dt, arena=None, g=G_DEFAULT, damp=1.0):
    """Linear prediction of a mech's feet after dt (horizontal), simple ballistic vertical."""
    x = pos[0] + vel[0] * dt * damp
    y = pos[1] + vel[1] * dt * damp
    z = pos[2]
    vz = vel[2] if len(vel) > 2 else 0.0
    if abs(vz) > 0.3:
        z = pos[2] + vz * dt - 0.5 * g * dt * dt
        if arena is not None:
            f = arena.terrain(x, y)
            if z < f:
                z = f
    return x, y, z


def lead(shooter, tpos, tvel, speed, latency=0.05, head=3.0, aim_h=4.5, arena=None, damp=1.0, iters=4):
    """Intercept point for a straight projectile. Returns (x, y, z_aim, flight_time)."""
    sx, sy, sz = shooter
    t = latency
    X, Y, Z = tpos[0], tpos[1], tpos[2]
    for _ in range(iters):
        X, Y, Z = predict(tpos, tvel, t, arena, damp=damp)
        d = math.sqrt((X - sx) ** 2 + (Y - sy) ** 2 + (Z + aim_h - sz) ** 2)
        tf = max(0.0, d - head) / speed
        t = latency + tf
    return X, Y, Z + aim_h, t


def aim_to(shooter, px, py, pz):
    sx, sy, sz = shooter
    dx, dy = px - sx, py - sy
    return math.atan2(dy, dx), math.atan2(pz - sz, math.hypot(dx, dy))


def angular_radius(dist: float, radius: float) -> float:
    if dist < 1e-3:
        return math.pi
    return math.atan2(radius, dist)


def ballistic_pitch(D, H, v, g, high=False):
    """Pitch to hit a point D m away horizontally and H m above the launch point, or None."""
    if D < 0.5:
        return None
    a = g * D * D / (2 * v * v)
    disc = D * D - 4 * a * (H + a)
    if disc < 0:
        return None
    r = math.sqrt(disc)
    u = (D + r) / (2 * a) if high else (D - r) / (2 * a)
    return math.atan(u)


def mortar_solution(tube, target, v, g, head=3.0, high=False, min_pitch=-0.7, max_pitch=1.3):
    """(yaw, pitch, flight_time) for a shell from tube (x, y, z) to target (x, y, z), or None."""
    tx, ty, tz = target
    sx, sy, sz = tube
    yaw = math.atan2(ty - sy, tx - sx)
    D0 = math.hypot(tx - sx, ty - sy)
    H0 = tz - sz
    pitch = ballistic_pitch(D0, H0, v, g, high)
    if pitch is None:
        return None
    for _ in range(2):
        D = D0 - head * math.cos(pitch)
        H = H0 - head * math.sin(pitch)
        p2 = ballistic_pitch(max(0.6, D), H, v, g, high)
        if p2 is None:
            return None
        pitch = p2
    if pitch < min_pitch or pitch > max_pitch:
        return None
    D = D0 - head * math.cos(pitch)
    tf = D / max(1e-3, v * math.cos(pitch))
    return yaw, pitch, tf


def shell_impact(pos, vel, g, arena, max_t=8.0, dt=0.05):
    """Where and when a falling shell lands (terrain/roof column), simple stepping."""
    x, y, z = pos
    vx, vy, vz = vel
    t = 0.0
    while t < max_t:
        nx_, ny_ = x + vx * dt, y + vy * dt
        nz = z + vz * dt - 0.5 * g * dt * dt
        vz -= g * dt
        t += dt
        top = arena.col[arena.cell(nx_, ny_)] / 100.0
        if nz <= top:
            return nx_, ny_, max(nz, top), t
        x, y, z = nx_, ny_, nz
    return x, y, z, t


def closest_approach(ppos, pvel, qx, qy, qz, horizon):
    """Time and distance of the closest approach of a straight projectile to point q within horizon."""
    rx, ry, rz = qx - ppos[0], qy - ppos[1], qz - ppos[2]
    vv = pvel[0] ** 2 + pvel[1] ** 2 + pvel[2] ** 2
    if vv < 1e-6:
        return 0.0, math.sqrt(rx * rx + ry * ry + rz * rz)
    t = (rx * pvel[0] + ry * pvel[1] + rz * pvel[2]) / vv
    t = max(0.0, min(horizon, t))
    dx = rx - pvel[0] * t
    dy = ry - pvel[1] * t
    dz = rz - pvel[2] * t
    return t, math.sqrt(dx * dx + dy * dy + dz * dz)
