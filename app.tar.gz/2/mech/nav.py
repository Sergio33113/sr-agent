"""Ground navigation: a 2 m walkability grid in configuration space, A* with a node budget,
and path smoothing.

Walkable means a mech centre can stand there at ground level: no wall within radius + margin,
no head-height overhang, terrain slope under the limit. Roofs are not part of the ground graph.
Built at hello time from the Arena in well under a second (bit-parallel row operations).
"""
from __future__ import annotations

import heapq
import math

from .arena import Arena, CM

SQ2 = math.sqrt(2.0)


def _dilate_rows(rows, nbits, radius):
    """Morphological dilation of a bit-row image by a disc of `radius` cells."""
    mask = (1 << nbits) - 1
    R = int(math.floor(radius))
    widths = {}
    for dy in range(-R, R + 1):
        widths[dy] = int(math.floor(math.sqrt(max(0.0, radius * radius - dy * dy))))
    need = sorted(set(widths.values()))
    hcache = {}
    for w in need:
        hc = []
        for r in rows:
            acc = r
            for k in range(1, w + 1):
                acc |= (r << k) | (r >> k)
            hc.append(acc & mask)
        hcache[w] = hc
    n = len(rows)
    out = []
    for j in range(n):
        acc = 0
        for dy, w in widths.items():
            jj = j + dy
            if 0 <= jj < n:
                acc |= hcache[w][jj]
        out.append(acc)
    return out


class NavGrid:
    def __init__(self, arena: Arena, cell: float = 2.0, margin: float = 0.4):
        self.A = arena
        self.cs = cell
        A = arena
        nx, ny = A.nx, A.ny
        g = A.ground
        col, bld, over = A.col, A.bld, A.over
        step_cm = A.step_up * CM
        head_cm = A.mech_h * CM
        slope_lim = A.max_slope * 2 * CM  # central difference over 2 m, in cm
        # 1) obstacle bit rows at 1 m
        rows = []
        for j in range(ny):
            r = 0
            base = j * nx
            jm = base - nx if j > 0 else base
            jp = base + nx if j < ny - 1 else base
            for i in range(nx):
                c = base + i
                gc = g[c]
                blocked = False
                if bld[c] and col[c] - gc > step_cm:
                    blocked = True
                else:
                    lst = over.get(c)
                    if lst:
                        for b, t in lst:
                            if b < gc + head_cm and t > gc + step_cm:
                                blocked = True
                                break
                    if not blocked:
                        il = c - 1 if i > 0 else c
                        ir = c + 1 if i < nx - 1 else c
                        sx = g[ir] - g[il]
                        sy = g[jp + i] - g[jm + i]
                        if sx * sx + sy * sy > slope_lim * slope_lim:
                            blocked = True
                if blocked:
                    r |= 1 << i
            rows.append(r)
        # map edge is a wall
        full = (1 << nx) - 1
        rows[0] = full
        rows[-1] = full
        edge = 1 | (1 << (nx - 1))
        rows = [r | edge for r in rows]
        self.obst_rows = rows
        # 2) configuration space: dilate by radius + margin
        rad = A.mech_r + margin
        cs_rows = _dilate_rows(rows, nx, rad)
        self.cspace_rows = cs_rows
        # 3) sample to the nav grid
        k = int(round(cell))
        self.k = k
        self.gx = (nx + k - 1) // k
        self.gy = (ny + k - 1) // k
        gx, gy = self.gx, self.gy
        free = bytearray(gx * gy)
        for J in range(gy):
            r = cs_rows[min(ny - 1, J * k)]
            row = J * gx
            for I in range(gx):
                if not (r >> min(nx - 1, I * k)) & 1:
                    free[row + I] = 1
        self.free = free
        self.cost = None  # optional per-node extra cost (bytearray, units of 0.1 cell)
        # "near cover": free nav cells within ~14 m of a wall (a building to duck behind)
        near_rows = _dilate_rows(rows, nx, 14.0)
        cover = bytearray(gx * gy)
        for J in range(gy):
            r = near_rows[min(ny - 1, J * k)]
            row = J * gx
            for I in range(gx):
                if free[row + I] and (r >> min(nx - 1, I * k)) & 1:
                    cover[row + I] = 1
        self.cover = cover

    # ---------------------------------------------------------------- coordinates
    def node(self, x: float, y: float) -> int:
        I = int(round((x - self.A.x0) / self.k))
        J = int(round((y - self.A.y0) / self.k))
        I = 0 if I < 0 else (self.gx - 1 if I >= self.gx else I)
        J = 0 if J < 0 else (self.gy - 1 if J >= self.gy else J)
        return J * self.gx + I

    def pos(self, n: int):
        J, I = divmod(n, self.gx)
        return self.A.x0 + I * self.k, self.A.y0 + J * self.k

    def nearest_cover(self, x: float, y: float, max_r: int = 12):
        """Nearest free nav node next to a wall (within max_r nodes), else nearest free."""
        n = self.node(x, y)
        if self.cover[n]:
            return n
        J0, I0 = divmod(n, self.gx)
        for r in range(1, max_r + 1):
            best, bd = None, 1e18
            for dJ in range(-r, r + 1):
                for dI in (-r, r) if abs(dJ) != r else range(-r, r + 1):
                    I, J = I0 + dI, J0 + dJ
                    if 0 <= I < self.gx and 0 <= J < self.gy and self.cover[J * self.gx + I]:
                        d = dI * dI + dJ * dJ
                        if d < bd:
                            bd, best = d, J * self.gx + I
            if best is not None:
                return best
        return self.nearest_free(x, y, max_r)

    def is_free(self, x: float, y: float) -> bool:
        return bool(self.free[self.node(x, y)])

    def cspace_free(self, x: float, y: float) -> bool:
        A = self.A
        i = int(x - A.x0 + 0.5)
        j = int(y - A.y0 + 0.5)
        if not (0 <= i < A.nx and 0 <= j < A.ny):
            return False
        return not (self.cspace_rows[j] >> i) & 1

    def nearest_free(self, x: float, y: float, max_r: int = 12):
        n = self.node(x, y)
        if self.free[n]:
            return n
        J0, I0 = divmod(n, self.gx)
        best, bd = None, 1e18
        for r in range(1, max_r + 1):
            for dJ in range(-r, r + 1):
                for dI in (-r, r) if abs(dJ) != r else range(-r, r + 1):
                    I, J = I0 + dI, J0 + dJ
                    if 0 <= I < self.gx and 0 <= J < self.gy and self.free[J * self.gx + I]:
                        d = dI * dI + dJ * dJ
                        if d < bd:
                            bd, best = d, J * self.gx + I
            if best is not None:
                return best
        return None

    def segment_free(self, ax, ay, bx, by) -> bool:
        """Straight walk a->b stays in free configuration space (1 m resolution, sampled)."""
        d = math.hypot(bx - ax, by - ay)
        nstep = int(d / 0.8) + 1
        rows = self.cspace_rows
        A = self.A
        for s in range(nstep + 1):
            t = s / nstep
            i = int(ax + (bx - ax) * t - A.x0 + 0.5)
            j = int(ay + (by - ay) * t - A.y0 + 0.5)
            if not (0 <= i < A.nx and 0 <= j < A.ny) or (rows[j] >> i) & 1:
                return False
        return True

    # ---------------------------------------------------------------- search
    def astar(self, sx, sy, tx, ty, budget=60000, goal_radius=0.0):
        """Path of world points from (sx, sy) to (tx, ty), or None. If the budget runs out,
        returns the partial path to the expanded node closest to the goal."""
        s = self.nearest_free(sx, sy)
        t = self.nearest_free(tx, ty)
        if s is None or t is None:
            return None
        gx = self.gx
        free = self.free
        cost = self.cost
        TJ, TI = divmod(t, gx)
        gr2 = (goal_radius / self.k) ** 2
        openh = [(0.0, 0.0, s)]
        gsc = {s: 0.0}
        parent = {s: -1}
        closed = set()
        best, bestd = s, 1e18
        nb = ((1, 0, 1.0), (-1, 0, 1.0), (0, 1, 1.0), (0, -1, 1.0),
              (1, 1, SQ2), (1, -1, SQ2), (-1, 1, SQ2), (-1, -1, SQ2))
        exp = 0
        found = None
        while openh:
            f, gcur, n = heapq.heappop(openh)
            if n in closed:
                continue
            closed.add(n)
            J, I = divmod(n, gx)
            dI = abs(I - TI)
            dJ = abs(J - TJ)
            if n == t or (gr2 and dI * dI + dJ * dJ <= gr2):
                found = n
                break
            h = (dI + dJ) + (SQ2 - 2) * (dI if dI < dJ else dJ)
            if h < bestd:
                bestd, best = h, n
            exp += 1
            if exp > budget:
                break
            for di, dj, c in nb:
                I2, J2 = I + di, J + dj
                if I2 < 0 or J2 < 0 or I2 >= gx or J2 >= self.gy:
                    continue
                m = J2 * gx + I2
                if not free[m] or m in closed:
                    continue
                if di and dj and not (free[J * gx + I2] and free[J2 * gx + I]):
                    continue
                g2 = gcur + c
                if cost is not None:
                    g2 += cost[m] * 0.1
                if g2 < gsc.get(m, 1e18):
                    gsc[m] = g2
                    parent[m] = n
                    eI = abs(I2 - TI)
                    eJ = abs(J2 - TJ)
                    h2 = (eI + eJ) + (SQ2 - 2) * (eI if eI < eJ else eJ)
                    heapq.heappush(openh, (g2 + h2 * 1.001, g2, m))
        end = found if found is not None else best
        path = []
        n = end
        while n != -1:
            path.append(self.pos(n))
            n = parent[n]
        path.reverse()
        if found is not None and goal_radius <= 0:
            path[-1] = (tx, ty) if self.cspace_free(tx, ty) else path[-1]
        return self.smooth(path, sx, sy), found is not None

    def astar_iter(self, sx, sy, tx, ty, chunk=600):
        """Resumable A*: a generator that yields None after every `chunk` expansions and finally
        yields (smoothed path, found). Lets the bot spread a long search over several ticks."""
        s = self.nearest_free(sx, sy)
        t = self.nearest_free(tx, ty)
        if s is None or t is None:
            yield ([(tx, ty)], False)
            return
        gx, gy = self.gx, self.gy
        free = self.free
        TJ, TI = divmod(t, gx)
        openh = [(0.0, 0.0, s)]
        gsc = {s: 0.0}
        parent = {s: -1}
        closed = set()
        best, bestd = s, 1e18
        nb = ((1, 0, 1.0), (-1, 0, 1.0), (0, 1, 1.0), (0, -1, 1.0),
              (1, 1, SQ2), (1, -1, SQ2), (-1, 1, SQ2), (-1, -1, SQ2))
        found = None
        exp = 0
        total = 0
        while openh:
            f, gcur, n = heapq.heappop(openh)
            if n in closed:
                continue
            closed.add(n)
            if n == t:
                found = n
                break
            J, I = divmod(n, gx)
            dI = abs(I - TI)
            dJ = abs(J - TJ)
            h = (dI + dJ) + (SQ2 - 2) * (dI if dI < dJ else dJ)
            if h < bestd:
                bestd, best = h, n
            exp += 1
            total += 1
            if total > 120000:
                break
            if exp >= chunk:
                exp = 0
                yield None
            for di, dj, c in nb:
                I2, J2 = I + di, J + dj
                if I2 < 0 or J2 < 0 or I2 >= gx or J2 >= gy:
                    continue
                m = J2 * gx + I2
                if not free[m] or m in closed:
                    continue
                if di and dj and not (free[J * gx + I2] and free[J2 * gx + I]):
                    continue
                g2 = gcur + c
                if g2 < gsc.get(m, 1e18):
                    gsc[m] = g2
                    parent[m] = n
                    eI = abs(I2 - TI)
                    eJ = abs(J2 - TJ)
                    h2 = (eI + eJ) + (SQ2 - 2) * (eI if eI < eJ else eJ)
                    heapq.heappush(openh, (g2 + h2 * 1.001, g2, m))
        end = found if found is not None else best
        path = []
        n = end
        while n != -1:
            path.append(self.pos(n))
            n = parent[n]
        path.reverse()
        if found is not None and self.cspace_free(tx, ty):
            path[-1] = (tx, ty)
        yield (path, found is not None)

    def smooth(self, path, sx, sy):
        """String-pulling: from each kept point, jump to the farthest of the next ~40 points that is
        reachable in a straight free line (forward scan with stride, cheap)."""
        if not path:
            return path
        pts = [(sx, sy)] + list(path[1:]) if self.cspace_free(sx, sy) else list(path)
        out = [pts[0]]
        i = 0
        n = len(pts)
        while i < n - 1:
            j = i + 1
            k = i + 3
            lim = min(n - 1, i + 40)
            while k <= lim and self.segment_free(pts[i][0], pts[i][1], pts[k][0], pts[k][1]):
                j = k
                k += 3
            if j < lim and j + 1 <= lim and self.segment_free(pts[i][0], pts[i][1], pts[min(lim, j + 1)][0], pts[min(lim, j + 1)][1]):
                j = min(lim, j + 1)
            out.append(pts[j])
            i = j
        return out
