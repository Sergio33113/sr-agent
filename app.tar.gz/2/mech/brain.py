from __future__ import annotations
import gc
import math
import random
import time
from . import gunnery as gn
from .arena import Arena
from .geometry import adiff, bearing, clamp, d2, unit, wrap
from .nav import NavGrid
from .params import load as load_params
from .world import World
try:
    import mechfight as _mf
except Exception:
    _mf = None
_OPEN_DIRS = tuple(((math.cos(k * math.pi / 8.0), math.sin(k * math.pi / 8.0)) for k in range(16)))
HOLD_RANGES = (22.0, 35.0, 50.0, 70.0, 95.0, 125.0, 160.0, 200.0)

class Intent:
    __slots__ = ('mode', 'goal', 'target', 'shoot', 'dist_pref', 'strafe', 'boost', 'face', 'pickup', 'note', 'evasive')

    def __init__(self, mode, goal=None, target=None, shoot=None, dist_pref=None, strafe=False, boost=False, face=None, pickup=None, note=''):
        (self.mode, self.goal, self.target, self.shoot) = (mode, goal, target, shoot)
        (self.dist_pref, self.strafe, self.boost, self.face) = (dist_pref, strafe, boost, face)
        (self.pickup, self.note) = (pickup, note)
        self.evasive = False

class Brain:
    name = 'OSU Ironclad'

    def __init__(self, hello: dict):
        self.cfg = f = hello['config']
        self.P = load_params()
        self.slot = int(hello.get('slot', 0))
        self.rng = random.Random(hello.get('seed', 0) or 0)
        j = (hello.get('map') or {}).get('dir', '/arena')
        self.A = Arena(j, f.get('mech', {}))
        self.N = NavGrid(self.A)
        self.W = World(f, self.slot)
        self.mc = f.get('mech', {})
        self.wc = f.get('weapons', {})
        self.zc = f.get('zone', {})
        self.loot_reach = float(f.get('loot', {}).get('pickup_radius', 4.0))
        self.cube_reach = float(f.get('cubes', {}).get('pickup_radius', 3.5))
        self.size_per_cube = float(f.get('cubes', {}).get('size_per_cube', 0.05))
        self.dmg_per_cube = float(f.get('cubes', {}).get('damage_per_cube', 0.04))
        self.cube_cap = float(f.get('cubes', {}).get('stat_cap', 10))
        self.rear_mult = float(self.mc.get('rear_mult', 1.5))
        self.path = []
        self.path_goal = None
        self.path_t = -99.0
        self.search = None
        self.search_goal = None
        self.strafe_dir = 1 if self.rng.random() < 0.5 else -1
        self.strafe_until = 0.0
        self.fb_on = False
        self.stuck_since = None
        self.unstick_until = -1.0
        self.unstick_dir = (0.0, 0.0)
        self.last_move = (0.0, 0.0)
        self.wd_key = None
        self.wd_best = 1000000000.0
        self.wd_t = 0.0
        self.wd_escapes = 0
        self.bad_goals = []
        self.bad_count = {}
        self.escape_until = -1.0
        self.escape_dir = (0.0, 0.0)
        self.target_id = None
        self.los_seen = {}
        self.evade = False
        self.retreating = False
        self.squad = False
        self.retreat_spot = None
        self.retreat_spot_t = -99.0
        self.gate = False
        self.gate_from = 0.0
        self.ghost_t = -99.0
        self.ghost_spot = (-99.0, None)
        self.snug = None
        self.snug_t = -99.0
        self.snug_done = False
        self.snug_since = (None, 0.0)
        self.open_cache = {}
        self.open_budget = 0
        self.laser_hold_start = None
        self.last_fire_t = -99.0
        self.phase_from = None
        self.hold = None
        self.hold_t = -99.0
        self.hold_key = None
        self.loot_goal = None
        self.blacklist = {}
        self.visited = set()
        self.explore_target = None
        self.explore_t = -99.0
        self.ticks = 0
        self.act_ms = 0.0
        gc.collect()
        try:
            gc.freeze()
        except AttributeError:
            pass
        gc.disable()

    def act(self, obs: dict) -> dict:
        try:
            return self._act(obs)
        except Exception as f:
            self.errors = getattr(self, 'errors', 0) + 1
            if self.errors <= 5 or self.errors % 200 == 0:
                import sys
                import traceback
                print(f"act error #{self.errors} at t={obs.get('t')}: {f!r}\n{traceback.format_exc()}", file=sys.stderr, flush=True)
            self.path = []
            self.search = None
            return self.safe_act(obs)

    def safe_act(self, obs: dict) -> dict:
        a0 = obs['self']
        (i0, j0, k0) = a0['pos']
        l0 = obs['zone']['next_center']
        (b0, d0) = unit(l0[0] - i0, l0[1] - j0)
        if d2(i0, j0, l0[0], l0[1]) < 0.4 * obs['zone']['next_radius']:
            b0 = d0 = 0.0
        try:
            self.pos = a0['pos']
            if b0 or d0:
                (b0, d0) = self.steer(b0, d0)
        except Exception:
            pass
        f = {'move': [b0, d0], 'boost': not a0.get('in_zone', True), 'aim': [math.atan2(d0, b0) if b0 or d0 else a0['aim'][0], 0.0]}
        j = None
        for q in obs.get('mechs') or []:
            if q.get('kind') != 'mech':
                continue
            l = math.dist(q['pos'][:2], (i0, j0))
            if j is None or l < j[0]:
                j = (l, q)
        if j is not None and j[0] < 200:
            (e0, g0, h0) = j[1]['pos']
            f['aim'] = [math.atan2(g0 - j0, e0 - i0), math.atan2(h0 + 4.5 - k0 - 7.0, max(1.0, j[0]))]
            f['fire'] = [True, True]
        if obs.get('offer'):
            f['pick'] = 0
        return f

    def _act(self, obs: dict) -> dict:
        n0 = time.perf_counter()
        self.tick_t0 = n0
        self.rays0 = self.A.rays
        self.ticks += 1
        f = self.W
        f.update(obs)
        self.obs = obs
        g0 = obs['self']
        self.me = g0
        self.t = m0 = obs['t']
        self.pos = g0['pos']
        self.hpf = g0['hp'] / max(1.0, g0['max_hp'])
        self.scale = gn.body_scale(g0.get('cubes', 0), self.size_per_cube)
        l0 = g0.get('stats') or {}
        self.walk = float(l0.get('walk_speed', self.mc.get('walk_speed', 11.7)))
        self.muzzle_h = float(l0.get('muzzle_height', self.mc.get('muzzle_height', 7.0) * self.scale))
        self.eye_h = float(l0.get('eye_height', self.mc.get('eye_height', 8.0) * self.scale))
        self.weap = g0.get('weapons') or [None, None]
        self.kinds = [w['kind'] if w else None for w in self.weap]
        self.squad = bool(self.P.get('squad_mode')) and (not f.is_ffa()) and (m0 >= self.P.get('squad_after_s', 30.0))
        j: dict = {}
        if obs.get('offer'):
            j0 = self.pick_upgrade(obs['offer'])
            if j0 is not None:
                j['pick'] = j0
        self.zone_update(obs['zone'])
        self.los_cache = {}
        d0 = self.decide()
        if self.P.get('wd_on', True):
            self.watchdog(d0)
        self.return_fire(d0)
        (i0, q, e0) = self.pilot(d0)
        (l, b0, k0) = self.gunnery(d0)
        h0 = math.hypot(i0[0], i0[1])
        if h0 > 0.9999:
            i0 = (i0[0] * 0.9999 / h0, i0[1] * 0.9999 / h0)
        j['move'] = [round(i0[0], 4), round(i0[1], 4)]
        j['boost'] = bool(q)
        j['jump'] = bool(e0)
        j['aim'] = [round(l[0], 5), round(l[1], 5)]
        j['fire'] = b0
        if k0:
            j['reload'] = True
        self.loot_actions(d0, j)
        self.intent = d0
        a0 = (time.perf_counter() - n0) * 1000.0
        self.act_ms = a0
        if self.P.get('debug_draw') and _mf is not None:
            try:
                o0 = d0.target.id if d0.target is not None else '-'
                _mf.draw.label(f'{d0.mode} {o0} hp{self.hpf:.2f} {d0.note}'[:78])
            except Exception:
                pass
        if self.ticks % 150 == 0 and a0 < 8.0:
            gc.collect(0)
        return j

    def circle_at(self, z, t):
        (d0, b0) = (z['shrink_start'], z['shrink_end'])
        (f, l) = (z['center'], z['radius'])
        (j, q) = (z['next_center'], z['next_radius'])
        if self.phase_from is not None and self.phase_from[0] == d0:
            (f, l) = (self.phase_from[1], self.phase_from[2])
        if t <= d0:
            return (f, l)
        if t >= b0:
            return (j, q)
        a0 = (t - d0) / max(1e-06, b0 - d0)
        return ((f[0] + (j[0] - f[0]) * a0, f[1] + (j[1] - f[1]) * a0), l + (q - l) * a0)

    def zone_update(self, z):
        p0 = self.t
        if p0 < z['shrink_start']:
            self.phase_from = (z['shrink_start'], tuple(z['center']), z['radius'])
        (v0, w0) = (self.pos[0], self.pos[1])
        (q, m0) = (z['next_center'], z['next_radius'])
        self.zn = (q, m0)
        self.zcur = self.circle_at(z, p0)
        h0 = min(self.P.zone_margin, 0.3 * m0)
        a0 = d2(v0, w0, q[0], q[1])
        self.inside_next = a0 <= m0 - h0
        if a0 <= m0:
            q0 = 1000000000.0
        else:
            (o0, n0) = (z['shrink_start'], z['shrink_end'])
            (g0, d0) = (0.0, 1.0)
            (l, l0) = self.circle_at(z, o0)
            b0 = l0 - d2(v0, w0, l[0], l[1])
            if b0 <= 0:
                q0 = p0
            else:
                for f in range(18):
                    i0 = 0.5 * (g0 + d0)
                    s0 = o0 + (n0 - o0) * i0
                    (j, k0) = self.circle_at(z, s0)
                    if k0 - d2(v0, w0, j[0], j[1]) > 0:
                        g0 = i0
                    else:
                        d0 = i0
                q0 = o0 + (n0 - o0) * g0
        j0 = max(0.0, a0 - (m0 - h0))
        u0 = j0 / max(1.0, self.walk) * 1.3
        self.zone_slack = q0 - p0 - u0
        self.outside = not self.me.get('in_zone', True)
        self.zone_dps = z.get('dps', 0.0)
        e0 = (round(q[0], 1), round(q[1], 1), m0)
        if e0 != self.hold_key or p0 - self.hold_t > 4.0 or self.hold is None:
            self.hold_key = e0
            self.hold_t = p0
            self.hold = self.pick_hold(q, m0)

    def pick_hold(self, cn, rn):
        (k0, l0) = (self.pos[0], self.pos[1])
        if rn <= 1.0:
            b0 = self.N.nearest_free(cn[0], cn[1], 20)
            return self.N.pos(b0) if b0 is not None else (cn[0], cn[1])
        l = self.P.zone_hold_frac
        if rn <= 75:
            l = 0.3
        if rn <= 30:
            l = 0.15
        j = d2(k0, l0, cn[0], cn[1])
        (i0, j0) = unit(k0 - cn[0], l0 - cn[1])
        if i0 == 0 and j0 == 0:
            (i0, j0) = (1.0, 0.0)
        g0 = min(j, l * rn)
        f = self.N
        if j <= l * rn + 8 and f.is_free(k0, l0) and f.cover[f.node(k0, l0)]:
            return (k0, l0)
        (q, a0) = (cn[0] + i0 * g0, cn[1] + j0 * g0)
        h0 = max(3, min(12, int(0.12 * rn / f.k)))
        b0 = f.nearest_cover(q, a0, h0)
        if b0 is not None:
            (d0, e0) = f.pos(b0)
            if d2(d0, e0, cn[0], cn[1]) > rn - min(self.P.zone_margin, 0.3 * rn):
                b0 = None
        if b0 is None:
            b0 = f.nearest_free(q, a0, 15)
        if b0 is None:
            b0 = self.N.nearest_free(cn[0], cn[1], 25)
        return self.N.pos(b0) if b0 is not None else (cn[0], cn[1])

    def in_safe(self, px, py, slack_m=0.0):
        (j, a0) = self.zn
        (f, q) = self.zcur
        l = d2(px, py, f[0], f[1]) <= q - 2
        return l and (d2(px, py, j[0], j[1]) <= a0 - slack_m or self.zone_slack > 15)

    def los_to(self, tr, eye=False):
        j = (tr.id, eye)
        h0 = self.los_cache.get(j)
        if h0 is not None:
            return h0
        (i0, j0, k0) = self.pos
        g0 = k0 + (self.eye_h if eye else self.muzzle_h)
        l = getattr(tr, 'kind', 'mech') == 'mech'
        e0 = gn.body_scale(getattr(tr, 'cubes', 0), self.size_per_cube) if l else 1.0
        f = 9.0 * e0 if l else 3.5
        d0 = 2.5 * e0 if l else 1.8
        (q, a0, b0) = tr.pos
        h0 = self.exposed_point(i0, j0, g0, q, a0, b0, f, d0) is not None
        self.los_cache[j] = h0
        return h0

    def exposed_point(self, sx, sy, sz, px, py, pz, h, r):
        f = self.A
        (d0, e0) = unit(px - sx, py - sy)
        (j, l) = (-e0 * r * 0.75, d0 * r * 0.75)
        for (a0, b0, q) in ((0.0, 0.0, 0.5), (0.0, 0.0, 0.82), (j, l, 0.5), (-j, -l, 0.5), (j, l, 0.82), (-j, -l, 0.82)):
            if f.los(sx, sy, sz, px + a0, py + b0, pz + q * h):
                return (a0, b0, q * h)
        return None

    def their_los_to_point(self, tr, px, py, pz):
        (f, j, l) = tr.pos
        q = l + 8.0 * gn.body_scale(tr.cubes, self.size_per_cube)
        return self.exposed_point(f, j, q, px, py, pz, 9.0 * self.scale, 2.5 * self.scale) is not None

    def sq(self, key, default):
        if getattr(self, 'squad', False):
            f = self.P.get('squad_' + key)
            if f is not None:
                return f
        return self.P.get(key, default)

    def sqk(self, key, default):
        if getattr(self, 'squad', False) and self.t >= self.P.get('sqk_after_s', 30.0):
            f = self.P.get('squad_' + key)
            if f is not None:
                return f
        return default

    def ffa_on(self, key):
        return bool(self.P.get(key)) and self.W.is_ffa() and (self.W.ffa_sure() or not self.P.get('ffa_need_sure', True))

    def hit_by(self, tr, window):
        l = self.t
        if l - tr.last_hit_me < window:
            return True
        for (q, f, j, a0) in reversed(self.W.dmg_taken_log[-40:]):
            if l - q >= window:
                break
            if j == tr.id:
                return True
        return False

    def ffa_provoked(self, tr, d):
        if self.hit_by(tr, self.P.get('ffa_hit_s', 4.0)):
            return True
        if tr.charging and d < 130.0:
            f = bearing(tr.pos[0], tr.pos[1], self.pos[0], self.pos[1])
            return abs(adiff(tr.aim[0], f)) < 0.22
        return False

    def closing_on_us(self, tr, d):
        if d >= 180.0 or d < 1.0:
            return d < 1.0
        f = tr.vel or (0.0, 0.0, 0.0)
        return -((tr.pos[0] - self.pos[0]) * f[0] + (tr.pos[1] - self.pos[1]) * f[1]) / d > 3.0

    def ffa_open_ok(self, tr, d, adv, busy):
        f = self.P
        q = tr.hp / max(1.0, tr.max_hp)
        if d < f.get('ffa_gate_close_m', 60.0) and self.hpf > (0.3 if d < 45.0 else 0.45) and self.los_to(tr):
            l = bearing(tr.pos[0], tr.pos[1], self.pos[0], self.pos[1])
            if d < f.get('ffa_gate_bump_m', 30.0) or abs(adiff(tr.aim[0], l)) < 0.6:
                return 'close'
        if q < f.get('ffa_gate_weak', 0.5) and self.hpf >= f.get('ffa_gate_weak_hp', 0.6):
            return 'weak'
        if busy and q < 0.9 and (self.hpf >= f.get('ffa_gate_busy_hp', 0.75)) and (d < f.get('ffa_gate_busy_m', 170.0)) and (adv > 0.6):
            return 'busy'
        j = self.obs.get('alive', 16)
        if self.hpf >= 0.8 and adv > f.engage_ratio:
            if q < 0.8 and j <= f.get('ffa_gate_hurt_alive', 10):
                return 'hurt'
            if j <= f.get('ffa_gate_edge_alive', 6) and 'laser' in self.kinds and ('laser' not in (tr.weapons or [])):
                return 'edge'
        return None

    def ffa_loot_risky(self, px, py):
        f = self.P
        if d2(self.pos[0], self.pos[1], px, py) <= f.get('ffa_loot_near_m', 25.0):
            return False
        (j, l) = (f.get('ffa_loot_mech_m', 110.0), f.get('ffa_loot_mech_s', 20.0))
        for q in self.W.mechs.values():
            if self.t - q.last_seen < l and d2(q.pos[0], q.pos[1], px, py) < j:
                return True
        return False

    def openness(self, px, py):
        a0 = self.N
        l0 = a0.node(px, py)
        m0 = self.open_cache.get(l0)
        if m0 is not None:
            return m0
        if self.open_budget <= 0:
            return None
        self.open_budget -= 1
        (j0, k0, i0) = (a0.gx, a0.gy, a0.free)
        (q, j) = divmod(l0, j0)
        m0 = 0
        for (d0, e0) in _OPEN_DIRS:
            (g0, h0) = (float(j), float(q))
            for b0 in range(60):
                g0 += d0
                h0 += e0
                (f, l) = (int(g0 + 0.5), int(h0 + 0.5))
                if f < 0 or l < 0 or f >= j0 or (l >= k0) or (not i0[l * j0 + f]):
                    break
                m0 += 1
        self.open_cache[l0] = m0
        return m0

    def snug_spot(self):
        p0 = self.t
        (q0, s0) = (self.pos[0], self.pos[1])
        j0 = min(self.P.zone_margin, 0.3 * self.zn[1])
        b0 = self.snug
        if b0 is not None:
            if self.snug_since[0] != b0:
                self.snug_since = (b0, p0)
            e0 = d2(q0, s0, b0[0], b0[1]) > 6.0
            if e0 and p0 - self.snug_since[1] > 12.0:
                self.bad_goals.append((b0[0], b0[1], p0 + 60.0))
            if not e0:
                self.snug_since = (b0, p0)
            if not self.in_safe(b0[0], b0[1], j0) or self.goal_bad(b0[0], b0[1]):
                b0 = self.snug = None
        if b0 is not None and self.snug_done and (p0 - self.snug_t < 6.0):
            return b0
        (g0, h0) = self.hold
        f = self.N
        self.open_budget = 8
        a0 = [(g0, h0)]
        if b0 is not None:
            a0.append(b0)
        for n0 in (14.0, 28.0, 42.0):
            for i0 in range(8):
                j = i0 * (math.pi / 4.0) + n0 * 0.03
                a0.append((g0 + n0 * math.cos(j), h0 + n0 * math.sin(j)))
        (l, q, d0) = (None, 1e+18, True)
        for (l0, m0) in a0:
            if not f.is_free(l0, m0) or not f.cspace_free(l0, m0) or (not self.in_safe(l0, m0, j0)) or self.goal_bad(l0, m0):
                continue
            k0 = self.openness(l0, m0)
            if k0 is None:
                d0 = False
                continue
            o0 = k0 + 0.25 * d2(q0, s0, l0, m0)
            if b0 is not None and l0 == b0[0] and (m0 == b0[1]):
                o0 -= 25.0
            if o0 < q:
                (q, l) = (o0, (l0, m0))
        if l is not None:
            self.snug = l
        (self.snug_t, self.snug_done) = (p0, d0)
        return self.snug

    def cube_mult(self, cubes):
        return 1.0 + self.dmg_per_cube * min(cubes or 0, self.cube_cap)

    def weapon_dps(self, kind, d, stats=None, cubes=0, vs_mortar=False, energy=100.0):
        h0 = stats or self.wc.get(kind, {})
        a0 = self.cube_mult(cubes)
        if kind == 'gun':
            e0 = h0.get('range', 230)
            if d > e0:
                return 0.0
            f = max(0.05, h0.get('cooldown', 0.24))
            b0 = h0.get('mag', 12)
            g0 = b0 * f / (b0 * f + h0.get('reload', 2.4))
            q = clamp(1.05 - d / 240.0, 0.12, 0.95)
            return h0.get('damage', 45) / f * g0 * q * a0
        if kind == 'laser':
            if d > h0.get('range', 280):
                return 0.0
            j = h0.get('charge', 0.75) + h0.get('cooldown', 1.65)
            l = h0.get('damage', 315) * (1.0 + (h0.get('cookoff', 0.6) if vs_mortar else 0.0))
            return l / j * 0.9 * a0
        if kind == 'lightning':
            if d > h0.get('range', 45) * 0.95:
                return 0.0
            d0 = 1.0 if energy > 20 else 0.4
            return h0.get('damage', 60) / max(0.05, h0.get('cooldown', 0.25)) * 0.95 * d0 * a0
        if kind == 'mortar':
            if d < 18 or d > 225:
                return 0.0
            return (h0.get('damage', 200) * 0.5 + h0.get('splash', 160) * 0.5) / h0.get('cooldown', 2.6) * 0.3 * a0
        return 0.0

    def behind(self, tr):
        f = bearing(tr.pos[0], tr.pos[1], self.pos[0], self.pos[1])
        return abs(adiff(tr.aim[0], f)) > 0.5 * math.radians(self.mc.get('front_arc_deg', 180.0))

    def exposed_to(self, tr):
        f = bearing(self.pos[0], self.pos[1], tr.pos[0], tr.pos[1])
        return abs(adiff(self.me['aim'][0], f)) > 0.5 * math.radians(self.mc.get('front_arc_deg', 180.0))

    def my_dps(self, d, tr=None):
        f = 0.0
        j = tr is not None and 'mortar' in (tr.weapons or [])
        for l in self.weap:
            if l:
                f += self.weapon_dps(l['kind'], d, l.get('stats'), self.me.get('cubes', 0), j, self.me.get('energy', 100))
        if tr is not None and getattr(tr, 'kind', 'mech') == 'mech' and self.behind(tr):
            f *= self.rear_mult
        return f

    def their_dps(self, tr, d, facing_them=True):
        l = 0.0
        j = 'mortar' in self.kinds
        for f in tr.weapons or ['gun']:
            l += self.weapon_dps(f, d, None, tr.cubes, j)
        if not facing_them:
            l *= self.rear_mult
        return l

    def decide(self) -> Intent:
        W = self.W
        f = self.P
        t = self.t
        (x, y, z) = self.pos
        g1 = self.me
        enemies = []
        for tr in W.mechs.values():
            if not tr.listed:
                continue
            d = d2(x, y, tr.pos[0], tr.pos[1])
            if d > 260:
                continue
            enemies.append((d, tr))
        enemies.sort(key=lambda e: e[0])
        self.enemies = enemies
        u0 = self.ffa_on('ffa_gate') and self.obs.get('alive', 16) > f.get('ffa_gate_off_alive', 2)
        self.gate_from = 0.0
        if not u0 and f.get('ffa_gate') and (t < f.get('ffa_unknown_s', 0.0)) and (not W.is_ffa()):
            u0 = True
            self.gate_from = f.get('ffa_unknown_m', 0.0)
        self.gate = u0
        hostile = []
        for (d, tr) in enemies:
            e1 = self.los_to(tr, eye=True)
            g0 = bearing(tr.pos[0], tr.pos[1], x, y)
            q = abs(adiff(tr.aim[0], g0)) < 0.35
            p1 = t - tr.last_hit_me < 3.0
            if e1 and (q or p1 or d < 60):
                hostile.append((d, tr))
        self.hostile = hostile
        a1 = W.recent_damage(2.5)
        i1 = sum((1 for (d, tr) in hostile if d < 130))
        z1 = False
        if self.hpf < f.retreat_hp_frac + 0.1 and (hostile or a1 > 0):
            z1 = True
        if i1 >= 2 and self.hpf < 0.7:
            z1 = True
        if i1 >= 3 and self.hpf < 0.85:
            z1 = True
        if z1 and len(hostile) == 1:
            (d, tr) = hostile[0]
            k1 = self.my_dps(d, tr)
            w1 = self.their_dps(tr, d)
            if k1 > 1 and tr.hp / k1 < 0.55 * g1['hp'] / max(1.0, w1):
                z1 = False
        if self.squad and f.get('squad_no_retreat'):
            if hostile or t - W.last_damage_t < 2.0 or (f.get('squad_hyper') and enemies):
                z1 = False
                self.retreating = False
            elif self.hpf < f.get('squad_heal_below', 0.8):
                z1 = True
        if z1:
            self.retreating = True
        if self.retreating:
            o1 = t - W.last_damage_t > 6.0 and (not hostile)
            if self.hpf >= 0.85 or (o1 and self.hpf > 0.6 and (t - W.last_damage_t > 12)):
                self.retreating = False
        (target, x1) = (None, -1000000000.0)
        for (d, tr) in enemies:
            k1 = self.my_dps(d, tr)
            if k1 <= 0 and d > 60:
                continue
            e1 = self.los_to(tr)
            if e1:
                self.los_seen[tr.id] = t
            w1 = self.their_dps(tr, d)
            b1 = tr.hp / max(1.0, k1)
            q1 = -b1
            q1 += w1 / 100.0
            if t - tr.last_hit_me < 4:
                q1 += 3.0
            if u0 and d >= self.gate_from and self.hit_by(tr, 4.0):
                q1 += 6.0
            if tr.hp < 350:
                q1 += 3.0
            if not e1:
                q1 -= 6.0
            if tr.id == self.target_id:
                q1 += 1.5
            if q1 > x1:
                (target, x1) = (tr, q1)
        if self.squad and f.get('squad_smith_target') and (len(hostile) >= 2):
            (h0, k0, n0) = (None, -1.0, -1.0)
            for (d, tr) in hostile:
                if not self.los_to(tr):
                    continue
                k1 = self.my_dps(d, tr)
                if k1 <= 0:
                    continue
                y1 = self.their_dps(tr, d, not self.exposed_to(tr)) / max(0.5, tr.hp / k1)
                if tr.id == self.target_id:
                    n0 = y1
                if y1 > k0:
                    (h0, k0) = (tr, y1)
            if h0 is not None and (target is None or h0 is target or k0 > 1.25 * n0):
                target = h0
        self.target_id = target.id if target is not None else None
        if self.retreating and (hostile or t - W.last_damage_t < 5.0):
            t1 = self.cover_spot()
            l0 = None
            for (d, tr) in enemies:
                if d < 45 and self.los_to(tr):
                    l0 = tr
                    break
            s1 = l0 if l0 is not None else target if target is not None and self.los_to(target) else None
            m1 = True
            if u0 and target is not None and (l0 is None) and (d2(x, y, target.pos[0], target.pos[1]) >= self.gate_from):
                m1 = self.ffa_provoked(target, d2(x, y, target.pos[0], target.pos[1])) or self.hit_by(target, 8.0)
                if not m1:
                    s1 = None
            w0 = t1
            j1 = 'cover'
            if w0 is None and target is not None and m1 and self.los_to(target):
                return Intent('fight', target=target, shoot=target, dist_pref=self.pref_range(target), strafe=True, boost=False, note='cornered')
            if w0 is None:
                u1 = None
                if target is not None:
                    u1 = bearing(x, y, target.pos[0], target.pos[1])
                else:
                    u1 = W.threat_bearing(5.0)
                if u1 is not None:
                    (d0, e0) = (x - 30 * math.cos(u1), y - 30 * math.sin(u1))
                    (y0, z0) = self.hold
                    if not self.in_safe(d0, e0, -10):
                        (d0, e0) = ((d0 + y0) * 0.5, (e0 + z0) * 0.5)
                    w0 = (d0, e0)
                else:
                    w0 = self.hold
                j1 = 'run'
            return Intent('retreat', goal=w0, target=target, shoot=s1, strafe=False, boost=True, note=j1)
        if self.retreating:
            s0 = None
            if target is not None and target.hp < 260 and self.los_to(target):
                dd = d2(x, y, target.pos[0], target.pos[1])
                if target.hp / max(1.0, self.my_dps(dd, target)) < 0.5 * g1['hp'] / max(1.0, self.their_dps(target, dd)):
                    s0 = target
            if s0 is None:
                if self.outside or self.zone_slack < f.zone_lead_s:
                    return Intent('zone', goal=self.hold, target=target, boost=True, note='heal-zone')
                t1 = self.cover_spot()
                return Intent('heal', goal=t1 if t1 is not None else self.hold, target=target, note='heal')
        for (d, tr) in hostile:
            if not tr.charging or d > 285:
                continue
            if abs(adiff(tr.aim[0], bearing(tr.pos[0], tr.pos[1], x, y))) > max(0.05, math.atan2(4.0, max(d, 1.0))):
                continue
            if 'lightning' in self.kinds and d < 40:
                break
            t1 = self.cover_spot(only=[tr])
            if t1 is not None and d2(x, y, t1[0], t1[1]) <= 12.0:
                return Intent('dodge', goal=t1, target=tr, shoot=tr if self.los_to(tr) else None, boost=True, note='laser')
            break
        if target is None and t - W.last_damage_t < 2.0:
            d1 = [e for e in W.dmg_taken_log[-6:] if t - e[0] < 2.0 and e[3] not in ('zone', None)]
            if d1:
                u1 = W.threat_bearing(2.0)
                if u1 is not None:
                    n1 = (x + 120.0 * math.cos(u1), y + 120.0 * math.sin(u1))
                    t1 = None if self.outside or self.zone_slack < f.zone_lead_s else self.cover_spot(pseudo=n1)
                    return Intent('alert', goal=t1 if t1 is not None else self.hold, face=u1, boost=t1 is not None, note='unseen')
        q0 = None
        if target is not None:
            d = d2(x, y, target.pos[0], target.pos[1])
            k1 = self.my_dps(d, target)
            w1 = self.their_dps(target, d)
            h1 = target.hp / max(1.0, k1)
            v1 = g1['hp'] / max(1.0, w1 + sum((self.their_dps(o, dd, not self.exposed_to(o)) for (dd, o) in hostile if o is not target)) * 0.7)
            a0 = t - target.last_hit_me < 4.0 or any((o is target for (dd, o) in hostile))
            c2 = None
            v0 = u0 and d >= self.gate_from
            if v0:
                a0 = self.ffa_provoked(target, d)
                c2 = 'prov' if a0 else None
            j = v1 / max(0.1, h1)
            b2 = target.hp < 0.45 * target.max_hp
            j0 = t - target.fighting_t < 3.0
            l1 = not W.is_ffa()
            l = f.aggression * (1.25 if l1 else 1.0)
            x0 = self.close_weapon(25.0)
            self.evade = False
            i0 = t - self.los_seen.get(target.id, -99.0) > 2.0 and t - target.last_hit_me > 3.0
            if x0 is not None and (not (a0 and d < 60)):
                q0 = None
            elif self.squad and f.get('squad_hyper'):
                q0 = target
            elif i0 and d > 30:
                q0 = None
            elif a0 and (j >= 0.75 or d < 40 or (self.squad and f.get('squad_fight_back'))):
                q0 = target
            elif a0:
                self.evade = True
            elif v0:
                c2 = self.ffa_open_ok(target, d, j, j0)
                if c2 is not None:
                    q0 = target
            elif j * l > f.engage_ratio:
                if not (self.squad and f.get('squad_reactive')) or self.closing_on_us(target, d):
                    q0 = target
            elif b2 and self.hpf > 0.4 or (j0 and self.hpf > 0.5 and (j > 0.6)):
                q0 = target
            elif d < 45 and self.hpf > 0.3:
                q0 = target
        e2 = self.outside or self.zone_slack < f.zone_lead_s
        if q0 is None and target is not None and getattr(self, 'evade', False):
            t1 = self.cover_spot()
            if t1 is None and self.los_to(target):
                q0 = target
        if q0 is None and target is not None and getattr(self, 'evade', False):
            t1 = self.cover_spot()
            w0 = t1 if t1 is not None else self.hold
            if e2 and t1 is not None and (not self.in_safe(t1[0], t1[1], 0)):
                w0 = self.hold
            s1 = target if self.los_to(target) else None
            return Intent('evade', goal=w0, target=target, shoot=s1, strafe=t1 is None, boost=True, dist_pref=200.0, note='cover' if t1 else 'open')
        if q0 is not None:
            o0 = self.pref_range(q0)
            w0 = None
            if e2:
                w0 = self.hold
            elif self.squad and f.get('squad_hyper') and (not self.los_to(q0)):
                w0 = (q0.pos[0], q0.pos[1])
            if w0 is None and self.sq('fight_cube_m', 0) > 0 and (self.hpf > self.sq('fight_cube_hp', 0.5)):
                m0 = self.near_cube(self.sq('fight_cube_m', 0))
                if m0 is not None:
                    w0 = (m0.pos[0], m0.pos[1])
            return Intent('fight', goal=w0, target=q0, shoot=q0, dist_pref=o0, strafe=True, boost=e2 or self.outside, note=f"{(c2 + ' ' if u0 and c2 else '')}d{int(d2(x, y, q0.pos[0], q0.pos[1]))}>{int(o0)}")
        b0 = target
        if e2:
            return Intent('zone', goal=self.hold, target=b0, shoot=None, boost=self.outside or self.zone_slack < 0, note=f'slack{int(self.zone_slack)}')
        if self.ffa_on('ffa_hide') and enemies:
            hm = f.get('ffa_hide_m', 170.0)
            near = [tr for (dd, tr) in enemies if dd < hm]
            if near and self.close_weapon(20.0) is None and (self.near_cube(12.0) is None):
                a2 = [tr for tr in near if self.their_los_to_point(tr, x, y, z)]
                if a2:
                    t1 = self.cover_spot(only=near)
                    self.ghost_spot = (t, t1)
                    if t1 is not None and d2(x, y, t1[0], t1[1]) <= f.get('ffa_hide_reach_m', 45.0):
                        self.ghost_t = t
                        return Intent('hold', goal=t1, target=a2[0], note='ghost')
                elif t - self.ghost_t < f.get('ffa_hide_wait_s', 6.0):
                    return Intent('hold', goal=None, target=near[0], note='ghost-wait')
        p0 = self.drop_goal()
        if p0 is not None:
            if p0.target is None:
                p0.target = b0
            return p0
        f1 = self.loot_goal_pick()
        if f1 is not None:
            if f1.target is None and b0 is not None:
                f1.target = b0
            return f1
        j1 = 'hold'
        w0 = self.hold
        if b0 is not None:
            t1 = self.ghost_spot[1] if self.ghost_spot[0] == t else self.cover_spot(only=[b0])
            if t1 is not None:
                w0 = t1
                j1 = 'hide'
        elif self.ffa_on('ffa_snug'):
            t1 = self.snug_spot()
            if t1 is not None:
                w0 = t1
                j1 = 'snug'
        return Intent('hold', goal=w0, target=b0, note=j1)

    def return_fire(self, intent: Intent):
        t = self.t
        (e0, g0) = (self.pos[0], self.pos[1])
        intent.evasive = bool(self.hostile) or t - self.W.last_damage_t < 1.5
        if intent.shoot is not None or intent.mode in ('heal',):
            return
        (j, f) = (None, 1000000000.0)
        q = getattr(self, 'gate', False)
        for (l, d0) in self.hostile:
            if q and l >= max(self.P.get('ffa_gate_bump_m', 30.0), self.gate_from) and (not self.ffa_provoked(d0, l)) and (self.ffa_open_ok(d0, l, 1.0, False) != 'close'):
                continue
            if self.my_dps(l, d0) > 0 and self.los_to(d0) and (l < f):
                (j, f) = (d0, l)
        if j is None:
            a0 = {e[2] for e in self.W.dmg_taken_log[-8:] if t - e[0] < 3.0 and e[3] == 'npc'}
            for b0 in self.W.npcs.values():
                if b0.id in a0 and t - b0.last_seen < 0.3:
                    l = d2(e0, g0, b0.pos[0], b0.pos[1])
                    if l < 120 and self.los_to(b0) and (l < f):
                        (j, f) = (b0, l)
        if j is not None:
            intent.shoot = j
            if intent.target is None:
                intent.target = j

    def pref_range(self, tr):
        b0 = max(1.0, self.me['hp'])
        e0 = max(1.0, tr.hp)
        (i0, j0) = (self.pos[0], self.pos[1])
        q = d2(i0, j0, tr.pos[0], tr.pos[1])
        (j, l) = (q, -1000000000.0)
        for d0 in HOLD_RANGES:
            a0 = self.my_dps(d0, tr)
            if a0 <= 0:
                continue
            g0 = self.their_dps(tr, d0)
            f = a0 / e0 / (g0 / b0 + 0.001)
            h0 = math.log(f + 1e-06) - abs(d0 - q) * 0.0015
            if h0 > l:
                (l, j) = (h0, d0)
        if tr.hp < 320 and self.hpf > 0.5 and ('lightning' in self.kinds):
            j = min(j, 35.0)
        return j

    def cover_spot(self, only=None, pseudo=None):
        t = self.t
        if self.retreat_spot is not None and t - self.retreat_spot_t < 0.8 and (only is None) and (pseudo is None):
            return self.retreat_spot
        if only is not None:
            m0 = tuple((tr.id for tr in only))
            b0 = getattr(self, '_hide_cache', None)
            if b0 is not None and b0[0] == m0 and (t - b0[1] < 0.6):
                return b0[2]
        if pseudo is not None:
            b0 = getattr(self, '_pseudo_cache', None)
            if b0 is not None and t - b0[1] < 0.8 and (d2(b0[0][0], b0[0][1], pseudo[0], pseudo[1]) < 40):
                return b0[2]
        (x, y, b1) = self.pos
        a1 = time.perf_counter()
        w0 = self.A.rays + int(self.P.get('cover_ray_budget', 150))
        j0 = float(self.P.get('cover_guard_s', 0.015))
        if only is not None:
            eyes = [(tr.pos[0], tr.pos[1], tr.pos[2] + 8.0 * gn.body_scale(tr.cubes, self.size_per_cube)) for tr in only]
        else:
            eyes = [(tr.pos[0], tr.pos[1], tr.pos[2] + 8.0 * gn.body_scale(tr.cubes, self.size_per_cube)) for tr in self.W.mechs.values() if t - tr.last_seen < 6.0 and d2(x, y, tr.pos[0], tr.pos[1]) < 230]
        if pseudo is not None:
            eyes.append((pseudo[0], pseudo[1], self.A.terrain(pseudo[0], pseudo[1]) + 8.0))
        if not eyes:
            return None
        f = self.A
        j = self.N
        y0 = sum((e[0] for e in eyes)) / len(eyes)
        z0 = sum((e[1] for e in eyes)) / len(eyes)
        q = bearing(y0, z0, x, y)
        d0 = []
        for u0 in (8.0, 14.0, 22.0, 32.0, 45.0, 60.0, 78.0, 95.0):
            for l0 in range(16):
                n0 = (l0 - 7.5) * (math.pi / 8.0)
                l = q + n0
                d0.append((u0 * 0.6 + abs(n0) * 9.0, u0, l))
        d0.sort()
        a0 = None
        i0 = None
        (k0, v0) = (9.0 * self.scale, 2.5 * self.scale)
        for (o0, u0, l) in d0:
            if self.A.rays > w0 or time.perf_counter() - a1 > j0:
                break
            (p0, q0) = (x + u0 * math.cos(l), y + u0 * math.sin(l))
            if not j.cspace_free(p0, q0):
                continue
            if not self.in_safe(p0, q0, 0) and (self.outside or self.zone_slack < 20):
                continue
            s0 = f.terrain(p0, q0)
            x0 = False
            for (e0, g0, h0) in eyes:
                if f.los(e0, g0, h0, p0, q0, s0 + 0.5 * k0):
                    x0 = True
                    break
            if x0:
                continue
            for (e0, g0, h0) in eyes:
                if self.exposed_point(e0, g0, h0, p0, q0, s0, k0, v0) is not None:
                    x0 = True
                    break
            if x0:
                continue
            if j.segment_free(x, y, p0, q0):
                a0 = (p0, q0)
                break
            if i0 is None:
                i0 = (p0, q0)
        if a0 is None:
            a0 = i0
        if only is None and pseudo is None:
            self.retreat_spot = a0
            self.retreat_spot_t = t
        elif only is not None:
            self._hide_cache = (tuple((tr.id for tr in only)), t, a0)
        else:
            self._pseudo_cache = (pseudo, t, a0)
        return a0

    def drop_goal(self):
        f = self.P
        if not f.drop_go:
            return None
        l = self.ffa_on('ffa_loot')
        (m0, n0) = (self.pos[0], self.pos[1])
        j = None
        for d0 in self.obs.get('drops') or []:
            (e0, g0) = (d0['pos'][0], d0['pos'][1])
            a0 = d2(m0, n0, e0, g0)
            if a0 > f.drop_max_dist:
                continue
            h0 = a0 / max(1.0, self.walk)
            if d0.get('lands_in', 0) > h0 + 6:
                continue
            if not self.in_safe(e0, g0, 0) and self.zone_slack < 20:
                continue
            if self.goal_bad(e0, g0, 8.0):
                continue
            q = False
            for (b0, l0) in self.enemies:
                if d2(l0.pos[0], l0.pos[1], e0, g0) < 45:
                    q = True
            if d0.get('holder') not in (None, self.slot):
                q = True
            if q and (self.hpf < 0.9 or l):
                continue
            if l and self.ffa_loot_risky(e0, g0):
                continue
            if self.hpf < f.drop_hp_frac:
                continue
            if j is None or a0 < j[0]:
                j = (a0, d0)
        if j is None:
            return None
        (a0, d0) = j
        k0 = d0.get('radius', 8.0)
        (i0, j0) = (d0['pos'][0], d0['pos'][1])
        if a0 < k0 * 0.6:
            return Intent('drop', goal=(i0, j0), note=f"cap{d0.get('progress', 0):.1f}")
        return Intent('drop', goal=(i0, j0), boost=a0 > 40 and self.me.get('energy', 0) > 40, note='drop')

    def weapon_value(self, kind):
        j = self.P.weapon_value.get(kind, 0.0)
        f = self.P.get('gun_laser_always') or (self.P.get('gun_laser_unless_ffa') and (not self.W.is_ffa())) or (getattr(self, 'squad', False) and self.P.get('squad_gun_laser'))
        if kind == 'lightning' and f:
            return self.P.get('squad_lightning_value', 4.0)
        if kind == 'lightning' and self.zn[1] <= self.P.late_radius:
            j += self.P.late_lightning_bonus
        return j

    def loadout_gain(self, kind):
        kinds = self.kinds
        if kind in kinds:
            return (0.0, None)
        if None in kinds:
            return (self.weapon_value(kind), None)
        f = [self.weapon_value(k) for k in kinds]
        l = 0 if f[0] <= f[1] else 1
        j = self.weap[l]
        if j and j.get('kind') == 'laser' and ((j.get('charge') or 0) > 0):
            return (0.0, None)
        return (self.weapon_value(kind) - f[l], l)

    def near_cube(self, radius):
        if self.me.get('cubes', 0) >= 21:
            return None
        (a0, b0, d0) = self.pos
        (j, f) = (None, radius)
        for q in self.W.cubes.values():
            l = d2(a0, b0, q.pos[0], q.pos[1])
            if l > f or abs(q.pos[2] - d0) > 5:
                continue
            if not self.N.cspace_free(q.pos[0], q.pos[1]) and (not self.N.is_free(q.pos[0], q.pos[1])):
                continue
            if not self.in_safe(q.pos[0], q.pos[1], 0):
                continue
            (j, f) = (q, l)
        return j

    def close_weapon(self, radius):
        (b0, d0, e0) = self.pos
        f = None
        for q in self.W.pickups.values():
            if self.blacklist.get(q.id, -1) > self.t:
                continue
            if abs(q.pos[2] - e0) > 4:
                continue
            j = d2(b0, d0, q.pos[0], q.pos[1])
            if j > radius:
                continue
            (l, a0) = self.loadout_gain(q.kind)
            if l >= max(5.0, self.P.swap_margin) and (f is None or j < f[0]):
                f = (j, q)
        return f[1] if f else None

    def loot_goal_pick(self):
        f = self.P
        j = self.W
        (x, y, z) = self.pos
        q0 = self.t
        (hx, hy) = self.hold
        base = d2(x, y, hx, hy)
        o0 = min(self.zone_slack, 120.0)
        q = max(0.0, o0 - 6.0) * self.walk * 0.5
        b0 = 0.25 if self.zn[1] > 150 else 0.45
        l = None
        a0 = self.ffa_on('ffa_loot')

        def detour(px, py):
            return d2(x, y, px, py) + d2(px, py, hx, hy) - base

        def reachable(px, py, pz):
            return abs(pz - z) <= 5 or self.N.is_free(px, py)
        for l0 in j.pickups.values():
            (j0, p0) = self.loadout_gain(l0.kind)
            if j0 < f.swap_margin and (not (p0 is None and j0 > 0)):
                continue
            if self.blacklist.get(l0.id, -1) > q0 or not reachable(*l0.pos) or self.goal_bad(l0.pos[0], l0.pos[1]):
                continue
            if not self.N.is_free(l0.pos[0], l0.pos[1]) and (not self.N.cspace_free(l0.pos[0], l0.pos[1])):
                continue
            g0 = detour(l0.pos[0], l0.pos[1])
            if g0 > q + 15:
                continue
            if a0 and self.ffa_loot_risky(l0.pos[0], l0.pos[1]):
                continue
            n0 = 12.0 * j0 - b0 * g0
            if n0 > 0 and (l is None or n0 > l[0]):
                l = (n0, Intent('loot', goal=(l0.pos[0], l0.pos[1]), pickup=l0, note=f'{l0.kind}'))
        d0 = self.me.get('cubes', 0)
        if d0 < 21:
            s0 = 60.0 if d0 < 10 else 12.0
            for l0 in j.cubes.values():
                if not reachable(*l0.pos) or (not self.N.cspace_free(l0.pos[0], l0.pos[1]) and (not self.N.is_free(l0.pos[0], l0.pos[1]))):
                    continue
                if self.goal_bad(l0.pos[0], l0.pos[1]):
                    continue
                g0 = detour(l0.pos[0], l0.pos[1])
                if g0 > q + 15:
                    continue
                if a0 and d2(x, y, l0.pos[0], l0.pos[1]) > f.get('ffa_loot_near_m', 25.0) and (g0 > f.get('ffa_cube_detour_m', 60.0) or self.ffa_loot_risky(l0.pos[0], l0.pos[1])):
                    continue
                n0 = s0 - b0 * g0
                if n0 > 0 and (l is None or n0 > l[0]):
                    l = (n0, Intent('loot', goal=(l0.pos[0], l0.pos[1]), note='cube'))
        if l is not None:
            l0 = l[1]
            l0.shoot = self.farm_target(walking=True)
            return l0
        i0 = self.farm_target(walking=False)
        if i0 is not None:
            m0 = 'npc' if getattr(i0, 'kind', '') == 'npc' else 'crate'
            k0 = None
            if m0 == 'npc':
                e0 = d2(x, y, i0.pos[0], i0.pos[1])
                if e0 > 95:
                    k0 = (i0.pos[0], i0.pos[1])
            return Intent('farm', goal=k0, shoot=i0, target=i0 if m0 == 'npc' else None, dist_pref=75.0 if m0 == 'npc' else None, strafe=m0 == 'npc', note=m0)
        h0 = self.explore_goal(q)
        if h0 is not None:
            return Intent('explore', goal=h0, note='explore')
        return None

    def explore_goal(self, budget_m):
        if budget_m < 80 or (self.me.get('cubes', 0) >= 10 and 'laser' in self.kinds):
            return None
        if 'laser' in self.kinds and self.ffa_on('ffa_hide'):
            return None
        (q0, s0) = (self.pos[0], self.pos[1])
        p0 = self.visited
        d0 = 40.0
        (q, a0) = (int(math.floor(q0 / d0)), int(math.floor(s0 / d0)))
        for h0 in (-1, 0, 1):
            for i0 in (-1, 0, 1):
                p0.add((q + h0, a0 + i0))
        e0 = self.explore_target
        if e0 is not None and (int(math.floor(e0[0] / d0)), int(math.floor(e0[1] / d0))) not in p0 and (self.t - self.explore_t < 25) and (not self.goal_bad(e0[0], e0[1], 20.0)):
            return e0
        (b0, o0) = self.zn
        (l, n0) = self.zcur
        (j, f) = (None, 1e+18)
        for h0 in range(-6, 7):
            for i0 in range(-6, 7):
                j0 = (q + h0, a0 + i0)
                if j0 in p0:
                    continue
                (l0, m0) = ((j0[0] + 0.5) * d0, (j0[1] + 0.5) * d0)
                g0 = math.hypot(l0 - q0, m0 - s0)
                if g0 > min(budget_m * 0.5, 260):
                    continue
                if d2(l0, m0, l[0], l[1]) > n0 - 25:
                    continue
                if self.zone_slack < 60 and d2(l0, m0, b0[0], b0[1]) > o0:
                    continue
                if self.goal_bad(l0, m0, 20.0):
                    continue
                k0 = self.N.nearest_free(l0, m0, 6)
                if k0 is None:
                    p0.add(j0)
                    continue
                if g0 < f:
                    (f, j) = (g0, self.N.pos(k0))
        self.explore_target = j
        self.explore_t = self.t
        return j

    def farm_target(self, walking):
        f = self.P
        if self.enemies:
            e0 = [d for (d, tr) in self.enemies if d < 200]
            if e0:
                return None
        (k0, l0, m0) = self.pos
        (q, l) = (None, 1000000000.0)
        if self.hpf < self.sq('farm_regen_hp', 0.85) and self.t - self.W.last_damage_t < 20:
            return None
        if self.ffa_on('ffa_quiet'):
            (g0, h0) = (f.get('ffa_quiet_m', 250.0), f.get('ffa_quiet_s', 8.0))
            for tr in self.W.mechs.values():
                if self.t - tr.last_seen < h0 and d2(k0, l0, tr.pos[0], tr.pos[1]) < g0:
                    return None
            for (i0, j, j0, d0, a0) in self.W.threats:
                if self.t - i0 < 5.0 and a0 == 'near' and (d0 in ('gun', 'laser', 'laser_charge', 'lightning', 'mortar')):
                    return None
        if self.me.get('cubes', 0) < 14:
            for b0 in self.W.crates.values():
                d = d2(k0, l0, b0.pos[0], b0.pos[1])
                if d > f.crate_shoot_range or d < 4:
                    continue
                if self.t - b0.last_seen > 0.3:
                    continue
                if not self.in_safe(b0.pos[0], b0.pos[1], -25):
                    continue
                if not self.A.los(k0, l0, m0 + self.muzzle_h, b0.pos[0], b0.pos[1], b0.pos[2] + 1.2):
                    continue
                if d < l:
                    (q, l) = (b0, d)
        if f.npc_hunt and self.hpf > self.sq('npc_min_hp_frac', 0.8) and (self.me.get('cubes', 0) < 12):
            for tr in self.W.npcs.values():
                if self.t - tr.last_seen > 0.25:
                    continue
                d = d2(k0, l0, tr.pos[0], tr.pos[1])
                if d > self.sq('npc_hunt_range', 140.0):
                    continue
                if not self.in_safe(tr.pos[0], tr.pos[1], -25):
                    continue
                if not self.los_to(tr):
                    continue
                if d * 0.8 < l:
                    (q, l) = (tr, d * 0.8)
        return q

    def goal_bad(self, px, py, r=6.0):
        l = self.t
        for (f, j, q) in self.bad_goals:
            if q > l and abs(f - px) < r and (abs(j - py) < r):
                return True
        return False

    def watchdog(self, intent: Intent):
        a0 = intent.goal
        if a0 is None or intent.mode in ('fight', 'evade', 'farm', 'dodge', 'alert'):
            self.wd_key = None
            return
        t = self.t
        f = self.P
        q = d2(self.pos[0], self.pos[1], a0[0], a0[1])
        d0 = (intent.mode, int(a0[0] // 8), int(a0[1] // 8))
        if d0 != self.wd_key:
            (self.wd_key, self.wd_best, self.wd_t, self.wd_escapes) = (d0, q, t, 0)
            return
        if q < self.wd_best - 1.5 or t < self.escape_until:
            self.wd_best = min(self.wd_best, q)
            self.wd_t = t
            return
        if q <= (0.0 if intent.mode in ('loot', 'explore') else 5.0):
            self.wd_t = t
            return
        if t - self.wd_t < f.get('wd_stall_s', 4.0):
            return
        self.bad_goals = [b for b in self.bad_goals if b[2] > t]
        if intent.mode in ('loot', 'explore', 'drop'):
            b = (int(a0[0] // 8), int(a0[1] // 8))
            e0 = self.bad_count[b] = self.bad_count.get(b, 0) + 1
            l = f.get('wd_ban_s', 60.0) * 2 ** min(e0 - 1, 4)
            self.bad_goals.append((a0[0], a0[1], t + l))
            if intent.pickup is not None:
                self.blacklist[intent.pickup.id] = t + l
            if intent.mode == 'explore':
                self.explore_target = None
            self.wd_key = None
            return
        b0 = self.wd_escapes
        j = math.atan2(a0[1] - self.pos[1], a0[0] - self.pos[0]) + (0.0, 0.9, -0.9, 1.8, -1.8)[b0 % 5]
        self.escape_dir = (math.cos(j), math.sin(j))
        self.escape_until = t + f.get('wd_escape_s', 1.5)
        self.wd_escapes = b0 + 1
        self.wd_t = t
        self.path = []
        self.search = None
        if intent.mode in ('retreat', 'heal'):
            self.retreat_spot = None

    def plan_to(self, goal):
        (m0, n0) = (self.pos[0], self.pos[1])
        (b0, d0) = goal
        l0 = self.t
        f = self.N
        if self.ticks % 2 == 0 or not self.path or self.path_goal is None or (d2(b0, d0, self.path_goal[0], self.path_goal[1]) > 3.0):
            if f.segment_free(m0, n0, b0, d0):
                self.path = [(b0, d0)]
                self.path_goal = (b0, d0)
                self.path_t = l0
                self.search = None
                return
        k0 = self.path_goal is None or d2(b0, d0, self.path_goal[0], self.path_goal[1]) > 8.0 or l0 - self.path_t > 5.0 or (not self.path)
        if self.search is not None and d2(b0, d0, self.search_goal[0], self.search_goal[1]) > 20.0:
            self.search = None
        if k0 and self.search is None:
            self.search = f.astar_iter(m0, n0, b0, d0, chunk=250)
            self.search_goal = (b0, d0)
        if self.search is not None:
            j = self.P
            e0 = int(j.get('astar_chunks_path', 5) if self.path else j.get('astar_chunks_nopath', 7))
            q = self.A.rays - self.rays0 - int(j.get('astar_free_rays', 160))
            if q > 0:
                e0 -= (q + 29) // 30
            a0 = float(j.get('tick_guard_s', 0.02))
            for l in range(max(0, e0)):
                if time.perf_counter() - self.tick_t0 > a0:
                    break
                i0 = next(self.search, ([(b0, d0)], False))
                if i0 is not None:
                    (h0, g0) = i0
                    self.search = None
                    j0 = f.smooth(h0, m0, n0)
                    self.path = j0[1:] if len(j0) > 1 else [self.search_goal]
                    self.path_goal = self.search_goal
                    self.path_t = l0
                    break
        if not self.path:
            self.path = [(b0, d0)]
            self.path_goal = (b0, d0)
            self.path_t = l0

    def follow(self):
        (b0, d0) = (self.pos[0], self.pos[1])
        while len(self.path) > 1 and d2(b0, d0, self.path[0][0], self.path[0][1]) < 2.5:
            self.path.pop(0)
        if len(self.path) > 1 and self.ticks % 2 == 0 and self.N.segment_free(b0, d0, self.path[1][0], self.path[1][1]):
            self.path.pop(0)
        if not self.path:
            return (0.0, 0.0, 0.0)
        (q, a0) = self.path[0]
        f = d2(b0, d0, q, a0)
        (j, l) = unit(q - b0, a0 - d0)
        return (j, l, f)

    def pilot(self, intent: Intent):
        f = self.P
        m1 = self.t
        (t1, u1, v1) = self.pos
        w0 = self.me
        x0 = y0 = 0.0
        a0 = bool(intent.boost)
        u0 = False
        if intent.goal is not None:
            self.plan_to(intent.goal)
            (n0, o0, i0) = self.follow()
            k0 = len(self.path) <= 1
            if k0 and i0 < 1.5:
                n0 = o0 = 0.0
            elif k0 and i0 < 6:
                k1 = i0 / 6.0
                (n0, o0) = (n0 * k1, o0 * k1)
            (x0, y0) = (n0, o0)
        n1 = intent.target
        if intent.evasive and (not intent.strafe) and (x0 or y0) and (n1 is not None):
            if m1 >= self.strafe_until:
                if self.rng.random() < 0.75:
                    self.strafe_dir = -self.strafe_dir
                self.strafe_until = m1 + self.rng.uniform(f.strafe_min_s, f.strafe_max_s)
            q = bearing(t1, u1, n1.pos[0], n1.pos[1])
            (e1, f1) = (-math.sin(q) * self.strafe_dir, math.cos(q) * self.strafe_dir)
            (x0, y0) = unit(x0 + e1 * 0.8, y0 + f1 * 0.8)
        if intent.strafe and n1 is not None:
            q = bearing(t1, u1, n1.pos[0], n1.pos[1])
            h0 = d2(t1, u1, n1.pos[0], n1.pos[1])
            if not a0 and self.fight_boost():
                a0 = True
            if m1 >= self.strafe_until:
                if self.rng.random() < 0.75:
                    self.strafe_dir = -self.strafe_dir
                self.strafe_until = m1 + self.rng.uniform(f.strafe_min_s, f.strafe_max_s)
            (e1, f1) = (-math.sin(q) * self.strafe_dir, math.cos(q) * self.strafe_dir)
            h1 = 0.0
            if intent.dist_pref is not None:
                h1 = clamp((h0 - intent.dist_pref) / 25.0, -1.0, 1.0)
            (i1, j1) = (math.cos(q) * h1, math.sin(q) * h1)
            if intent.goal is not None:
                s1 = 0.9
                (e0, g0) = (x0 * s1 + e1 * 0.6 + i1 * 0.3, y0 * s1 + f1 * 0.6 + j1 * 0.3)
                (b1, d1) = (x0 * s1 - e1 * 0.6 + i1 * 0.3, y0 * s1 - f1 * 0.6 + j1 * 0.3)
            else:
                (e0, g0) = (e1 * 0.75 + i1 * 0.9, f1 * 0.75 + j1 * 0.9)
                (b1, d1) = (-e1 * 0.75 + i1 * 0.9, -f1 * 0.75 + j1 * 0.9)
            (x0, y0) = unit(e0, g0)
            if self.P.get('dodge_pred') or self.sqk('dodge_pred', False):
                l1 = self.move_speed(a0)
                v0 = self.bullet_miss(x0, y0, l1)
                p0 = self.mc.get('radius', 2.5) * self.scale + 0.6
                if v0 < p0:
                    (l0, m0) = unit(b1, d1)
                    j = self.bullet_miss(l0, m0, l1)
                    if j >= p0 or j > v0 + 1.0:
                        self.strafe_dir = -self.strafe_dir
                        self.strafe_until = m1 + self.rng.uniform(f.strafe_min_s, f.strafe_max_s)
                        (x0, y0) = (l0, m0)
            elif self.bullet_inbound():
                self.strafe_dir = -self.strafe_dir
                self.strafe_until = m1 + self.rng.uniform(f.strafe_min_s, f.strafe_max_s)
        if self.P.get('dodge_all') or self.sqk('dodge_all', False):
            (x0, y0) = self.bullet_filter(x0, y0, a0)
        j0 = self.mortar_dodge()
        if j0 is not None:
            (x0, y0) = j0
            a0 = w0.get('energy', 0) > 10
        q1 = self.P.get('wd_on', True)
        if not self.outside and (x0 or y0) and (not (q1 and (intent.mode == 'zone' or m1 < self.escape_until))):
            (b0, g1) = self.zcur
            (z0, a1) = (t1 + x0 * 6, u1 + y0 * 6)
            if d2(z0, a1, b0[0], b0[1]) > g1 - 1.5 and d2(t1, u1, b0[0], b0[1]) > g1 - 10:
                (q0, s0) = unit(b0[0] - t1, b0[1] - u1)
                (x0, y0) = unit(x0 + q0 * 1.2, y0 + s0 * 1.2)
        if x0 or y0:
            (x0, y0) = self.steer(x0, y0)
        l1 = math.hypot(w0['vel'][0], w0['vel'][1])
        d0 = math.hypot(x0, y0) > 0.5
        if d0 and l1 < 1.5 and w0.get('grounded', True):
            if self.stuck_since is None:
                self.stuck_since = m1
            elif m1 - self.stuck_since > 0.6:
                self.unstick_until = m1 + 0.9
                l = math.atan2(y0, x0) + self.rng.choice((-1, 1)) * self.rng.uniform(0.6, 1.6)
                self.unstick_dir = (math.cos(l), math.sin(l))
                self.stuck_since = None
                self.path = []
                self.search = None
        else:
            self.stuck_since = None
        if m1 < self.unstick_until:
            u0 = w0.get('grounded', False)
            a0 = w0.get('energy', 0) > 15
            (o1, p1) = self.unstick_dir
            (x0, y0) = unit(x0 * 0.4 + o1, y0 * 0.4 + p1)
        if q1 and m1 < self.escape_until:
            u0 = w0.get('grounded', False)
            a0 = w0.get('energy', 0) > 15
            (x0, y0) = self.escape_dir
        if a0 and w0.get('energy', 0) < 22 and (not self.outside):
            a0 = False
        if intent.mode == 'hold' and (not self.enemies) and (x0 or y0):
            pass
        self.last_move = (x0, y0)
        return ((x0, y0), a0, u0)

    def fight_boost(self):
        f = self.P
        q = f.get('fight_boost_e', 0.0)
        if not q or not (self.squad or f.get('fight_boost_ffa')):
            self.fb_on = False
            return False
        if not (getattr(self, 'hostile', None) or self.t - self.W.last_damage_t < 2.0):
            self.fb_on = False
            return False
        l = self.me.get('energy', 0)
        if l >= q:
            self.fb_on = True
        elif l < f.get('fight_boost_stop_e', 26.0):
            self.fb_on = False
        if self.fb_on:
            return True
        j = f.get('fight_boost_charge_e', 0.0)
        return bool(j) and l >= j and any((w and w.get('kind') == 'laser' and ((w.get('charge') or 0) > 0) for w in self.weap))

    def steer(self, mx, my):
        (d0, e0) = (self.pos[0], self.pos[1])
        f = self.N
        if f.cspace_free(d0 + mx * 3.0, e0 + my * 3.0) and f.cspace_free(d0 + mx * 1.5, e0 + my * 1.5):
            return (mx, my)
        l = math.atan2(my, mx)
        for b0 in (1, -1, 2, -2, 3, -3, 4, -4, 5, -5):
            j = l + b0 * 0.45
            (q, a0) = (math.cos(j), math.sin(j))
            if f.cspace_free(d0 + q * 3.0, e0 + a0 * 3.0) and f.cspace_free(d0 + q * 1.5, e0 + a0 * 1.5):
                return (q, a0)
        return (mx, my)

    def bullet_filter(self, mvx, mvy, boost):
        if not self.obs.get('projectiles'):
            return (mvx, mvy)
        g0 = bool(mvx or mvy)
        h0 = self.move_speed(boost)
        d0 = self.bullet_miss(mvx, mvy, h0 if g0 else 0.0)
        a0 = self.mc.get('radius', 2.5) * self.scale + 0.6
        if d0 >= a0:
            return (mvx, mvy)
        j = math.atan2(mvy, mvx) if g0 else 0.0
        (l, q) = (None, d0 + 1.0)
        for b0 in (1, -1, 2, -2, 3, -3, 4):
            f = j + b0 * (math.pi / 4)
            (i0, j0) = (math.cos(f), math.sin(f))
            e0 = self.bullet_miss(i0, j0, h0)
            if e0 >= a0 + 0.75:
                return (i0, j0)
            if e0 > q:
                (l, q) = ((i0, j0), e0)
        return l if l is not None else (mvx, mvy)

    def move_speed(self, boost):
        f = self.walk
        if boost and self.me.get('energy', 0) >= 22:
            j = self.me.get('stats') or {}
            f = float(j.get('boost_speed', self.mc.get('boost_speed', 19.5)))
        if any((w and w.get('kind') == 'laser' and ((w.get('charge') or 0) > 0) for w in self.weap)):
            f *= float(self.mc.get('charge_move_mult', 0.5))
        return f

    def bullet_miss(self, ux, uy, spd):
        q = 99.0
        p0 = self.obs.get('projectiles')
        if not p0:
            return q
        (b1, d1, e1) = self.pos
        (x0, y0) = (self.me['vel'][0], self.me['vel'][1])
        k0 = self.me.get('grounded', True)
        l = float(self.mc.get('ground_accel', 58.5) if k0 else self.mc.get('air_accel', 12.0))
        (z0, a1) = (ux * spd, uy * spd)
        (g0, h0) = (z0 - x0, a1 - y0)
        e0 = math.hypot(g0, h0)
        f = e0 / l if l > 0 else 0.0
        (l0, m0) = (0.5 * l * g0 / e0, 0.5 * l * h0 / e0) if e0 > 1e-06 else (0.0, 0.0)
        (i0, j0) = (b1 + x0 * f + l0 * f * f, d1 + y0 * f + m0 * f * f)
        v0 = e1 + self.mc.get('height', 9.0) * self.scale + 0.3
        for o0 in p0:
            if o0.get('kind') not in ('gun', 'npc'):
                continue
            (a0, b0) = (o0['pos'], o0['vel'])
            w0 = b0[0] * b0[0] + b0[1] * b0[1]
            if w0 < 1.0:
                continue
            u0 = ((b1 - a0[0]) * b0[0] + (d1 - a0[1]) * b0[1]) / w0
            if u0 <= 0.0 or u0 > 1.0:
                continue
            q0 = s0 = 0.0
            for j in range(3):
                if u0 <= f:
                    (q0, s0) = (b1 + x0 * u0 + l0 * u0 * u0, d1 + y0 * u0 + m0 * u0 * u0)
                else:
                    (q0, s0) = (i0 + z0 * (u0 - f), j0 + a1 * (u0 - f))
                u0 = max(0.0, ((q0 - a0[0]) * b0[0] + (s0 - a0[1]) * b0[1]) / w0)
            if u0 <= f:
                (q0, s0) = (b1 + x0 * u0 + l0 * u0 * u0, d1 + y0 * u0 + m0 * u0 * u0)
            else:
                (q0, s0) = (i0 + z0 * (u0 - f), j0 + a1 * (u0 - f))
            d0 = a0[2] + b0[2] * u0
            if d0 < e1 - 0.3 or d0 > v0:
                continue
            n0 = math.hypot(a0[0] + b0[0] * u0 - q0, a0[1] + b0[1] * u0 - s0)
            if n0 < q:
                q = n0
        return q

    def bullet_inbound(self):
        (a0, b0, d0) = self.pos
        f = d0 + 4.5 * self.scale
        for l in self.obs.get('projectiles') or []:
            if l.get('kind') not in ('gun', 'npc'):
                continue
            (q, j) = gn.closest_approach(l['pos'], l['vel'], a0, b0, f, 0.6)
            if q > 0.04 and j < 2.5 * self.scale + 0.8:
                return True
        return False

    def mortar_dodge(self):
        (j0, k0, l0) = self.pos
        l = self.wc.get('mortar', {}).get('gravity', 22.0)
        i0 = self.wc.get('mortar', {}).get('splash_radius', 7.0)
        for e0 in self.obs.get('projectiles') or []:
            if e0.get('kind') != 'mortar':
                continue
            (a0, b0, d0, q) = gn.shell_impact(e0['pos'], e0['vel'], l, self.A)
            g0 = j0 + self.me['vel'][0] * q
            h0 = k0 + self.me['vel'][1] * q
            if d2(g0, h0, a0, b0) < i0 + 3.0 * self.scale + 1.0 and q < 5.0:
                (f, j) = unit(j0 - a0, k0 - b0)
                if f == 0 and j == 0:
                    (f, j) = (1.0, 0.0)
                return (f, j)
        return None

    def gunnery(self, intent: Intent):
        z1 = self.t
        f1 = self.me
        (k2, l2, n2) = self.pos
        (i2, j2) = (f1['vel'][0], f1['vel'][1])
        i0 = [False, False]
        p1 = False
        u1 = (k2 + i2 * 0.05, l2 + j2 * 0.05, n2 + self.muzzle_h)
        b2 = intent.shoot
        f = None
        w0 = next((i for (i, w) in enumerate(self.weap) if w and w['kind'] == 'laser'), None)
        l0 = next((i for (i, w) in enumerate(self.weap) if w and w['kind'] == 'gun'), None)
        y0 = next((i for (i, w) in enumerate(self.weap) if w and w['kind'] == 'lightning'), None)
        g1 = next((i for (i, w) in enumerate(self.weap) if w and w['kind'] == 'mortar'), None)
        (b0, a0) = (f1['aim'][0], f1['aim'][1])
        if b2 is not None:
            s0 = getattr(b2, 'kind', '') == 'mech'
            u0 = getattr(b2, 'kind', '') == 'npc'
            f2 = b2.pos
            h2 = getattr(b2, 'vel', None) or [0.0, 0.0, 0.0]
            if s0:
                t1 = gn.body_scale(b2.cubes, self.size_per_cube)
                (n0, o1) = (9.0 * t1, 2.5 * t1)
            elif u0:
                (n0, o1) = (3.5, 1.8)
            else:
                (n0, o1) = (2.4, 1.4)
            d0 = d2(k2, l2, f2[0], f2[1])
            e0 = self.exposed_point(u1[0], u1[1], u1[2], f2[0], f2[1], f2[2], n0, o1)
            z0 = e0 is not None
            j = 0.5 * n0
            if e0 is not None:
                j = e0[2]
                if e0[0] or e0[1]:
                    f2 = [f2[0] + e0[0] * 0.8, f2[1] + e0[1] * 0.8, f2[2]]
                    o1 *= 0.5
            k0 = None
            if l0 is not None:
                m0 = self.weap[l0]
                x1 = m0['stats'].get('speed', 252.0)
                x0 = 0.05 + min(0.05, max(0.0, m0.get('cooldown', 0.0)))
                (l1, m1, n1, a2) = gn.lead(u1, f2, h2, x1, x0, 3.0 * self.scale, j, self.A)
                k0 = gn.aim_to(u1, l1, m1, n1)
            a1 = None
            if w0 is not None:
                (l1, m1, n1) = gn.predict(f2, h2, 0.075, self.A)
                a1 = gn.aim_to(u1, l1, m1, n1 + j)
            b1 = self.weap[w0] if w0 is not None else None
            v0 = False
            if b1 is not None:
                l = b1.get('charge') or 0.0
                j0 = b1['stats'].get('charge', 0.75)
                s1 = b1['stats'].get('range', 280.0)
                q0 = z0 and d0 <= s1
                if l > 0:
                    if self.laser_hold_start is None:
                        self.laser_hold_start = z1 - l
                    o0 = z1 - self.laser_hold_start
                    if l >= j0 - 0.051 and q0:
                        v0 = True
                        h0 = abs(adiff(b0, a1[0]))
                        g0 = abs(a0 - a1[1])
                        c2 = gn.angular_radius(max(d0, 1.0), o1) * self.P.laser_aim_tol
                        e2 = gn.angular_radius(max(d0, 1.0), 0.45 * n0)
                        if h0 <= c2 and g0 <= e2:
                            i0[w0] = False
                            self.laser_hold_start = None
                        else:
                            i0[w0] = True
                    elif o0 > j0 + 1.6:
                        i0[w0] = False
                        self.laser_hold_start = None
                    else:
                        i0[w0] = True
                        if l >= j0 - 0.12 and q0:
                            v0 = True
                else:
                    self.laser_hold_start = None
                    if b1.get('cooldown', 0) <= 0.1 and (q0 or (d0 < 120 and s0)) and (s0 or u0 or d0 < 200):
                        if not (intent.mode == 'retreat' and (not s0)):
                            i0[w0] = True
            if v0 and a1 is not None:
                f = a1
            elif k0 is not None:
                f = k0
            elif a1 is not None:
                f = a1
            else:
                f = gn.aim_to(u1, f2[0], f2[1], f2[2] + j)
            if l0 is not None and k0 is not None and z0:
                m0 = self.weap[l0]
                if d0 <= m0['stats'].get('range', 230.0) * 0.98 and (m0.get('reload', 0) or 0) <= 0:
                    h0 = abs(adiff(b0, k0[0]))
                    g0 = abs(a0 - k0[1])
                    c2 = gn.angular_radius(max(d0, 1.0), o1) * self.P.gun_aim_tol + 0.004
                    e2 = gn.angular_radius(max(d0, 1.0), 0.45 * n0) + 0.004
                    if h0 <= c2 + 0.02 and g0 <= e2 + 0.02 and (not v0):
                        i0[l0] = True
                    elif d0 < 25:
                        i0[l0] = h0 < 0.3
            if y0 is not None and z0:
                d1 = self.weap[y0]
                y1 = d1['stats']
                q = math.radians(y1.get('cone_deg', 30.0)) * 0.5
                if d0 <= y1.get('range', 45.0) * 0.97 and abs(adiff(b0, bearing(k2, l2, f2[0], f2[1]))) < q * 0.9:
                    q1 = self.P.lightning_energy_reserve
                    if f1.get('energy', 0) > q1 or (s0 and b2.hp < 200):
                        if s0 or u0 or d0 < 30:
                            i0[y0] = True
            if g1 is not None:
                i1 = self.weap[g1]
                if i1.get('cooldown', 0) <= 0.05 and d0 >= self.P.mortar_min_range:
                    v1 = math.hypot(h2[0], h2[1]) < self.P.mortar_max_target_speed or not s0
                    if (v1 or not z0) and (f is None or not i0[l0 if l0 is not None else 0]):
                        y1 = i1['stats']
                        g2 = (k2, l2, n2 + (self.mc.get('height', 9.0) + 0.5) * self.scale)
                        h1 = None
                        for p0 in (False, True):
                            (l1, m1, n1) = gn.predict(f2, h2, 1.5, self.A, damp=0.6)
                            w1 = gn.mortar_solution(g2, (l1, m1, n1 + 0.5), y1.get('speed', 72.0), y1.get('gravity', 22.0), 3.0 * self.scale, p0, self.mc.get('min_pitch', -0.7), self.mc.get('max_pitch', 1.3))
                            if w1 is None:
                                continue
                            (m2, j1, a2) = w1
                            (l1, m1, n1) = gn.predict(f2, h2, a2, self.A, damp=0.6)
                            w1 = gn.mortar_solution(g2, (l1, m1, n1 + 0.5), y1.get('speed', 72.0), y1.get('gravity', 22.0), 3.0 * self.scale, p0, self.mc.get('min_pitch', -0.7), self.mc.get('max_pitch', 1.3))
                            if w1 is not None and (p0 or z0 or True):
                                h1 = w1
                                break
                        if h1 is not None and (not v0) and (not any(i0)):
                            f = (h1[0], h1[1])
                            if abs(adiff(b0, h1[0])) < 0.03 and abs(a0 - h1[1]) < 0.03:
                                i0[g1] = True
        else:
            if w0 is not None:
                b1 = self.weap[w0]
                if (b1.get('charge') or 0) > 0:
                    if self.laser_hold_start is None:
                        self.laser_hold_start = z1 - (b1.get('charge') or 0)
                    if z1 - self.laser_hold_start < b1['stats'].get('charge', 0.75) + 1.5 and intent.target is not None:
                        i0[w0] = True
                    else:
                        self.laser_hold_start = None
            f = self.scan_aim(intent)
            if l0 is not None:
                m0 = self.weap[l0]
                e1 = m0['stats'].get('mag', 12)
                if (m0.get('ammo', e1) or 0) < e1 * self.sq('reload_below_frac', 0.6) and (m0.get('reload', 0) or 0) <= 0 and (not self.enemies):
                    p1 = True
        if f is None:
            f = (b0, 0.0)
        k1 = clamp(f[1], self.mc.get('min_pitch', -0.7), self.mc.get('max_pitch', 1.3))
        if any(i0):
            self.last_fire_t = z1
        return ((wrap(f[0]), k1), i0, p1)

    def scan_aim(self, intent: Intent):
        (m0, n0) = (self.pos[0], self.pos[1])
        k0 = self.t
        if intent.target is not None:
            l0 = intent.target
            return (bearing(m0, n0, l0.pos[0], l0.pos[1]), 0.0)
        if intent.face is not None:
            return (intent.face + 0.35 * math.sin(2 * math.pi * k0 / 1.6), 0.0)
        e0 = self.W.threat_bearing(4.0)
        j = 0.9
        if e0 is None:
            l = None
            for l0 in self.W.mechs.values():
                f = k0 - l0.last_seen
                if f < 12:
                    b0 = d2(m0, n0, l0.pos[0], l0.pos[1])
                    if l is None or b0 < l[0]:
                        l = (b0, l0)
            if l is not None:
                e0 = bearing(m0, n0, l[1].pos[0], l[1].pos[1])
                j = 0.6
        if e0 is None:
            (a0, j0) = self.zn
            g0 = self.last_move
            if math.hypot(g0[0], g0[1]) > 0.3:
                h0 = math.atan2(g0[1], g0[0])
            else:
                h0 = None
            d0 = d2(m0, n0, a0[0], a0[1])
            if d0 > 30:
                q = bearing(m0, n0, a0[0], a0[1])
                e0 = q if h0 is None else math.atan2(math.sin(q) + math.sin(h0), math.cos(q) + math.cos(h0))
            elif h0 is not None:
                e0 = h0
            else:
                e0 = self.me['aim'][0]
            j = 1.25 if intent.mode not in ('explore', 'loot') else math.pi
        i0 = self.P.scan_period_s
        return (wrap(e0 + j * math.sin(2 * math.pi * k0 / i0 + self.slot)), 0.0)

    def loot_actions(self, intent: Intent, action: dict):
        (b0, d0, e0) = self.pos
        f = None
        for q in self.obs.get('pickups') or []:
            if d2(b0, d0, q['pos'][0], q['pos'][1]) > self.loot_reach - 0.3 or abs(q['pos'][2] - e0) > 3.8:
                continue
            (l, a0) = self.loadout_gain(q.get('kind'))
            if l <= 0 or (a0 is not None and l < self.P.swap_margin):
                continue
            if self.blacklist.get(q['id'], -1) > self.t:
                continue
            if f is None or l > f[0]:
                f = (l, q, a0)
        if f is not None:
            (l, q, a0) = f
            action['take'] = q['id']
            if a0 is not None:
                action['drop'] = a0
            self.blacklist[q['id']] = self.t + 1.0
        for j in self.obs.get('events') or []:
            if j.get('type') == 'take_failed':
                self.blacklist[j.get('id')] = self.t + (20.0 if j.get('reason') in ('gone', 'have') else 2.0)

    def pick_upgrade(self, offer: dict):
        q = offer.get('choices') or []
        if not q:
            return None
        have = self.me.get('upgrades') or []
        d0 = self.P.upgrade_value
        if getattr(self, 'squad', False) and self.P.get('squad_dmg_upgrades'):
            d0 = dict(d0, **self.P.get('squad_upgrade_value', {}))
        (f, j) = (0, -1000000000.0)
        for (a0, l) in enumerate(q):
            cid = l.get('id', '')
            e0 = d0.get(cid, 2.0)
            b0 = sum((1 for u in have if u == cid))
            e0 *= 0.85 ** b0
            if cid.startswith('laser') and 'laser' not in self.kinds:
                e0 *= 0.3
            if cid.startswith('gun') and 'gun' not in self.kinds:
                e0 *= 0.3
            if cid.startswith('lightning') and 'lightning' not in self.kinds:
                e0 *= 0.3
            if cid.startswith('mortar') and 'mortar' not in self.kinds:
                e0 *= 0.3
            if e0 > j:
                (j, f) = (e0, a0)
        return f
