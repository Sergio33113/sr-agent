"""The bot: one act() per observation.

Pipeline per decision (10 Hz):
  perceive  -> World.update (tracks, items, threats, mode evidence)
  assess    -> zone pressure, per-enemy fight evaluation (damage race at each range)
  decide    -> one intent: retreat / fight / drop / loot / hold
  pilot     -> movement: A* path + strafing + wall steering + dodging + unstick
  gunnery   -> aim and per-slot trigger logic (gun lead, laser charge/release, lightning, mortar)
  upkeep    -> upgrade pick, take/drop, reload, debug label

Everything numeric about the game comes from hello.config; behaviour knobs live in params.py.
"""
from __future__ import annotations

import gc
import math
import random
import time

from . import gunnery as gn
from .arena import Arena
from .geometry import adiff, bearing, clamp, d2, unit, wrap
from .nav import NavGrid
from .params import load as load_params
from .world import World

try:
    import mechfight as _mf  # debug drawing helper when running under the kit wrapper
except Exception:  # pragma: no cover
    _mf = None

HOLD_RANGES = (22.0, 35.0, 50.0, 70.0, 95.0, 125.0, 160.0, 200.0)


class Intent:
    __slots__ = ("mode", "goal", "target", "shoot", "dist_pref", "strafe", "boost", "face", "pickup", "note", "evasive")

    def __init__(self, mode, goal=None, target=None, shoot=None, dist_pref=None, strafe=False, boost=False,
                 face=None, pickup=None, note=""):
        self.mode, self.goal, self.target, self.shoot = mode, goal, target, shoot
        self.dist_pref, self.strafe, self.boost, self.face = dist_pref, strafe, boost, face
        self.pickup, self.note = pickup, note
        self.evasive = False


class Brain:
    name = "OSU Ironclad"

    # ================================================================== setup
    def __init__(self, hello: dict):
        self.cfg = cfg = hello["config"]
        self.P = load_params()
        self.slot = int(hello.get("slot", 0))
        self.rng = random.Random(hello.get("seed", 0) or 0)
        mdir = (hello.get("map") or {}).get("dir", "/arena")
        self.A = Arena(mdir, cfg.get("mech", {}))
        self.N = NavGrid(self.A)
        self.W = World(cfg, self.slot)
        self.mc = cfg.get("mech", {})
        self.wc = cfg.get("weapons", {})
        self.zc = cfg.get("zone", {})
        self.loot_reach = float(cfg.get("loot", {}).get("pickup_radius", 4.0))
        self.cube_reach = float(cfg.get("cubes", {}).get("pickup_radius", 3.5))
        self.size_per_cube = float(cfg.get("cubes", {}).get("size_per_cube", 0.05))
        self.dmg_per_cube = float(cfg.get("cubes", {}).get("damage_per_cube", 0.04))
        self.cube_cap = float(cfg.get("cubes", {}).get("stat_cap", 10))
        self.rear_mult = float(self.mc.get("rear_mult", 1.5))
        # path state
        self.path = []
        self.path_goal = None
        self.path_t = -99.0
        self.search = None
        self.search_goal = None
        # movement state
        self.strafe_dir = 1 if self.rng.random() < 0.5 else -1
        self.strafe_until = 0.0
        self.stuck_since = None
        self.unstick_until = -1.0
        self.unstick_dir = (0.0, 0.0)
        self.last_move = (0.0, 0.0)
        # progress watchdog (B12): the goal we walk to, the closest we got to it, and when we last got closer
        self.wd_key = None
        self.wd_best = 1e9
        self.wd_t = 0.0
        self.wd_escapes = 0
        self.bad_goals = []  # (x, y, until): goals that stalled, skipped until `until`
        self.bad_count = {}  # 8 m bucket -> times a goal there stalled (the ban doubles each time)
        self.escape_until = -1.0
        self.escape_dir = (0.0, 0.0)
        # combat state
        self.target_id = None
        self.los_seen = {}
        self.evade = False
        self.retreating = False
        self.squad = False  # practice house squad rules on (set each tick in _act)
        self.retreat_spot = None
        self.retreat_spot_t = -99.0
        self.laser_hold_start = None
        self.last_fire_t = -99.0
        # zone state
        self.phase_from = None  # (shrink_start, center, radius) observed before the shrink
        self.hold = None
        self.hold_t = -99.0
        self.hold_key = None
        # loot state
        self.loot_goal = None
        self.blacklist = {}
        self.visited = set()
        self.explore_target = None
        self.explore_t = -99.0
        self.ticks = 0
        self.act_ms = 0.0
        gc.collect()
        try:
            gc.freeze()
        except AttributeError:
            pass
        gc.disable()

    # ================================================================== main loop
    def act(self, obs: dict) -> dict:
        try:
            return self._act(obs)
        except Exception as e:  # never freeze: fall back to a simple safe policy for this tick
            self.errors = getattr(self, "errors", 0) + 1
            if self.errors <= 5 or self.errors % 200 == 0:
                import sys
                import traceback
                print(f"act error #{self.errors} at t={obs.get('t')}: {e!r}\n{traceback.format_exc()}", file=sys.stderr, flush=True)
            self.path = []
            self.search = None
            return self.safe_act(obs)

    def safe_act(self, obs: dict) -> dict:
        """Minimal policy: walk into the next circle (wall-steered), shoot the nearest visible mech."""
        me = obs["self"]
        x, y, z = me["pos"]
        zc = obs["zone"]["next_center"]
        mx, my = unit(zc[0] - x, zc[1] - y)
        if d2(x, y, zc[0], zc[1]) < 0.4 * obs["zone"]["next_radius"]:
            mx = my = 0.0
        try:
            self.pos = me["pos"]
            if mx or my:
                mx, my = self.steer(mx, my)
        except Exception:
            pass
        act = {"move": [mx, my], "boost": not me.get("in_zone", True), "aim": [math.atan2(my, mx) if (mx or my) else me["aim"][0], 0.0]}
        best = None
        for m in obs.get("mechs") or []:
            if m.get("kind") != "mech":
                continue
            d = math.dist(m["pos"][:2], (x, y))
            if best is None or d < best[0]:
                best = (d, m)
        if best is not None and best[0] < 200:
            px, py, pz = best[1]["pos"]
            act["aim"] = [math.atan2(py - y, px - x), math.atan2(pz + 4.5 - z - 7.0, max(1.0, best[0]))]
            act["fire"] = [True, True]
        if obs.get("offer"):
            act["pick"] = 0
        return act

    def _act(self, obs: dict) -> dict:
        t0 = time.perf_counter()
        self.tick_t0 = t0
        self.rays0 = self.A.rays
        self.ticks += 1
        W = self.W
        W.update(obs)
        self.obs = obs
        me = obs["self"]
        self.me = me
        self.t = t = obs["t"]
        self.pos = me["pos"]
        self.hpf = me["hp"] / max(1.0, me["max_hp"])
        self.scale = gn.body_scale(me.get("cubes", 0), self.size_per_cube)
        st = me.get("stats") or {}
        self.walk = float(st.get("walk_speed", self.mc.get("walk_speed", 11.7)))
        self.muzzle_h = float(st.get("muzzle_height", self.mc.get("muzzle_height", 7.0) * self.scale))
        self.eye_h = float(st.get("eye_height", self.mc.get("eye_height", 8.0) * self.scale))
        self.weap = me.get("weapons") or [None, None]
        self.kinds = [w["kind"] if w else None for w in self.weap]
        # practice house squad: no free-for-all evidence after squad_after_s (the final is a free-for-all)
        self.squad = bool(self.P.get("squad_mode")) and not W.is_ffa() and t >= self.P.get("squad_after_s", 30.0)
        action: dict = {}
        if obs.get("offer"):
            pk = self.pick_upgrade(obs["offer"])
            if pk is not None:
                action["pick"] = pk
        self.zone_update(obs["zone"])
        self.los_cache = {}
        intent = self.decide()
        if self.P.get("wd_on", True):
            self.watchdog(intent)
        self.return_fire(intent)
        mv, boost, jump = self.pilot(intent)
        aim, fire, reload = self.gunnery(intent)
        mlen = math.hypot(mv[0], mv[1])
        if mlen > 0.9999:
            mv = (mv[0] * 0.9999 / mlen, mv[1] * 0.9999 / mlen)  # stay within the unit disc after rounding
        action["move"] = [round(mv[0], 4), round(mv[1], 4)]
        action["boost"] = bool(boost)
        action["jump"] = bool(jump)
        action["aim"] = [round(aim[0], 5), round(aim[1], 5)]
        action["fire"] = fire
        if reload:
            action["reload"] = True
        self.loot_actions(intent, action)
        self.intent = intent
        el = (time.perf_counter() - t0) * 1000.0
        self.act_ms = el
        if self.P.get("debug_draw") and _mf is not None:
            try:
                tid = intent.target.id if intent.target is not None else "-"
                _mf.draw.label(f"{intent.mode} {tid} hp{self.hpf:.2f} {intent.note}"[:78])
            except Exception:
                pass
        if self.ticks % 150 == 0 and el < 8.0:
            gc.collect(0)
        return action

    # ================================================================== zone
    def circle_at(self, z, t):
        """Zone circle at time t (handles both live-interpolated and phase-start reporting)."""
        ss, se = z["shrink_start"], z["shrink_end"]
        c0, r0 = z["center"], z["radius"]
        c1, r1 = z["next_center"], z["next_radius"]
        if self.phase_from is not None and self.phase_from[0] == ss:
            c0, r0 = self.phase_from[1], self.phase_from[2]
        if t <= ss:
            return c0, r0
        if t >= se:
            return c1, r1
        s = (t - ss) / max(1e-6, se - ss)
        return (c0[0] + (c1[0] - c0[0]) * s, c0[1] + (c1[1] - c0[1]) * s), r0 + (r1 - r0) * s

    def zone_update(self, z):
        t = self.t
        if t < z["shrink_start"]:
            self.phase_from = (z["shrink_start"], tuple(z["center"]), z["radius"])
        x, y = self.pos[0], self.pos[1]
        cn, rn = z["next_center"], z["next_radius"]
        self.zn = (cn, rn)
        self.zcur = self.circle_at(z, t)
        margin = min(self.P.zone_margin, 0.3 * rn)
        dn = d2(x, y, cn[0], cn[1])
        self.inside_next = dn <= rn - margin
        # when does the boundary reach us?
        if dn <= rn:
            t_reach = 1e9
        else:
            ss, se = z["shrink_start"], z["shrink_end"]
            lo, hi = 0.0, 1.0
            c0, r0 = self.circle_at(z, ss)
            f0 = r0 - d2(x, y, c0[0], c0[1])
            if f0 <= 0:
                t_reach = t  # already outside the circle as it starts shrinking
            else:
                for _ in range(18):
                    mid = 0.5 * (lo + hi)
                    tc = ss + (se - ss) * mid
                    c, r = self.circle_at(z, tc)
                    if r - d2(x, y, c[0], c[1]) > 0:
                        lo = mid
                    else:
                        hi = mid
                t_reach = ss + (se - ss) * lo
        need = max(0.0, dn - (rn - margin))
        travel = need / max(1.0, self.walk) * 1.3
        self.zone_slack = (t_reach - t) - travel
        self.outside = not self.me.get("in_zone", True)
        self.zone_dps = z.get("dps", 0.0)
        # hold point (recomputed every few seconds or on phase change)
        key = (round(cn[0], 1), round(cn[1], 1), rn)
        if key != self.hold_key or t - self.hold_t > 4.0 or self.hold is None:
            self.hold_key = key
            self.hold_t = t
            self.hold = self.pick_hold(cn, rn)

    def pick_hold(self, cn, rn):
        x, y = self.pos[0], self.pos[1]
        if rn <= 1.0:
            n = self.N.nearest_free(cn[0], cn[1], 20)
            return self.N.pos(n) if n is not None else (cn[0], cn[1])
        frac = self.P.zone_hold_frac
        if rn <= 75:
            frac = 0.3
        if rn <= 30:
            frac = 0.15
        dn = d2(x, y, cn[0], cn[1])
        ux, uy = unit(x - cn[0], y - cn[1])
        if ux == 0 and uy == 0:
            ux, uy = 1.0, 0.0
        r = min(dn, frac * rn)
        N = self.N
        if dn <= frac * rn + 8 and N.is_free(x, y) and N.cover[N.node(x, y)]:
            return (x, y)
        hx, hy = cn[0] + ux * r, cn[1] + uy * r
        reach = max(3, min(12, int(0.12 * rn / N.k)))
        n = N.nearest_cover(hx, hy, reach)
        if n is not None:
            px, py = N.pos(n)
            if d2(px, py, cn[0], cn[1]) > rn - min(self.P.zone_margin, 0.3 * rn):
                n = None
        if n is None:
            n = N.nearest_free(hx, hy, 15)
        if n is None:
            n = self.N.nearest_free(cn[0], cn[1], 25)
        return self.N.pos(n) if n is not None else (cn[0], cn[1])

    def in_safe(self, px, py, slack_m=0.0):
        cn, rn = self.zn
        c, r = self.zcur
        ok_now = d2(px, py, c[0], c[1]) <= r - 2
        return ok_now and (d2(px, py, cn[0], cn[1]) <= rn - slack_m or self.zone_slack > 15)

    # ================================================================== perception helpers
    def los_to(self, tr, eye=False):
        """Line of fire from our muzzle (or eye) to the body of track tr (centre or top)."""
        key = (tr.id, eye)
        v = self.los_cache.get(key)
        if v is not None:
            return v
        x, y, z = self.pos
        sz = z + (self.eye_h if eye else self.muzzle_h)
        mech = getattr(tr, "kind", "mech") == "mech"
        sc = gn.body_scale(getattr(tr, "cubes", 0), self.size_per_cube) if mech else 1.0
        h = 9.0 * sc if mech else 3.5
        r = 2.5 * sc if mech else 1.8
        px, py, pz = tr.pos
        v = self.exposed_point(x, y, sz, px, py, pz, h, r) is not None
        self.los_cache[key] = v
        return v

    def exposed_point(self, sx, sy, sz, px, py, pz, h, r):
        """First point of a (radius r, height h) body at feet (px, py, pz) with a clear line from
        (sx, sy, sz): centre, upper body, then the left/right edges. Returns (dx, dy, dz) offset or None."""
        A = self.A
        ux, uy = unit(px - sx, py - sy)
        ex, ey = -uy * r * 0.75, ux * r * 0.75
        for ox, oy, fz in ((0.0, 0.0, 0.5), (0.0, 0.0, 0.82), (ex, ey, 0.5), (-ex, -ey, 0.5), (ex, ey, 0.82), (-ex, -ey, 0.82)):
            if A.los(sx, sy, sz, px + ox, py + oy, pz + fz * h):
                return ox, oy, fz * h
        return None

    def their_los_to_point(self, tr, px, py, pz):
        """Can enemy tr see/shoot a mech standing at (px, py, pz)?"""
        ex, ey, ez = tr.pos
        sz = ez + 8.0 * gn.body_scale(tr.cubes, self.size_per_cube)
        return self.exposed_point(ex, ey, sz, px, py, pz, 9.0 * self.scale, 2.5 * self.scale) is not None

    def sq(self, key, default):
        """Parameter `key`, or its `squad_` variant while the practice house squad is detected."""
        if getattr(self, "squad", False):
            v = self.P.get("squad_" + key)
            if v is not None:
                return v
        return self.P.get(key, default)

    def cube_mult(self, cubes):
        return 1.0 + self.dmg_per_cube * min(cubes or 0, self.cube_cap)

    # ================================================================== damage model
    def weapon_dps(self, kind, d, stats=None, cubes=0, vs_mortar=False, energy=100.0):
        wc = stats or self.wc.get(kind, {})
        m = self.cube_mult(cubes)
        if kind == "gun":
            rng = wc.get("range", 230)
            if d > rng:
                return 0.0
            cd = max(0.05, wc.get("cooldown", 0.24))
            mag = wc.get("mag", 12)
            sustain = (mag * cd) / (mag * cd + wc.get("reload", 2.4))
            hit = clamp(1.05 - d / 240.0, 0.12, 0.95)
            return wc.get("damage", 45) / cd * sustain * hit * m
        if kind == "laser":
            if d > wc.get("range", 280):
                return 0.0
            cyc = wc.get("charge", 0.75) + wc.get("cooldown", 1.65)
            dmg = wc.get("damage", 315) * (1.0 + (wc.get("cookoff", 0.6) if vs_mortar else 0.0))
            return dmg / cyc * 0.9 * m
        if kind == "lightning":
            if d > wc.get("range", 45) * 0.95:
                return 0.0
            ok = 1.0 if energy > 20 else 0.4
            return wc.get("damage", 60) / max(0.05, wc.get("cooldown", 0.25)) * 0.95 * ok * m
        if kind == "mortar":
            if d < 18 or d > 225:
                return 0.0
            return (wc.get("damage", 200) * 0.5 + wc.get("splash", 160) * 0.5) / wc.get("cooldown", 2.6) * 0.3 * m
        return 0.0

    def behind(self, tr):
        """True if we are outside tr's front arc (our hits on it count x rear_mult)."""
        b = bearing(tr.pos[0], tr.pos[1], self.pos[0], self.pos[1])
        return abs(adiff(tr.aim[0], b)) > 0.5 * math.radians(self.mc.get("front_arc_deg", 180.0))

    def exposed_to(self, tr):
        """True if tr is outside our front arc (its hits on us count x rear_mult)."""
        b = bearing(self.pos[0], self.pos[1], tr.pos[0], tr.pos[1])
        return abs(adiff(self.me["aim"][0], b)) > 0.5 * math.radians(self.mc.get("front_arc_deg", 180.0))

    def my_dps(self, d, tr=None):
        s = 0.0
        vs_mortar = tr is not None and "mortar" in (tr.weapons or [])
        for w in self.weap:
            if w:
                s += self.weapon_dps(w["kind"], d, w.get("stats"), self.me.get("cubes", 0), vs_mortar, self.me.get("energy", 100))
        if tr is not None and getattr(tr, "kind", "mech") == "mech" and self.behind(tr):
            s *= self.rear_mult
        return s

    def their_dps(self, tr, d, facing_them=True):
        s = 0.0
        mine_mortar = "mortar" in self.kinds
        for k in tr.weapons or ["gun"]:
            s += self.weapon_dps(k, d, None, tr.cubes, mine_mortar)
        if not facing_them:
            s *= self.rear_mult
        return s

    # ================================================================== decide
    def decide(self) -> Intent:
        W = self.W
        P = self.P
        t = self.t
        x, y, z = self.pos
        me = self.me
        enemies = []
        for tr in W.mechs.values():
            if not tr.listed:
                continue
            d = d2(x, y, tr.pos[0], tr.pos[1])
            if d > 260:
                continue
            enemies.append((d, tr))
        enemies.sort(key=lambda e: e[0])
        self.enemies = enemies
        # how many can currently shoot at us
        hostile = []
        for d, tr in enemies:
            los = self.los_to(tr, eye=True)
            b_to_me = bearing(tr.pos[0], tr.pos[1], x, y)
            aiming = abs(adiff(tr.aim[0], b_to_me)) < 0.35
            recent_hit = t - tr.last_hit_me < 3.0
            if los and (aiming or recent_hit or d < 60):
                hostile.append((d, tr))
        self.hostile = hostile
        incoming = W.recent_damage(2.5)
        # ---------------- retreat logic
        n_close = sum(1 for d, tr in hostile if d < 130)
        want_retreat = False
        if self.hpf < P.retreat_hp_frac + 0.1 and (hostile or incoming > 0):
            want_retreat = True
        if n_close >= 2 and self.hpf < 0.7:
            want_retreat = True
        if n_close >= 3 and self.hpf < 0.85:
            want_retreat = True
        # don't retreat from a fight we're clearly winning against a single weak target
        if want_retreat and len(hostile) == 1:
            d, tr = hostile[0]
            ours = self.my_dps(d, tr)
            theirs = self.their_dps(tr, d)
            if ours > 1 and tr.hp / ours < 0.55 * me["hp"] / max(1.0, theirs):
                want_retreat = False
        if self.squad and P.get("squad_no_retreat"):
            # House squad: hunters share vision and chase, so running gives them free hits (practice traces:
            # 50 of 90 deaths came while retreating). Fight while any can shoot us; heal once none can.
            if hostile or t - W.last_damage_t < 2.0 or (P.get("squad_hyper") and enemies):
                want_retreat = False  # hyper: no hiding to heal while there is a mech to chase
                self.retreating = False
            elif self.hpf < P.get("squad_heal_below", 0.8):
                want_retreat = True
        if want_retreat:
            self.retreating = True
        if self.retreating:
            quiet = t - W.last_damage_t > 6.0 and not hostile
            if self.hpf >= 0.85 or (quiet and self.hpf > 0.6 and t - W.last_damage_t > 12):
                self.retreating = False
        # ---------------- target choice
        target, tscore = None, -1e9
        for d, tr in enemies:
            ours = self.my_dps(d, tr)
            if ours <= 0 and d > 60:
                continue
            los = self.los_to(tr)
            if los:
                self.los_seen[tr.id] = t
            theirs = self.their_dps(tr, d)
            kill_t = tr.hp / max(1.0, ours)
            sc = -kill_t
            sc += theirs / 100.0
            if t - tr.last_hit_me < 4:
                sc += 3.0
            if tr.hp < 350:
                sc += 3.0
            if not los:
                sc -= 6.0
            if tr.id == self.target_id:
                sc += 1.5
            if sc > tscore:
                target, tscore = tr, sc
        if self.squad and P.get("squad_smith_target") and len(hostile) >= 2:
            # Several shooters at once: the damage we take before they are all dead is smallest when we kill
            # them in order of (their dps / our time to kill) (Smith's rule, weighted shortest processing time).
            best, bv, cur_v = None, -1.0, -1.0
            for d, tr in hostile:
                if not self.los_to(tr):
                    continue
                ours = self.my_dps(d, tr)
                if ours <= 0:
                    continue
                v = self.their_dps(tr, d, not self.exposed_to(tr)) / max(0.5, tr.hp / ours)
                if tr.id == self.target_id:
                    cur_v = v
                if v > bv:
                    best, bv = tr, v
            if best is not None and (target is None or best is target or bv > 1.25 * cur_v):
                target = best
        self.target_id = target.id if target is not None else None
        # ---------------- retreat intent
        if self.retreating and (hostile or t - W.last_damage_t < 5.0):
            spot = self.cover_spot()
            close_threat = None
            for d, tr in enemies:
                if d < 45 and self.los_to(tr):
                    close_threat = tr
                    break
            shoot = close_threat if close_threat is not None else (target if target is not None and self.los_to(target) else None)
            goal = spot
            note = "cover"
            if (goal is not None and target is not None and self.squad and t >= P.get("exposure_after_s", 30.0)
                    and P.get("squad_retreat_exposure", True) and self.los_to(target)):
                # Practice only, and only after 30 s: before then a free-for-all may not be detected yet (first death
                # we didn't cause: median 12 s, max 30 s in the final-like league), and there this rule hurt (E3v: C
                # -0.94 vs B; E4 seed 9025: dead at 13.8 s where B won). A far hiding place is not safety: run only
                # if we reach cover well before we would die on the way and before we could kill the target.
                dd = d2(x, y, target.pos[0], target.pos[1])
                v = self.walk * (1.6 if me.get("energy", 0) > 30 else 1.0)
                t_cover = d2(x, y, goal[0], goal[1]) / max(1.0, v)
                inc = max(W.recent_damage(2.5) / 2.5, sum(self.their_dps(o, od) for od, o in hostile))
                t_die = me["hp"] / max(1.0, inc)
                t_kill = target.hp / max(1.0, self.my_dps(dd, target))
                if t_cover > P.get("retreat_cover_die_frac", 0.6) * t_die or t_kill < t_cover:
                    goal = None
            if goal is None and target is not None and self.los_to(target):
                # cornered in the open: running only gives free hits, so fight it out
                return Intent("fight", target=target, shoot=target, dist_pref=self.pref_range(target), strafe=True,
                              boost=False, note="cornered")
            if goal is None:
                # no hiding place found: open distance from the threat, staying inside the zone
                tb = None
                if target is not None:
                    tb = bearing(x, y, target.pos[0], target.pos[1])
                else:
                    tb = W.threat_bearing(5.0)
                if tb is not None:
                    ax, ay = x - 30 * math.cos(tb), y - 30 * math.sin(tb)
                    hx, hy = self.hold
                    if not self.in_safe(ax, ay, -10):
                        ax, ay = (ax + hx) * 0.5, (ay + hy) * 0.5
                    goal = (ax, ay)
                else:
                    goal = self.hold
                note = "run"
            return Intent("retreat", goal=goal, target=target, shoot=shoot, strafe=False,
                          boost=True, note=note)
        # ---------------- healing: stay hidden and don't deal damage (it resets the regen timer)
        if self.retreating:
            finish = None
            if target is not None and target.hp < 260 and self.los_to(target):
                dd = d2(x, y, target.pos[0], target.pos[1])
                if target.hp / max(1.0, self.my_dps(dd, target)) < 0.5 * me["hp"] / max(1.0, self.their_dps(target, dd)):
                    finish = target
            if finish is None:
                if self.outside or self.zone_slack < P.zone_lead_s:
                    return Intent("zone", goal=self.hold, target=target, boost=True, note="heal-zone")
                spot = self.cover_spot()
                return Intent("heal", goal=spot if spot is not None else self.hold, target=target, note="heal")
        # ---------------- a charged laser is pointed at us: duck behind close cover
        for d, tr in hostile:
            if not tr.charging or d > 285:
                continue
            if abs(adiff(tr.aim[0], bearing(tr.pos[0], tr.pos[1], x, y))) > max(0.05, math.atan2(4.0, max(d, 1.0))):
                continue
            if "lightning" in self.kinds and d < 40:
                break  # our lightning shorts their charge: keep fighting (return_fire shoots it)
            spot = self.cover_spot(only=[tr])
            if spot is not None and d2(x, y, spot[0], spot[1]) <= 12.0:
                return Intent("dodge", goal=spot, target=tr, shoot=tr if self.los_to(tr) else None, boost=True,
                              note="laser")
            break
        # ---------------- alert: hit by someone we can't see
        if target is None and t - W.last_damage_t < 2.0:
            last = [e for e in W.dmg_taken_log[-6:] if t - e[0] < 2.0 and e[3] not in ("zone", None)]
            if last:
                tb = W.threat_bearing(2.0)
                if tb is not None:
                    pseudo = (x + 120.0 * math.cos(tb), y + 120.0 * math.sin(tb))
                    spot = None if (self.outside or self.zone_slack < P.zone_lead_s) else self.cover_spot(pseudo=pseudo)
                    return Intent("alert", goal=spot if spot is not None else self.hold, face=tb, boost=spot is not None,
                                  note="unseen")
        # ---------------- fight intent
        engage = None
        if target is not None:
            d = d2(x, y, target.pos[0], target.pos[1])
            ours = self.my_dps(d, target)
            theirs = self.their_dps(target, d)
            my_ttk = target.hp / max(1.0, ours)
            their_ttk = me["hp"] / max(1.0, theirs + sum(self.their_dps(o, dd, not self.exposed_to(o)) for dd, o in hostile if o is not target) * 0.7)
            attacked = t - target.last_hit_me < 4.0 or any(o is target for dd, o in hostile)
            adv = their_ttk / max(0.1, my_ttk)  # > 1: we win the damage race
            weak = target.hp < 0.45 * target.max_hp
            busy = t - target.fighting_t < 3.0
            practice = not W.is_ffa()
            aggr = P.aggression * (1.25 if practice else 1.0)
            grab = self.close_weapon(25.0)
            self.evade = False
            blind = t - self.los_seen.get(target.id, -99.0) > 2.0 and t - target.last_hit_me > 3.0
            if grab is not None and not (attacked and d < 60):
                engage = None  # take the better weapon first
            elif self.squad and P.get("squad_hyper"):
                # Practice squad, the recipe AT measured on the real board (their experiments C -> D1): attack
                # every mech we see and chase it out of sight. Kills are the practice score.
                engage = target
            elif blind and d > 30:
                engage = None  # no line of fire for a while: carry on, re-engage when it shows
            elif attacked and (adv >= 0.75 or d < 40 or (self.squad and P.get("squad_fight_back"))):
                engage = target
            elif attacked:
                self.evade = True  # losing trade in the open: break line of sight, shoot back on the way
            elif adv * aggr > P.engage_ratio:
                engage = target
            elif (weak and self.hpf > 0.4) or (busy and self.hpf > 0.5 and adv > 0.6):
                engage = target
            elif d < 45 and self.hpf > 0.3:
                engage = target
        zone_urgent = self.outside or self.zone_slack < P.zone_lead_s
        if engage is None and target is not None and getattr(self, "evade", False):
            spot = self.cover_spot()
            if spot is None and self.los_to(target):
                engage = target  # no cover in reach: trading shots beats taking them for free
        if engage is None and target is not None and getattr(self, "evade", False):
            spot = self.cover_spot()
            goal = spot if spot is not None else self.hold
            if zone_urgent and spot is not None and not self.in_safe(spot[0], spot[1], 0):
                goal = self.hold
            shoot = target if self.los_to(target) else None
            return Intent("evade", goal=goal, target=target, shoot=shoot, strafe=spot is None, boost=True,
                          dist_pref=200.0, note="cover" if spot else "open")
        if engage is not None:
            d_pref = self.pref_range(engage)
            goal = None
            if zone_urgent:
                goal = self.hold
            elif self.squad and P.get("squad_hyper") and not self.los_to(engage):
                goal = (engage.pos[0], engage.pos[1])  # chase it out of sight (the server tracks it 5 s)
            if goal is None and self.sq("fight_cube_m", 0) > 0 and self.hpf > self.sq("fight_cube_hp", 0.5):
                cube = self.near_cube(self.sq("fight_cube_m", 0))
                if cube is not None:
                    goal = (cube.pos[0], cube.pos[1])  # kill drops: take them mid-fight, still shooting
            return Intent("fight", goal=goal, target=engage, shoot=engage, dist_pref=d_pref, strafe=True,
                          boost=zone_urgent or self.outside, note=f"d{int(d2(x, y, engage.pos[0], engage.pos[1]))}>{int(d_pref)}")
        # visible enemy we chose not to fight: keep facing it, avoid exposure
        avoid = target
        # ---------------- zone first if urgent
        if zone_urgent:
            return Intent("zone", goal=self.hold, target=avoid, shoot=None, boost=self.outside or self.zone_slack < 0,
                          note=f"slack{int(self.zone_slack)}")
        # ---------------- supply drop
        dr = self.drop_goal()
        if dr is not None:
            if dr.target is None:
                dr.target = avoid
            return dr
        # ---------------- loot / farm / explore
        lt = self.loot_goal_pick()
        if lt is not None:
            if lt.target is None and avoid is not None:
                lt.target = avoid  # keep the torso (front armour, vision) on the enemy we see
            return lt
        # ---------------- hold
        note = "hold"
        goal = self.hold
        if avoid is not None:
            spot = self.cover_spot(only=[avoid])
            if spot is not None:
                goal = spot
                note = "hide"
        return Intent("hold", goal=goal, target=avoid, note=note)

    def return_fire(self, intent: Intent):
        """Never take fire without answering it: if something is shooting us and we have a line of
        fire, shoot it, whatever the movement intent. Also marks the intent evasive (zig-zag)."""
        t = self.t
        x, y = self.pos[0], self.pos[1]
        intent.evasive = bool(self.hostile) or t - self.W.last_damage_t < 1.5
        if intent.shoot is not None or intent.mode in ("heal",):
            return
        best, bd = None, 1e9
        for d, tr in self.hostile:
            if self.my_dps(d, tr) > 0 and self.los_to(tr) and d < bd:
                best, bd = tr, d
        if best is None:
            # drones that hit us recently (they chase their attacker and shoot 25/s)
            hit_by = {e[2] for e in self.W.dmg_taken_log[-8:] if t - e[0] < 3.0 and e[3] == "npc"}
            for n in self.W.npcs.values():
                if n.id in hit_by and t - n.last_seen < 0.3:
                    d = d2(x, y, n.pos[0], n.pos[1])
                    if d < 120 and self.los_to(n) and d < bd:
                        best, bd = n, d
        if best is not None:
            intent.shoot = best
            if intent.target is None:
                intent.target = best

    def pref_range(self, tr):
        """Distance where we win the damage race by the widest margin (kill-time ratio)."""
        my_hp = max(1.0, self.me["hp"])
        their_hp = max(1.0, tr.hp)
        x, y = self.pos[0], self.pos[1]
        dnow = d2(x, y, tr.pos[0], tr.pos[1])
        best, bv = dnow, -1e9
        for r in HOLD_RANGES:
            mine = self.my_dps(r, tr)
            if mine <= 0:
                continue
            theirs = self.their_dps(tr, r)
            adv = (mine / their_hp) / (theirs / my_hp + 1e-3)
            v = math.log(adv + 1e-6) - abs(r - dnow) * 0.0015  # prefer staying near the current range
            if v > bv:
                bv, best = v, r
        if tr.hp < 320 and self.hpf > 0.5 and "lightning" in self.kinds:
            best = min(best, 35.0)
        return best

    def cover_spot(self, only=None, pseudo=None):
        """Nearest free spot hidden from the threats (their eye -> our body, edges included),
        searched outward to ~95 m, away from the threats first. `pseudo` adds a fake threat at an
        (x, y) point (e.g. along a damage bearing from someone we can't see)."""
        t = self.t
        if self.retreat_spot is not None and t - self.retreat_spot_t < 0.8 and only is None and pseudo is None:
            return self.retreat_spot
        if only is not None:
            key = tuple(tr.id for tr in only)
            c = getattr(self, "_hide_cache", None)
            if c is not None and c[0] == key and t - c[1] < 0.6:
                return c[2]
        if pseudo is not None:
            c = getattr(self, "_pseudo_cache", None)
            if c is not None and t - c[1] < 0.8 and d2(c[0][0], c[0][1], pseudo[0], pseudo[1]) < 40:
                return c[2]
        x, y, z = self.pos
        t_start = time.perf_counter()
        ray_cap = self.A.rays + int(self.P.get("cover_ray_budget", 150))
        guard_s = float(self.P.get("cover_guard_s", 0.015))
        if only is not None:
            eyes = [(tr.pos[0], tr.pos[1], tr.pos[2] + 8.0 * gn.body_scale(tr.cubes, self.size_per_cube)) for tr in only]
        else:
            eyes = [(tr.pos[0], tr.pos[1], tr.pos[2] + 8.0 * gn.body_scale(tr.cubes, self.size_per_cube))
                    for tr in self.W.mechs.values()
                    if t - tr.last_seen < 6.0 and d2(x, y, tr.pos[0], tr.pos[1]) < 230]
        if pseudo is not None:
            eyes.append((pseudo[0], pseudo[1], self.A.terrain(pseudo[0], pseudo[1]) + 8.0))
        if not eyes:
            return None
        A = self.A
        N = self.N
        sx = sum(e[0] for e in eyes) / len(eyes)
        sy = sum(e[1] for e in eyes) / len(eyes)
        away = bearing(sx, sy, x, y)
        cands = []
        for r in (8.0, 14.0, 22.0, 32.0, 45.0, 60.0, 78.0, 95.0):
            for k in range(16):
                off = (k - 7.5) * (math.pi / 8.0)
                a = away + off
                cands.append((r * 0.6 + abs(off) * 9.0, r, a))
        cands.sort()
        best = None
        fallback = None
        h, rad = 9.0 * self.scale, 2.5 * self.scale
        for prior, r, a in cands:
            if self.A.rays > ray_cap or time.perf_counter() - t_start > guard_s:
                break  # a fixed amount of work (deterministic); the clock is only a safety net
            px, py = x + r * math.cos(a), y + r * math.sin(a)
            if not N.cspace_free(px, py):
                continue
            if not self.in_safe(px, py, 0) and (self.outside or self.zone_slack < 20):
                continue
            pz = A.terrain(px, py)
            seen = False
            for ex, ey, ez in eyes:  # cheap test first: centre ray
                if A.los(ex, ey, ez, px, py, pz + 0.5 * h):
                    seen = True
                    break
            if seen:
                continue
            for ex, ey, ez in eyes:
                if self.exposed_point(ex, ey, ez, px, py, pz, h, rad) is not None:
                    seen = True
                    break
            if seen:
                continue
            if N.segment_free(x, y, px, py):
                best = (px, py)
                break
            if fallback is None:
                fallback = (px, py)
        if best is None:
            best = fallback
        if only is None and pseudo is None:
            self.retreat_spot = best
            self.retreat_spot_t = t
        elif only is not None:
            self._hide_cache = (tuple(tr.id for tr in only), t, best)
        else:
            self._pseudo_cache = (pseudo, t, best)
        return best

    # ================================================================== drops and loot
    def drop_goal(self):
        P = self.P
        if not P.drop_go:
            return None
        x, y = self.pos[0], self.pos[1]
        best = None
        for dr in self.obs.get("drops") or []:
            dx, dy = dr["pos"][0], dr["pos"][1]
            d = d2(x, y, dx, dy)
            if d > P.drop_max_dist:
                continue
            eta = d / max(1.0, self.walk)
            if dr.get("lands_in", 0) > eta + 6:
                continue
            if not self.in_safe(dx, dy, 0) and self.zone_slack < 20:
                continue
            if self.goal_bad(dx, dy, 8.0):
                continue
            # contested: another mech near the ring
            contested = False
            for dd, tr in self.enemies:
                if d2(tr.pos[0], tr.pos[1], dx, dy) < 45:
                    contested = True
            if dr.get("holder") not in (None, self.slot):
                contested = True
            if contested and self.hpf < 0.9:
                continue
            if self.hpf < P.drop_hp_frac:
                continue
            if best is None or d < best[0]:
                best = (d, dr)
        if best is None:
            return None
        d, dr = best
        rad = dr.get("radius", 8.0)
        gx, gy = dr["pos"][0], dr["pos"][1]
        if d < rad * 0.6:
            return Intent("drop", goal=(gx, gy), note=f"cap{dr.get('progress', 0):.1f}")
        return Intent("drop", goal=(gx, gy), boost=d > 40 and self.me.get("energy", 0) > 40, note="drop")

    def weapon_value(self, kind):
        v = self.P.weapon_value.get(kind, 0.0)
        gun_laser = (self.P.get("gun_laser_always") or (self.P.get("gun_laser_unless_ffa") and not self.W.is_ffa())
                     or (getattr(self, "squad", False) and self.P.get("squad_gun_laser")))
        if kind == "lightning" and gun_laser:
            # gun + laser at range, as both leaders of the practice board do: lightning ranks below the gun
            return self.P.get("squad_lightning_value", 4.0)
        if kind == "lightning" and self.zn[1] <= self.P.late_radius:
            v += self.P.late_lightning_bonus
        return v

    def loadout_gain(self, kind):
        """(gain, drop_slot) for taking a weapon of `kind`."""
        kinds = self.kinds
        if kind in kinds:
            return 0.0, None
        if None in kinds:
            return self.weapon_value(kind), None
        vals = [self.weapon_value(k) for k in kinds]
        worst = 0 if vals[0] <= vals[1] else 1
        w = self.weap[worst]
        if w and w.get("kind") == "laser" and (w.get("charge") or 0) > 0:
            return 0.0, None
        return self.weapon_value(kind) - vals[worst], worst

    def near_cube(self, radius):
        """Nearest remembered power cube within radius (horizontal) that we can walk to inside the circle."""
        if self.me.get("cubes", 0) >= 21:
            return None
        x, y, z = self.pos
        best, bd = None, radius
        for it in self.W.cubes.values():
            d = d2(x, y, it.pos[0], it.pos[1])
            if d > bd or abs(it.pos[2] - z) > 5:
                continue
            if not self.N.cspace_free(it.pos[0], it.pos[1]) and not self.N.is_free(it.pos[0], it.pos[1]):
                continue
            if not self.in_safe(it.pos[0], it.pos[1], 0):
                continue
            best, bd = it, d
        return best

    def close_weapon(self, radius):
        """A remembered weapon pickup within radius that clearly improves our loadout."""
        x, y, z = self.pos
        best = None
        for it in self.W.pickups.values():
            if self.blacklist.get(it.id, -1) > self.t:
                continue
            if abs(it.pos[2] - z) > 4:
                continue
            d = d2(x, y, it.pos[0], it.pos[1])
            if d > radius:
                continue
            gain, slot = self.loadout_gain(it.kind)
            if gain >= max(5.0, self.P.swap_margin) and (best is None or d < best[0]):
                best = (d, it)
        return best[1] if best else None

    def loot_goal_pick(self):
        """Best loot by value minus walking cost, within what the zone lets us spend; else farm
        crates/drones from range; else explore unvisited ground (early game)."""
        P = self.P
        W = self.W
        x, y, z = self.pos
        t = self.t
        hx, hy = self.hold
        base = d2(x, y, hx, hy)
        slack = min(self.zone_slack, 120.0)
        budget_m = max(0.0, slack - 6.0) * self.walk * 0.5  # spend at most half the slack walking
        cost_m = 0.25 if self.zn[1] > 150 else 0.45
        best = None  # (score, intent)

        def detour(px, py):
            return d2(x, y, px, py) + d2(px, py, hx, hy) - base

        def reachable(px, py, pz):
            return abs(pz - z) <= 5 or self.N.is_free(px, py)

        for it in W.pickups.values():
            gain, slot = self.loadout_gain(it.kind)
            if gain < P.swap_margin and not (slot is None and gain > 0):
                continue
            if self.blacklist.get(it.id, -1) > t or not reachable(*it.pos) or self.goal_bad(it.pos[0], it.pos[1]):
                continue
            if not self.N.is_free(it.pos[0], it.pos[1]) and not self.N.cspace_free(it.pos[0], it.pos[1]):
                continue  # on a roof or inside geometry
            dt_ = detour(it.pos[0], it.pos[1])
            if dt_ > budget_m + 15:
                continue
            sc = 12.0 * gain - cost_m * dt_
            if sc > 0 and (best is None or sc > best[0]):
                best = (sc, Intent("loot", goal=(it.pos[0], it.pos[1]), pickup=it, note=f"{it.kind}"))
        cubes = self.me.get("cubes", 0)
        if cubes < 21:
            val = 60.0 if cubes < 10 else 12.0
            for it in W.cubes.values():
                if not reachable(*it.pos) or not self.N.cspace_free(it.pos[0], it.pos[1]) and not self.N.is_free(it.pos[0], it.pos[1]):
                    continue
                if self.goal_bad(it.pos[0], it.pos[1]):
                    continue
                dt_ = detour(it.pos[0], it.pos[1])
                if dt_ > budget_m + 15:
                    continue
                sc = val - cost_m * dt_
                if sc > 0 and (best is None or sc > best[0]):
                    best = (sc, Intent("loot", goal=(it.pos[0], it.pos[1]), note="cube"))
        if best is not None:
            it = best[1]
            it.shoot = self.farm_target(walking=True)
            return it
        ft = self.farm_target(walking=False)
        if ft is not None:
            kind = "npc" if getattr(ft, "kind", "") == "npc" else "crate"
            goal = None
            if kind == "npc":
                d = d2(x, y, ft.pos[0], ft.pos[1])
                if d > 95:
                    goal = (ft.pos[0], ft.pos[1])
            return Intent("farm", goal=goal, shoot=ft, target=ft if kind == "npc" else None,
                          dist_pref=75.0 if kind == "npc" else None, strafe=kind == "npc", note=kind)
        ex = self.explore_goal(budget_m)
        if ex is not None:
            return Intent("explore", goal=ex, note="explore")
        return None

    def explore_goal(self, budget_m):
        """Nearest unvisited 40 m cell inside the safe area (early game only)."""
        if budget_m < 80 or self.me.get("cubes", 0) >= 10 and "laser" in self.kinds:
            return None
        x, y = self.pos[0], self.pos[1]
        vis = self.visited
        cs = 40.0
        ci, cj = int(math.floor(x / cs)), int(math.floor(y / cs))
        for di in (-1, 0, 1):
            for dj in (-1, 0, 1):
                vis.add((ci + di, cj + dj))
        cur = self.explore_target
        if cur is not None and (int(math.floor(cur[0] / cs)), int(math.floor(cur[1] / cs))) not in vis and self.t - self.explore_t < 25 \
                and not self.goal_bad(cur[0], cur[1], 20.0):
            return cur
        cn, rn = self.zn
        c, r = self.zcur
        best, bd = None, 1e18
        for di in range(-6, 7):
            for dj in range(-6, 7):
                k = (ci + di, cj + dj)
                if k in vis:
                    continue
                px, py = (k[0] + 0.5) * cs, (k[1] + 0.5) * cs
                d = math.hypot(px - x, py - y)
                if d > min(budget_m * 0.5, 260):
                    continue
                if d2(px, py, c[0], c[1]) > r - 25:
                    continue
                if self.zone_slack < 60 and d2(px, py, cn[0], cn[1]) > rn:
                    continue
                if self.goal_bad(px, py, 20.0):
                    continue
                n = self.N.nearest_free(px, py, 6)
                if n is None:
                    vis.add(k)
                    continue
                if d < bd:
                    bd, best = d, self.N.pos(n)
        self.explore_target = best
        self.explore_t = self.t
        return best

    def farm_target(self, walking):
        """A crate or drone worth shooting now (only when no enemy mech is in view)."""
        P = self.P
        if self.enemies:
            near = [d for d, tr in self.enemies if d < 200]
            if near:
                return None
        x, y, z = self.pos
        best, bd = None, 1e9
        if self.hpf < self.sq("farm_regen_hp", 0.85) and self.t - self.W.last_damage_t < 20:
            return None  # let regen work: dealing damage restarts its delay
        if self.me.get("cubes", 0) < 14:
            for it in self.W.crates.values():
                d = d2(x, y, it.pos[0], it.pos[1])
                if d > P.crate_shoot_range or d < 4:
                    continue
                if self.t - it.last_seen > 0.3:
                    continue
                if not self.in_safe(it.pos[0], it.pos[1], -25):
                    continue
                if not self.A.los(x, y, z + self.muzzle_h, it.pos[0], it.pos[1], it.pos[2] + 1.2):
                    continue
                if d < bd:
                    best, bd = it, d
        if P.npc_hunt and self.hpf > self.sq("npc_min_hp_frac", 0.8) and self.me.get("cubes", 0) < 12:
            for tr in self.W.npcs.values():
                if self.t - tr.last_seen > 0.25:
                    continue
                d = d2(x, y, tr.pos[0], tr.pos[1])
                if d > self.sq("npc_hunt_range", 140.0):
                    continue
                if not self.in_safe(tr.pos[0], tr.pos[1], -25):
                    continue
                if not self.los_to(tr):
                    continue
                if d * 0.8 < bd:
                    best, bd = tr, d * 0.8
        return best

    # ================================================================== pilot
    # ================================================================== progress watchdog (B12)
    def goal_bad(self, px, py, r=6.0):
        """A goal next to one that stalled recently (see watchdog)."""
        t = self.t
        for bx, by, until in self.bad_goals:
            if until > t and abs(bx - px) < r and abs(by - py) < r:
                return True
        return False

    def watchdog(self, intent: Intent):
        """Unreachable goals held the bot still for minutes (S11 seed 9000: a laser on a roof 27 m up, then a
        partial A* path out of a disconnected pocket on a roof, outside the circle). The 2D grid can't see
        roofs or jumps, and a partial path ends in move 0, which the stuck handler never sees. So watch
        progress: when the distance to the goal hasn't shrunk by 1.5 m for wd_stall_s, skip that loot, cube,
        explore or drop goal for wd_ban_s; for a goal we can't drop (zone, hold, retreat, heal) walk straight
        at it with jump and jets (then +-0.9, +-1.8 rad on later tries) and replan."""
        g = intent.goal
        if g is None or intent.mode in ("fight", "evade", "farm", "dodge", "alert"):
            self.wd_key = None
            return
        t = self.t
        P = self.P
        d = d2(self.pos[0], self.pos[1], g[0], g[1])
        key = (intent.mode, int(g[0] // 8), int(g[1] // 8))
        if key != self.wd_key:
            self.wd_key, self.wd_best, self.wd_t, self.wd_escapes = key, d, t, 0
            return
        if d < self.wd_best - 1.5 or t < self.escape_until:
            self.wd_best = min(self.wd_best, d)
            self.wd_t = t
            return
        if d <= (0.0 if intent.mode in ("loot", "explore") else 5.0):
            self.wd_t = t  # there: capturing, holding or healing is progress (loot ends by pickup)
            return
        if t - self.wd_t < P.get("wd_stall_s", 4.0):
            return
        self.bad_goals = [b for b in self.bad_goals if b[2] > t]
        if intent.mode in ("loot", "explore", "drop"):
            b = (int(g[0] // 8), int(g[1] // 8))
            n = self.bad_count[b] = self.bad_count.get(b, 0) + 1
            ban = P.get("wd_ban_s", 60.0) * (2 ** min(n - 1, 4))  # exponential backoff: 60, 120, 240 s ...
            self.bad_goals.append((g[0], g[1], t + ban))
            if intent.pickup is not None:
                self.blacklist[intent.pickup.id] = t + ban
            if intent.mode == "explore":
                self.explore_target = None
            self.wd_key = None
            return
        k = self.wd_escapes
        ang = math.atan2(g[1] - self.pos[1], g[0] - self.pos[0]) + (0.0, 0.9, -0.9, 1.8, -1.8)[k % 5]
        self.escape_dir = (math.cos(ang), math.sin(ang))
        self.escape_until = t + P.get("wd_escape_s", 1.5)
        self.wd_escapes = k + 1
        self.wd_t = t
        self.path = []
        self.search = None
        if intent.mode in ("retreat", "heal"):
            self.retreat_spot = None

    def plan_to(self, goal):
        """Keep self.path pointing at goal. Long searches run a few ms per tick (resumable A*)."""
        x, y = self.pos[0], self.pos[1]
        gx, gy = goal
        t = self.t
        N = self.N
        if self.ticks % 2 == 0 or not self.path or self.path_goal is None or d2(gx, gy, self.path_goal[0], self.path_goal[1]) > 3.0:
            if N.segment_free(x, y, gx, gy):
                self.path = [(gx, gy)]
                self.path_goal = (gx, gy)
                self.path_t = t
                self.search = None
                return
        stale = (self.path_goal is None or d2(gx, gy, self.path_goal[0], self.path_goal[1]) > 8.0
                 or t - self.path_t > 5.0 or not self.path)
        if self.search is not None and d2(gx, gy, self.search_goal[0], self.search_goal[1]) > 20.0:
            self.search = None
        if stale and self.search is None:
            self.search = N.astar_iter(x, y, gx, gy, chunk=250)
            self.search_goal = (gx, gy)
        if self.search is not None:
            # A fixed number of 250-node chunks per tick, fewer when this tick already cast many rays
            # (about 30 rays cost one chunk). Counting work, not time, keeps runs reproducible on any CPU
            # and machine load; the clock is only a safety net.
            P = self.P
            n = int(P.get("astar_chunks_path", 5) if self.path else P.get("astar_chunks_nopath", 7))
            extra = (self.A.rays - self.rays0) - int(P.get("astar_free_rays", 160))
            if extra > 0:
                n -= (extra + 29) // 30
            guard_s = float(P.get("tick_guard_s", 0.020))
            for _ in range(max(0, n)):
                if time.perf_counter() - self.tick_t0 > guard_s:
                    break
                r = next(self.search, ([(gx, gy)], False))
                if r is not None:
                    path, ok = r
                    self.search = None
                    sm = N.smooth(path, x, y)
                    self.path = sm[1:] if len(sm) > 1 else [self.search_goal]
                    self.path_goal = self.search_goal
                    self.path_t = t
                    break
        if not self.path:
            self.path = [(gx, gy)]
            self.path_goal = (gx, gy)
            self.path_t = t

    def follow(self):
        x, y = self.pos[0], self.pos[1]
        while len(self.path) > 1 and d2(x, y, self.path[0][0], self.path[0][1]) < 2.5:
            self.path.pop(0)
        # skip ahead when the next-next waypoint is directly reachable
        if len(self.path) > 1 and self.ticks % 2 == 0 and self.N.segment_free(x, y, self.path[1][0], self.path[1][1]):
            self.path.pop(0)
        if not self.path:
            return 0.0, 0.0, 0.0
        wx, wy = self.path[0]
        dd = d2(x, y, wx, wy)
        ux, uy = unit(wx - x, wy - y)
        return ux, uy, dd

    def pilot(self, intent: Intent):
        P = self.P
        t = self.t
        x, y, z = self.pos
        me = self.me
        mvx = mvy = 0.0
        boost = bool(intent.boost)
        jump = False
        if intent.goal is not None:
            self.plan_to(intent.goal)
            gx, gy, dd = self.follow()
            final = len(self.path) <= 1
            if final and dd < 1.5:
                gx = gy = 0.0
            elif final and dd < 6:
                s = dd / 6.0
                gx, gy = gx * s, gy * s
            mvx, mvy = gx, gy
        # under fire while walking somewhere: zig-zag across the attacker's line of fire
        tr = intent.target
        if intent.evasive and not intent.strafe and (mvx or mvy) and tr is not None:
            if t >= self.strafe_until:
                if self.rng.random() < 0.75:
                    self.strafe_dir = -self.strafe_dir
                self.strafe_until = t + self.rng.uniform(P.strafe_min_s, P.strafe_max_s)
            b = bearing(x, y, tr.pos[0], tr.pos[1])
            px, py = -math.sin(b) * self.strafe_dir, math.cos(b) * self.strafe_dir
            mvx, mvy = unit(mvx + px * 0.8, mvy + py * 0.8)
        # combat movement: strafe + range keeping (blended with the goal)
        if intent.strafe and tr is not None:
            b = bearing(x, y, tr.pos[0], tr.pos[1])
            d = d2(x, y, tr.pos[0], tr.pos[1])
            if t >= self.strafe_until:
                if self.rng.random() < 0.75:
                    self.strafe_dir = -self.strafe_dir
                self.strafe_until = t + self.rng.uniform(P.strafe_min_s, P.strafe_max_s)
            px, py = -math.sin(b) * self.strafe_dir, math.cos(b) * self.strafe_dir
            rad = 0.0
            if intent.dist_pref is not None:
                rad = clamp((d - intent.dist_pref) / 25.0, -1.0, 1.0)
            rx, ry = math.cos(b) * rad, math.sin(b) * rad
            if intent.goal is not None:
                wg = 0.9
                cx, cy = mvx * wg + px * 0.6 + rx * 0.3, mvy * wg + py * 0.6 + ry * 0.3
            else:
                cx, cy = px * 0.75 + rx * 0.9, py * 0.75 + ry * 0.9
            mvx, mvy = unit(cx, cy)
            # dodge inbound bullets: flip early
            if self.bullet_inbound():
                self.strafe_dir = -self.strafe_dir
                self.strafe_until = t + self.rng.uniform(P.strafe_min_s, P.strafe_max_s)
        # mortar shells: step out of the splash
        dz = self.mortar_dodge()
        if dz is not None:
            mvx, mvy = dz
            boost = me.get("energy", 0) > 10
        # zone: never walk out (except on the way to the hold point: the planned path may clip the edge,
        # and pushing back against it deadlocked the bot at the edge until the circle passed it, B12)
        wd = self.P.get("wd_on", True)
        if not self.outside and (mvx or mvy) and not (wd and (intent.mode == "zone" or t < self.escape_until)):
            c, r = self.zcur
            nxp, nyp = x + mvx * 6, y + mvy * 6
            if d2(nxp, nyp, c[0], c[1]) > r - 1.5 and d2(x, y, c[0], c[1]) > r - 10:
                ix, iy = unit(c[0] - x, c[1] - y)
                mvx, mvy = unit(mvx + ix * 1.2, mvy + iy * 1.2)
        # walls: steer to a free direction
        if mvx or mvy:
            mvx, mvy = self.steer(mvx, mvy)
        # stuck handling
        spd = math.hypot(me["vel"][0], me["vel"][1])
        commanded = math.hypot(mvx, mvy) > 0.5
        if commanded and spd < 1.5 and me.get("grounded", True):
            if self.stuck_since is None:
                self.stuck_since = t
            elif t - self.stuck_since > 0.6:
                self.unstick_until = t + 0.9
                ang = math.atan2(mvy, mvx) + self.rng.choice((-1, 1)) * self.rng.uniform(0.6, 1.6)
                self.unstick_dir = (math.cos(ang), math.sin(ang))
                self.stuck_since = None
                self.path = []  # force replan
                self.search = None
        else:
            self.stuck_since = None
        if t < self.unstick_until:
            jump = me.get("grounded", False)
            boost = me.get("energy", 0) > 15
            ux, uy = self.unstick_dir
            mvx, mvy = unit(mvx * 0.4 + ux, mvy * 0.4 + uy)
        if wd and t < self.escape_until:  # watchdog escape: straight at the stalled goal, off roofs and ledges
            jump = me.get("grounded", False)
            boost = me.get("energy", 0) > 15
            mvx, mvy = self.escape_dir
        # energy discipline: keep a reserve unless outside the zone
        if boost and me.get("energy", 0) < 22 and not self.outside:
            boost = False
        # silent walking when hiding with no one around
        if intent.mode == "hold" and not self.enemies and (mvx or mvy):
            pass
        self.last_move = (mvx, mvy)
        return (mvx, mvy), boost, jump

    def steer(self, mx, my):
        x, y = self.pos[0], self.pos[1]
        N = self.N
        if N.cspace_free(x + mx * 3.0, y + my * 3.0) and N.cspace_free(x + mx * 1.5, y + my * 1.5):
            return mx, my
        base = math.atan2(my, mx)
        for k in (1, -1, 2, -2, 3, -3, 4, -4, 5, -5):
            a = base + k * 0.45
            cx, cy = math.cos(a), math.sin(a)
            if N.cspace_free(x + cx * 3.0, y + cy * 3.0) and N.cspace_free(x + cx * 1.5, y + cy * 1.5):
                return cx, cy
        return mx, my

    def bullet_inbound(self):
        x, y, z = self.pos
        cz = z + 4.5 * self.scale
        for p in self.obs.get("projectiles") or []:
            if p.get("kind") not in ("gun", "npc"):
                continue
            tt, dd = gn.closest_approach(p["pos"], p["vel"], x, y, cz, 0.6)
            if tt > 0.04 and dd < 2.5 * self.scale + 0.8:
                return True
        return False

    def mortar_dodge(self):
        x, y, z = self.pos
        g = self.wc.get("mortar", {}).get("gravity", 22.0)
        rad = self.wc.get("mortar", {}).get("splash_radius", 7.0)
        for p in self.obs.get("projectiles") or []:
            if p.get("kind") != "mortar":
                continue
            ix, iy, iz, it = gn.shell_impact(p["pos"], p["vel"], g, self.A)
            px = x + self.me["vel"][0] * it
            py = y + self.me["vel"][1] * it
            if d2(px, py, ix, iy) < rad + 3.0 * self.scale + 1.0 and it < 5.0:
                ax, ay = unit(x - ix, y - iy)
                if ax == 0 and ay == 0:
                    ax, ay = 1.0, 0.0
                return ax, ay
        return None

    # ================================================================== gunnery
    def gunnery(self, intent: Intent):
        t = self.t
        me = self.me
        x, y, z = self.pos
        vx, vy = me["vel"][0], me["vel"][1]
        fire = [False, False]
        reload = False
        shooter = (x + vx * 0.05, y + vy * 0.05, z + self.muzzle_h)
        tgt = intent.shoot
        aim = None
        laser_slot = next((i for i, w in enumerate(self.weap) if w and w["kind"] == "laser"), None)
        gun_slot = next((i for i, w in enumerate(self.weap) if w and w["kind"] == "gun"), None)
        lgt_slot = next((i for i, w in enumerate(self.weap) if w and w["kind"] == "lightning"), None)
        mor_slot = next((i for i, w in enumerate(self.weap) if w and w["kind"] == "mortar"), None)
        cur_yaw, cur_pitch = me["aim"][0], me["aim"][1]
        if tgt is not None:
            is_mech = getattr(tgt, "kind", "") == "mech"
            is_npc = getattr(tgt, "kind", "") == "npc"
            tpos = tgt.pos
            tvel = getattr(tgt, "vel", None) or [0.0, 0.0, 0.0]
            if is_mech:
                sc = gn.body_scale(tgt.cubes, self.size_per_cube)
                h_body, r_body = 9.0 * sc, 2.5 * sc
            elif is_npc:
                h_body, r_body = 3.5, 1.8
            else:
                h_body, r_body = 2.4, 1.4
            d = d2(x, y, tpos[0], tpos[1])
            ep = self.exposed_point(shooter[0], shooter[1], shooter[2], tpos[0], tpos[1], tpos[2], h_body, r_body)
            los = ep is not None
            aim_h = 0.5 * h_body
            if ep is not None:
                aim_h = ep[2]
                if ep[0] or ep[1]:
                    # only an edge shows: aim at that side of the body
                    tpos = [tpos[0] + ep[0] * 0.8, tpos[1] + ep[1] * 0.8, tpos[2]]
                    r_body *= 0.5
            # --- solutions
            gsol = None
            if gun_slot is not None:
                gw = self.weap[gun_slot]
                spd = gw["stats"].get("speed", 252.0)
                lat = 0.05 + min(0.05, max(0.0, gw.get("cooldown", 0.0)))
                px, py, pz, tf = gn.lead(shooter, tpos, tvel, spd, lat, 3.0 * self.scale, aim_h, self.A)
                gsol = gn.aim_to(shooter, px, py, pz)
            lsol = None
            if laser_slot is not None:
                px, py, pz = gn.predict(tpos, tvel, 0.075, self.A)
                lsol = gn.aim_to(shooter, px, py, pz + aim_h)
            # --- laser state machine
            lw = self.weap[laser_slot] if laser_slot is not None else None
            laser_aiming = False
            if lw is not None:
                charge = lw.get("charge") or 0.0
                full = lw["stats"].get("charge", 0.75)
                rng = lw["stats"].get("range", 280.0)
                hittable = los and d <= rng
                if charge > 0:
                    if self.laser_hold_start is None:
                        self.laser_hold_start = t - charge
                    held = t - self.laser_hold_start
                    if charge >= full - 0.051 and hittable:
                        laser_aiming = True
                        err_y = abs(adiff(cur_yaw, lsol[0]))
                        err_p = abs(cur_pitch - lsol[1])
                        tol = gn.angular_radius(max(d, 1.0), r_body) * self.P.laser_aim_tol
                        tolp = gn.angular_radius(max(d, 1.0), 0.45 * h_body)
                        if err_y <= tol and err_p <= tolp:
                            fire[laser_slot] = False  # release
                            self.laser_hold_start = None
                        else:
                            fire[laser_slot] = True
                    elif held > full + 1.6:
                        fire[laser_slot] = False  # about to auto-fire into nothing: let go now
                        self.laser_hold_start = None
                    else:
                        fire[laser_slot] = True
                        if charge >= full - 0.12 and hittable:
                            laser_aiming = True
                else:
                    self.laser_hold_start = None
                    if lw.get("cooldown", 0) <= 0.1 and (hittable or (d < 120 and is_mech)) and (is_mech or is_npc or d < 200):
                        if not (intent.mode == "retreat" and not is_mech):
                            fire[laser_slot] = True
            # --- aim choice
            if laser_aiming and lsol is not None:
                aim = lsol
            elif gsol is not None:
                aim = gsol
            elif lsol is not None:
                aim = lsol
            else:
                aim = gn.aim_to(shooter, tpos[0], tpos[1], tpos[2] + aim_h)
            # --- gun trigger
            if gun_slot is not None and gsol is not None and los:
                gw = self.weap[gun_slot]
                if d <= gw["stats"].get("range", 230.0) * 0.98 and (gw.get("reload", 0) or 0) <= 0:
                    err_y = abs(adiff(cur_yaw, gsol[0]))
                    err_p = abs(cur_pitch - gsol[1])
                    tol = gn.angular_radius(max(d, 1.0), r_body) * self.P.gun_aim_tol + 0.004
                    tolp = gn.angular_radius(max(d, 1.0), 0.45 * h_body) + 0.004
                    if err_y <= tol + 0.02 and err_p <= tolp + 0.02 and not laser_aiming:
                        fire[gun_slot] = True
                    elif d < 25:
                        fire[gun_slot] = err_y < 0.3
            # --- lightning trigger
            if lgt_slot is not None and los:
                lw2 = self.weap[lgt_slot]
                st = lw2["stats"]
                cone = math.radians(st.get("cone_deg", 30.0)) * 0.5
                if d <= st.get("range", 45.0) * 0.97 and abs(adiff(cur_yaw, bearing(x, y, tpos[0], tpos[1]))) < cone * 0.9:
                    reserve = self.P.lightning_energy_reserve
                    if me.get("energy", 0) > reserve or (is_mech and tgt.hp < 200):
                        if is_mech or is_npc or d < 30:
                            fire[lgt_slot] = True
            # --- mortar trigger
            if mor_slot is not None:
                mw = self.weap[mor_slot]
                if mw.get("cooldown", 0) <= 0.05 and d >= self.P.mortar_min_range:
                    slow = math.hypot(tvel[0], tvel[1]) < self.P.mortar_max_target_speed or not is_mech
                    if (slow or not los) and (aim is None or not fire[gun_slot if gun_slot is not None else 0]):
                        st = mw["stats"]
                        tube = (x, y, z + (self.mc.get("height", 9.0) + 0.5) * self.scale)
                        ms = None
                        for high in (False, True):
                            px, py, pz = gn.predict(tpos, tvel, 1.5, self.A, damp=0.6)
                            sol = gn.mortar_solution(tube, (px, py, pz + 0.5), st.get("speed", 72.0), st.get("gravity", 22.0),
                                                     3.0 * self.scale, high, self.mc.get("min_pitch", -0.7), self.mc.get("max_pitch", 1.3))
                            if sol is None:
                                continue
                            yaw_m, pit_m, tf = sol
                            px, py, pz = gn.predict(tpos, tvel, tf, self.A, damp=0.6)
                            sol = gn.mortar_solution(tube, (px, py, pz + 0.5), st.get("speed", 72.0), st.get("gravity", 22.0),
                                                     3.0 * self.scale, high, self.mc.get("min_pitch", -0.7), self.mc.get("max_pitch", 1.3))
                            if sol is not None and (high or los or True):
                                ms = sol
                                break
                        if ms is not None and not laser_aiming and not any(fire):
                            aim = (ms[0], ms[1])
                            if abs(adiff(cur_yaw, ms[0])) < 0.03 and abs(cur_pitch - ms[1]) < 0.03:
                                fire[mor_slot] = True
        else:
            # no target: release a dangling laser charge, scan
            if laser_slot is not None:
                lw = self.weap[laser_slot]
                if (lw.get("charge") or 0) > 0:
                    if self.laser_hold_start is None:
                        self.laser_hold_start = t - (lw.get("charge") or 0)
                    if t - self.laser_hold_start < lw["stats"].get("charge", 0.75) + 1.5 and intent.target is not None:
                        fire[laser_slot] = True
                    else:
                        self.laser_hold_start = None
            aim = self.scan_aim(intent)
            if gun_slot is not None:
                gw = self.weap[gun_slot]
                mag = gw["stats"].get("mag", 12)
                if (gw.get("ammo", mag) or 0) < mag * self.sq("reload_below_frac", 0.6) and (gw.get("reload", 0) or 0) <= 0 and not self.enemies:
                    reload = True
        if aim is None:
            aim = (cur_yaw, 0.0)
        pitch = clamp(aim[1], self.mc.get("min_pitch", -0.7), self.mc.get("max_pitch", 1.3))
        if any(fire):
            self.last_fire_t = t
        return (wrap(aim[0]), pitch), fire, reload

    def scan_aim(self, intent: Intent):
        """Where to look when not shooting: threats first, then the zone centre, sweeping."""
        x, y = self.pos[0], self.pos[1]
        t = self.t
        if intent.target is not None:
            tr = intent.target
            return bearing(x, y, tr.pos[0], tr.pos[1]), 0.0
        if intent.face is not None:
            return intent.face + 0.35 * math.sin(2 * math.pi * t / 1.6), 0.0
        focus = self.W.threat_bearing(4.0)
        amp = 0.9
        if focus is None:
            # last known enemies
            best = None
            for tr in self.W.mechs.values():
                age = t - tr.last_seen
                if age < 12:
                    d = d2(x, y, tr.pos[0], tr.pos[1])
                    if best is None or d < best[0]:
                        best = (d, tr)
            if best is not None:
                focus = bearing(x, y, best[1].pos[0], best[1].pos[1])
                amp = 0.6
        if focus is None:
            cn, rn = self.zn
            mv = self.last_move
            if math.hypot(mv[0], mv[1]) > 0.3:
                mvb = math.atan2(mv[1], mv[0])
            else:
                mvb = None
            dc = d2(x, y, cn[0], cn[1])
            if dc > 30:
                cb = bearing(x, y, cn[0], cn[1])
                focus = cb if mvb is None else math.atan2(math.sin(cb) + math.sin(mvb), math.cos(cb) + math.cos(mvb))
            elif mvb is not None:
                focus = mvb
            else:
                focus = self.me["aim"][0]
            amp = 1.25 if intent.mode not in ("explore", "loot") else math.pi
        per = self.P.scan_period_s
        return wrap(focus + amp * math.sin(2 * math.pi * t / per + self.slot)), 0.0

    # ================================================================== upkeep
    def loot_actions(self, intent: Intent, action: dict):
        x, y, z = self.pos
        best = None
        for p in self.obs.get("pickups") or []:
            if d2(x, y, p["pos"][0], p["pos"][1]) > self.loot_reach - 0.3 or abs(p["pos"][2] - z) > 3.8:
                continue
            gain, slot = self.loadout_gain(p.get("kind"))
            if gain <= 0 or (slot is not None and gain < self.P.swap_margin):
                continue
            if self.blacklist.get(p["id"], -1) > self.t:
                continue
            if best is None or gain > best[0]:
                best = (gain, p, slot)
        if best is not None:
            gain, p, slot = best
            action["take"] = p["id"]
            if slot is not None:
                action["drop"] = slot
            self.blacklist[p["id"]] = self.t + 1.0  # don't spam if it fails
        for e in self.obs.get("events") or []:
            if e.get("type") == "take_failed":
                self.blacklist[e.get("id")] = self.t + (20.0 if e.get("reason") in ("gone", "have") else 2.0)

    def pick_upgrade(self, offer: dict):
        ch = offer.get("choices") or []
        if not ch:
            return None
        have = self.me.get("upgrades") or []
        uv = self.P.upgrade_value
        if getattr(self, "squad", False) and self.P.get("squad_dmg_upgrades"):
            uv = dict(uv, **self.P.get("squad_upgrade_value", {}))
        best, bv = 0, -1e9
        for i, c in enumerate(ch):
            cid = c.get("id", "")
            v = uv.get(cid, 2.0)
            stacks = sum(1 for u in have if u == cid)
            v *= 0.85 ** stacks
            if cid.startswith("laser") and "laser" not in self.kinds:
                v *= 0.3
            if cid.startswith("gun") and "gun" not in self.kinds:
                v *= 0.3
            if cid.startswith("lightning") and "lightning" not in self.kinds:
                v *= 0.3
            if cid.startswith("mortar") and "mortar" not in self.kinds:
                v *= 0.3
            if v > bv:
                bv, best = v, i
        return best
