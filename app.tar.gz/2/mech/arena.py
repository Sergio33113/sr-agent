"""Static map model: terrain, solid columns, line of sight, floor height, walkability.

Shared by the bot and the local simulator. Standard library only.

Grid: 1 m cells centred on the terrain vertices, cell (i, j) <-> world (x0 + i, y0 + j).
Every solid prism is rasterised onto that grid. A cell holds:
  col[c]   top of the solid column that rises from the ground (terrain or a building
           standing on it), in centimetres. Anything below it is solid.
  over[c]  extra floating intervals (bridges, overhangs) as [(base_cm, top_cm), ...],
           only for the few cells that have them.
That split makes the common line-of-sight test one array lookup per cell.
"""
from __future__ import annotations

import array
import json
import math
import os
import sys

NONE = -32768
CM = 100.0


class Arena:
    def __init__(self, map_dir: str, mech_cfg: dict | None = None):
        mech_cfg = mech_cfg or {}
        self.step_up = float(mech_cfg.get("step_up", 1.2))
        self.mech_h = float(mech_cfg.get("height", 9.0))
        self.mech_r = float(mech_cfg.get("radius", 2.5))
        self.max_slope = math.tan(math.radians(float(mech_cfg.get("max_slope_deg", 50.0))))
        with open(os.path.join(map_dir, "v2", "world.json")) as f:
            w = json.load(f)
        t = w["terrain"]
        self.x0, self.y0 = float(t["minX"]), float(t["minY"])
        self.nx, self.ny = int(t["nx"]), int(t["ny"])
        self.scale = float(t.get("scale", 0.01))
        b = w["bounds"]
        self.bx0, self.bx1, self.by0, self.by1 = b["minX"], b["maxX"], b["minY"], b["maxY"]
        g = array.array("h")
        with open(os.path.join(map_dir, "v2", t.get("file", "terrain.i16")), "rb") as f:
            g.frombytes(f.read())
        if sys.byteorder != "little":
            g.byteswap()
        self.ground = g  # centimetres (scale 0.01)
        self.n = self.nx * self.ny
        self.col = array.array("h", g)  # starts as terrain; buildings raise it
        self.bld = bytearray(self.n)  # 1 where a prism raised the column (a building/roof cell)
        self.over: dict[int, list] = {}
        self.prisms = w["prisms"]
        self.trees = self._load_trees(w.get("trees") or {})
        self._raster()

    # ------------------------------------------------------------------ building the grid
    def _load_trees(self, tr):
        out = []
        fields = tr.get("fields") or []
        data = tr.get("data") or []
        k = len(fields)
        if not k:
            return out
        ix = {f: i for i, f in enumerate(fields)}
        for s in range(0, len(data) - k + 1, k):
            rec = data[s:s + k]
            x, y = rec[ix["x"]], rec[ix["y"]]
            cx = rec[ix["crownX"]] if "crownX" in ix and rec[ix["crownX"]] is not None else x
            cy = rec[ix["crownY"]] if "crownY" in ix and rec[ix["crownY"]] is not None else y
            out.append((x, y, rec[ix["z"]], rec[ix["height"]], rec[ix["crownR"]], rec[ix["crownBase"]], rec[ix["trunkR"]], cx, cy))
        return out

    def _raster(self):
        nx, x0, y0 = self.nx, self.x0, self.y0
        col, over, ground, bld = self.col, self.over, self.ground, self.bld
        for p in self.prisms:
            base_cm = int(round(p["base"] * CM))
            top_cm = int(round(p["top"] * CM))
            rings = [p["ring"]] + list(p.get("holes") or [])
            ys = p["ring"][1::2]
            j0 = max(0, int(math.floor(min(ys) - y0)))
            j1 = min(self.ny - 1, int(math.ceil(max(ys) - y0)))
            for j in range(j0, j1 + 1):
                py = y0 + j
                xs = []
                for r in rings:
                    m = len(r) // 2
                    for q in range(m):
                        ax, ay = r[2 * q], r[2 * q + 1]
                        q2 = (q + 1) % m
                        bx, by = r[2 * q2], r[2 * q2 + 1]
                        if (ay > py) != (by > py):
                            xs.append(ax + (py - ay) * (bx - ax) / (by - ay))
                xs.sort()
                row = j * nx
                for q in range(0, len(xs) - 1, 2):
                    i0 = max(0, int(math.ceil(xs[q] - x0)))
                    i1 = min(nx - 1, int(math.floor(xs[q + 1] - x0)))
                    for i in range(i0, i1 + 1):
                        c = row + i
                        g = ground[c]
                        if base_cm <= max(col[c], g) + 5:
                            # rests on the ground (or on the column below): raise the column
                            if top_cm > col[c]:
                                col[c] = top_cm
                                bld[c] = 1
                        else:
                            lst = over.get(c)
                            if lst is None:
                                over[c] = [(base_cm, top_cm)]
                            else:
                                lst.append((base_cm, top_cm))
        # merge floating intervals that touch the column or each other
        for c, lst in list(over.items()):
            lst.sort()
            merged = []
            for b, t in lst:
                if b <= self.col[c] + 5:
                    if t > self.col[c]:
                        self.col[c] = t
                        self.bld[c] = 1
                    continue
                if merged and b <= merged[-1][1] + 5:
                    if t > merged[-1][1]:
                        merged[-1] = (merged[-1][0], t)
                else:
                    merged.append((b, t))
            if merged:
                over[c] = merged
            else:
                del over[c]

    # ------------------------------------------------------------------ queries
    def cell(self, x: float, y: float) -> int:
        i = int(x - self.x0 + 0.5)
        j = int(y - self.y0 + 0.5)
        if i < 0:
            i = 0
        elif i >= self.nx:
            i = self.nx - 1
        if j < 0:
            j = 0
        elif j >= self.ny:
            j = self.ny - 1
        return j * self.nx + i

    def terrain(self, x: float, y: float) -> float:
        """Bilinear terrain height (m)."""
        fx = x - self.x0
        fy = y - self.y0
        i = int(fx)
        j = int(fy)
        if i < 0:
            i, fx = 0, 0.0
        if j < 0:
            j, fy = 0, 0.0
        if i >= self.nx - 1:
            i, fx = self.nx - 2, float(self.nx - 1)
        if j >= self.ny - 1:
            j, fy = self.ny - 2, float(self.ny - 1)
        tx = fx - i
        ty = fy - j
        g = self.ground
        c = j * self.nx + i
        h00, h10 = g[c], g[c + 1]
        h01, h11 = g[c + self.nx], g[c + self.nx + 1]
        return ((h00 * (1 - tx) + h10 * tx) * (1 - ty) + (h01 * (1 - tx) + h11 * tx) * ty) * self.scale

    def column_top(self, x: float, y: float) -> float:
        return self.col[self.cell(x, y)] / CM

    def floor_at(self, x: float, y: float, z: float) -> float:
        """Highest surface under (x, y) that a mech with feet at z can stand on (<= z + step_up)."""
        c = self.cell(x, y)
        reach = z + self.step_up
        f = self.terrain(x, y)
        if self.bld[c]:
            ct = self.col[c] / CM
            if f < ct <= reach:
                f = ct
        lst = self.over.get(c)
        if lst:
            for b, t in lst:
                tt = t / CM
                if f < tt <= reach:
                    f = tt
        return f

    def solid_at(self, x: float, y: float, z: float) -> bool:
        c = self.cell(x, y)
        zc = z * CM
        if zc < self.col[c]:
            return True
        lst = self.over.get(c)
        if lst:
            for b, t in lst:
                if b <= zc <= t:
                    return True
        return False

    def los(self, ax, ay, az, bx, by, bz, terrain=True) -> bool:
        """True if the segment a->b is not blocked by buildings, bridges or (optionally) terrain.
        2D DDA over 1 m cells; per cell the segment's z-range is tested against the column and
        any floating intervals."""
        x0, y0, nx = self.x0, self.y0, self.nx
        fx = ax - x0 + 0.5
        fy = ay - y0 + 0.5
        dx = bx - ax
        dy = by - ay
        dz = bz - az
        i = int(math.floor(fx))
        j = int(math.floor(fy))
        ie = int(math.floor(bx - x0 + 0.5))
        je = int(math.floor(by - y0 + 0.5))
        if dx > 0:
            sx, tdx, tmx = 1, 1.0 / dx, (i + 1 - fx) / dx
        elif dx < 0:
            sx, tdx, tmx = -1, -1.0 / dx, (fx - i) / -dx
        else:
            sx, tdx, tmx = 0, 1e30, 1e30
        if dy > 0:
            sy, tdy, tmy = 1, 1.0 / dy, (j + 1 - fy) / dy
        elif dy < 0:
            sy, tdy, tmy = -1, -1.0 / dy, (fy - j) / -dy
        else:
            sy, tdy, tmy = 0, 1e30, 1e30
        col, over, bld = self.col, self.over, self.bld
        nxm, nym = self.nx, self.ny
        t0 = 0.0
        steps = abs(ie - i) + abs(je - j) + 1
        azc = az * CM
        dzc = dz * CM
        for _ in range(steps):
            t1 = tmx if tmx < tmy else tmy
            if t1 > 1.0:
                t1 = 1.0
            if 0 <= i < nxm and 0 <= j < nym:
                c = j * nx + i
                za = azc + dzc * t0
                zb = azc + dzc * t1
                zlo = za if za < zb else zb
                top = col[c]
                if not terrain and not bld[c]:
                    top = NONE
                if zlo < top:
                    return False
                lst = over.get(c)
                if lst:
                    zhi = za if za > zb else zb
                    for b, t in lst:
                        if zlo <= t and zhi >= b:
                            return False
            else:
                return False  # outside the map: the edge is a wall
            if tmx < tmy:
                t0 = tmx
                tmx += tdx
                i += sx
            else:
                t0 = tmy
                tmy += tdy
                j += sy
        return True

    def ray_hit(self, ax, ay, az, bx, by, bz):
        """First blocking point along a->b as a fraction in [0, 1], or None if clear."""
        x0, y0, nx = self.x0, self.y0, self.nx
        fx = ax - x0 + 0.5
        fy = ay - y0 + 0.5
        dx = bx - ax
        dy = by - ay
        dz = bz - az
        i = int(math.floor(fx))
        j = int(math.floor(fy))
        ie = int(math.floor(bx - x0 + 0.5))
        je = int(math.floor(by - y0 + 0.5))
        if dx > 0:
            sx, tdx, tmx = 1, 1.0 / dx, (i + 1 - fx) / dx
        elif dx < 0:
            sx, tdx, tmx = -1, -1.0 / dx, (fx - i) / -dx
        else:
            sx, tdx, tmx = 0, 1e30, 1e30
        if dy > 0:
            sy, tdy, tmy = 1, 1.0 / dy, (j + 1 - fy) / dy
        elif dy < 0:
            sy, tdy, tmy = -1, -1.0 / dy, (fy - j) / -dy
        else:
            sy, tdy, tmy = 0, 1e30, 1e30
        col, over = self.col, self.over
        t0 = 0.0
        steps = abs(ie - i) + abs(je - j) + 1
        azc = az * CM
        dzc = dz * CM
        for _ in range(steps):
            t1 = tmx if tmx < tmy else tmy
            if t1 > 1.0:
                t1 = 1.0
            if not (0 <= i < self.nx and 0 <= j < self.ny):
                return t0
            c = j * nx + i
            za = azc + dzc * t0
            zb = azc + dzc * t1
            top = col[c]
            if za < top:
                return t0
            if zb < top:
                return t0 + (t1 - t0) * (za - top) / (za - zb)
            lst = over.get(c)
            if lst:
                zlo = za if za < zb else zb
                zhi = za if za > zb else zb
                for b, t in lst:
                    if zlo <= t and zhi >= b:
                        return t0
            if t1 >= 1.0:
                break
            if tmx < tmy:
                t0 = tmx
                tmx += tdx
                i += sx
            else:
                t0 = tmy
                tmy += tdy
                j += sy
        return None

    def inside_map(self, x: float, y: float, margin: float = 0.0) -> bool:
        return self.bx0 + margin <= x <= self.bx1 - margin and self.by0 + margin <= y <= self.by1 - margin
