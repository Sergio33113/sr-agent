"""World model: what we know beyond the current observation.

- enemy mech tracks (position, velocity, weapons, hp, who they fight, how dangerous they are)
- NPC drones, remembered weapon pickups and crates (they stay where they were)
- recent threats from damage events and sounds
- match-mode guess: squad practice (house bots never fight each other) vs free-for-all
"""
from __future__ import annotations

import math

from .geometry import adiff, bearing, d2


def _seg_dist(px, py, ax, ay, bx, by):
    """Horizontal distance from point p to segment a-b."""
    dx, dy = bx - ax, by - ay
    L = dx * dx + dy * dy
    if L < 1e-9:
        return math.hypot(px - ax, py - ay)
    u = max(0.0, min(1.0, ((px - ax) * dx + (py - ay) * dy) / L))
    return math.hypot(px - ax - u * dx, py - ay - u * dy)


class Track:
    __slots__ = ("id", "kind", "pos", "vel", "aim", "hp", "max_hp", "cubes", "weapons", "charging",
                 "last_seen", "first_seen", "listed", "dmg_to_me", "dmg_from_me", "last_hit_me",
                 "last_hit_by_me", "fighting_t", "hp_prev", "hp_drop_t", "acc", "vel_prev", "t_prev")

    def __init__(self, a: dict, t: float):
        self.id = a["id"]
        self.kind = a.get("kind", "mech")
        self.first_seen = t
        self.dmg_to_me = 0.0
        self.dmg_from_me = 0.0
        self.last_hit_me = -99.0
        self.last_hit_by_me = -99.0
        self.fighting_t = -99.0
        self.hp_prev = None
        self.hp_drop_t = -99.0
        self.acc = (0.0, 0.0)
        self.vel_prev = None
        self.t_prev = None
        self.charging = False
        self.weapons = []
        self.cubes = 0
        self.update(a, t)

    def update(self, a: dict, t: float):
        vel = a.get("vel") or [0.0, 0.0, 0.0]
        if self.vel_prev is not None and self.t_prev is not None and t - self.t_prev > 1e-3 and t - self.t_prev < 0.35:
            dt = t - self.t_prev
            ax = (vel[0] - self.vel_prev[0]) / dt
            ay = (vel[1] - self.vel_prev[1]) / dt
            k = 0.5
            self.acc = (self.acc[0] * (1 - k) + ax * k, self.acc[1] * (1 - k) + ay * k)
        else:
            self.acc = (0.0, 0.0)
        self.vel_prev = vel
        self.t_prev = t
        self.pos = a["pos"]
        self.vel = vel
        self.aim = a.get("aim") or [0.0, 0.0]
        hp = a.get("hp")
        if hp is not None:
            if self.hp_prev is not None and hp < self.hp_prev - 1:
                self.hp_drop_t = t
            self.hp_prev = hp
        self.hp = hp if hp is not None else (self.hp if hasattr(self, "hp") else 1400.0)
        self.max_hp = a.get("max_hp") or (self.max_hp if hasattr(self, "max_hp") else 1400.0)
        if "cubes" in a:
            self.cubes = a.get("cubes") or 0
        if "weapons" in a:
            self.weapons = a.get("weapons") or []
        self.charging = bool(a.get("charging", False))
        self.last_seen = t
        self.listed = True


class Item:
    __slots__ = ("id", "kind", "pos", "hp", "last_seen")

    def __init__(self, id_, kind, pos, hp, t):
        self.id, self.kind, self.pos, self.hp, self.last_seen = id_, kind, pos, hp, t


class World:
    def __init__(self, cfg: dict, my_id: int):
        self.cfg = cfg
        self.me_id = my_id
        self.t = 0.0
        self.mechs: dict[int, Track] = {}
        self.npcs: dict[int, Track] = {}
        self.pickups: dict[int, Item] = {}
        self.crates: dict[int, Item] = {}
        self.cubes: dict[int, Item] = {}
        self.threats = []  # (t, bearing, weight, kind, dist_class)
        self.my_kills = 0
        self.deaths_not_mine = 0
        self.prev_alive = None
        self.ffa_score = 0.0      # evidence that others fight each other
        self.dmg_taken_log = []   # (t, amount, by, weapon)
        self.dmg_dealt_log = []
        self.last_damage_t = -99.0
        self.last_dealt_t = -99.0
        self.rear_hits = 0
        self.self_hist = []

    # ------------------------------------------------------------------ update
    def update(self, obs: dict):
        t = obs["t"]
        self.t = t
        me = obs["self"]
        mx, my, mz = me["pos"]
        # --- events
        for e in obs.get("events") or []:
            ty = e.get("type")
            if ty == "damaged":
                amt = e.get("amount", 0.0)
                self.dmg_taken_log.append((t, amt, e.get("by"), e.get("weapon")))
                self.last_damage_t = t
                if e.get("rear"):
                    self.rear_hits += 1
                b = e.get("bearing")
                if b is not None:
                    self.threats.append((t, b, 1.0 + amt / 100.0, e.get("weapon"), None))
                by = e.get("by")
                if by is not None and by in self.mechs:
                    tr = self.mechs[by]
                    tr.dmg_to_me += amt
                    tr.last_hit_me = t
            elif ty == "hit":
                tgt = e.get("target")
                amt = e.get("amount", 0.0)
                self.dmg_dealt_log.append((t, amt, tgt, e.get("weapon")))
                self.last_dealt_t = t
                if tgt in self.mechs:
                    self.mechs[tgt].dmg_from_me += amt
                    self.mechs[tgt].last_hit_by_me = t
            elif ty == "kill":
                self.my_kills += 1
                self.mechs.pop(e.get("target"), None)
            elif ty == "took" or ty == "dropped":
                self.pickups.pop(e.get("id"), None)
                if ty == "dropped":
                    self.pickups[e["id"]] = Item(e["id"], e.get("kind"), [mx, my, mz], None, t)
            elif ty == "take_failed":
                if e.get("reason") in ("gone", "have"):
                    self.pickups.pop(e.get("id"), None)
        # --- alive count: deaths we did not cause point to a free-for-all
        alive = obs.get("alive", 16)
        if self.prev_alive is not None and alive < self.prev_alive:
            died = self.prev_alive - alive
            mine = sum(1 for e in obs.get("events") or [] if e.get("type") == "kill")
            other = max(0, died - mine)
            if other:
                self.deaths_not_mine += other
                # early deaths are usually mech-vs-mech, but in practice a house bot can also die to a drone or the
                # zone: one alone must not flip the mode (two early ones do)
                self.ffa_score += other * (0.5 if t < 120 else 0.25)
        self.prev_alive = alive
        # --- visible actors
        listed = set()
        for a in obs.get("mechs") or []:
            aid = a["id"]
            if a.get("kind") == "npc":
                tr = self.npcs.get(aid)
                if tr is None:
                    self.npcs[aid] = Track(a, t)
                else:
                    tr.update(a, t)
                continue
            if aid == self.me_id:
                continue
            listed.add(aid)
            tr = self.mechs.get(aid)
            if tr is None:
                self.mechs[aid] = tr = Track(a, t)
            else:
                tr.update(a, t)
        for aid, tr in self.mechs.items():
            if aid not in listed:
                tr.listed = False
        for aid, tr in list(self.npcs.items()):
            if t - tr.last_seen > 30:
                del self.npcs[aid]
        # forget mechs not seen for long; keep a while for threat memory
        for aid, tr in list(self.mechs.items()):
            if t - tr.last_seen > 25:
                del self.mechs[aid]
        # --- beams: who is shooting whom (evidence of fights between others)
        for b in obs.get("beams") or []:
            by = b.get("by")
            path = b.get("path") or []
            if by is None or len(path) < 2:
                continue
            ex, ey = path[-1][0], path[-1][1]
            # a beam that passes near us (aimed at us, or an arc chaining through us) is not a fight between others
            near_me = any(_seg_dist(mx, my, path[i][0], path[i][1], path[i + 1][0], path[i + 1][1]) <= 12.0
                          for i in range(len(path) - 1))
            if not near_me:
                tr = self.mechs.get(by)
                if tr is not None:
                    tr.fighting_t = t
                # the beam ends near another mech: that one is in a fight too. It counts as free-for-all evidence
                # only if that mech lost hp just now and not to us (house bots never damage each other)
                for o in self.mechs.values():
                    if o.id != by and d2(o.pos[0], o.pos[1], ex, ey) < 8:
                        o.fighting_t = t
                        if t < 150 and o.listed and o.hp_drop_t == t and t - o.last_hit_by_me > 0.25:
                            self.ffa_score += 0.25
            else:
                self.threats.append((t, bearing(mx, my, path[0][0], path[0][1]), 2.0, b.get("kind"), None))
        # hp drops of others that we didn't cause = they are fighting someone else
        for tr in self.mechs.values():
            if tr.listed and tr.hp_drop_t == t and t - tr.last_hit_by_me > 0.25:
                tr.fighting_t = t
        # --- sounds as threats
        for s in obs.get("sounds") or []:
            k = s.get("kind")
            if k in ("gun", "laser", "laser_charge", "lightning", "mortar", "explosion", "boost", "step", "jet", "reload"):
                w = {"near": 1.5, "mid": 0.8, "far": 0.3}.get(s.get("dist"), 0.3)
                self.threats.append((t - s.get("age", 0.0), s.get("bearing", 0.0), w, k, s.get("dist")))
        self.threats = [x for x in self.threats if t - x[0] < 6.0][-40:]
        # --- items (remembered while plausible)
        seen_p = set()
        for p in obs.get("pickups") or []:
            seen_p.add(p["id"])
            it = self.pickups.get(p["id"])
            if it is None:
                self.pickups[p["id"]] = Item(p["id"], p.get("kind"), p["pos"], None, t)
            else:
                it.pos, it.last_seen = p["pos"], t
        seen_c = set()
        for c in obs.get("crates") or []:
            seen_c.add(c["id"])
            it = self.crates.get(c["id"])
            if it is None:
                self.crates[c["id"]] = Item(c["id"], "crate", c["pos"], c.get("hp"), t)
            else:
                it.pos, it.hp, it.last_seen = c["pos"], c.get("hp"), t
        seen_q = set()
        for c in obs.get("cubes") or []:
            seen_q.add(c["id"])
            it = self.cubes.get(c["id"])
            if it is None:
                self.cubes[c["id"]] = Item(c["id"], "cube", c["pos"], None, t)
            else:
                it.pos, it.last_seen = c["pos"], t
        # items we should be able to see right now but don't: gone
        for store, seen, rng in ((self.pickups, seen_p, 40.0), (self.crates, seen_c, 40.0), (self.cubes, seen_q, 40.0)):
            for iid, it in list(store.items()):
                if iid in seen:
                    continue
                if d2(it.pos[0], it.pos[1], mx, my) < rng and t - it.last_seen > 0.25:
                    del store[iid]
                elif t - it.last_seen > 90:
                    del store[iid]
        self.self_hist.append((t, mx, my, mz))
        if len(self.self_hist) > 40:
            self.self_hist = self.self_hist[-40:]

    # ------------------------------------------------------------------ queries
    def visible_enemies(self):
        return [tr for tr in self.mechs.values() if tr.listed]

    def recent_damage(self, window: float) -> float:
        t = self.t
        return sum(a for (tt, a, by, w) in self.dmg_taken_log[-60:] if t - tt <= window and w != "zone")

    def threat_bearing(self, window: float = 4.0):
        """Weighted mean bearing of recent threats, or None."""
        sx = sy = 0.0
        t = self.t
        for (tt, b, w, k, dc) in self.threats:
            if t - tt <= window:
                f = w * (1.0 - (t - tt) / (window + 1e-6))
                sx += math.cos(b) * f
                sy += math.sin(b) * f
        if sx * sx + sy * sy < 0.04:
            return None
        return math.atan2(sy, sx)

    def is_ffa(self) -> bool:
        return self.ffa_score >= 1.0
