"""Small vector and angle helpers (yaw from +x counter-clockwise, radians)."""
from __future__ import annotations

import math

TAU = 2.0 * math.pi
PI = math.pi


def wrap(a: float) -> float:
    """Angle to [-pi, pi)."""
    return (a + PI) % TAU - PI


def adiff(a: float, b: float) -> float:
    """Signed smallest difference a - b."""
    return (a - b + PI) % TAU - PI


def bearing(ax: float, ay: float, bx: float, by: float) -> float:
    return math.atan2(by - ay, bx - ax)


def d2(ax: float, ay: float, bx: float, by: float) -> float:
    return math.hypot(bx - ax, by - ay)


def unit(x: float, y: float):
    n = math.hypot(x, y)
    if n < 1e-9:
        return 0.0, 0.0
    return x / n, y / n


def clamp(v: float, lo: float, hi: float) -> float:
    return lo if v < lo else (hi if v > hi else v)


def lerp(a: float, b: float, t: float) -> float:
    return a + (b - a) * t
